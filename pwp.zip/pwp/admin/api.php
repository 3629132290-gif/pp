<?php
// 防止被已有 api.php 的 POST 路由拦截
$__admin_post = $_POST;
if (isset($_POST['type'])) {
    unset($_POST['type']);
}
require_once __DIR__ . '/../注册登录/api.php';
require_once __DIR__ . '/../secure_config.php';
// 初始化数据库连接（修复：原先缺少此调用导致所有API操作失败）
try {
    $pdo = createSecurePdo();
} catch (RuntimeException $e) {
    http_response_code(500);
    echo json_encode(['status' => -1, 'msg' => '数据库配置未就绪']);
    exit;
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => -1, 'msg' => '数据库连接失败']);
    exit;
}
$_POST = $__admin_post;
unset($__admin_post);
header('Content-Type: application/json; charset=utf-8');
// ==================== 真实IP获取（CDN适配） ====================
// 修复 #2: 默认仅信任 REMOTE_ADDR，防止 IP 伪造
// 仅在明确配置 CDN 时才信任代理头
function getRealIp() {
    // Cloudflare 适配（需环境变量启用）
    if (getenv('TRUST_CF_IP') === 'true' && !empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = trim(explode(',', $_SERVER['HTTP_CF_CONNECTING_IP'])[0]);
        if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
    }
    // 默认只信任 REMOTE_ADDR（不可伪造）
    if (!empty($_SERVER['REMOTE_ADDR'])) {
        $ip = trim($_SERVER['REMOTE_ADDR']);
        if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
    }
    return '0.0.0.0';
}
function ipInRange($ip, $range) {
    list($subnet, $bits) = explode('/', $range);
    $ipLong = ip2long($ip);
    $subnetLong = ip2long($subnet);
    if ($ipLong === false || $subnetLong === false) return false;
    $mask = -1 << (32 - $bits);
    $subnetLong &= $mask;
    return ($ipLong & $mask) === $subnetLong;
}
function isCdnIp($ip) {
    if (empty($ip) || $ip === '0.0.0.0') return false;
    $privateRanges = ['10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '127.0.0.0/8', '100.64.0.0/10', '169.254.0.0/16'];
    foreach ($privateRanges as $range) {
        if (ipInRange($ip, $range)) return true;
    }
    return false;
}
// ==================== 访问统计表初始化 ====================
function initVisitTable() {
    global $pdo;
    if (!isset($pdo) || !$pdo instanceof PDO) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS visit_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            ip VARCHAR(45) NOT NULL,
            visited_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            date DATE NOT NULL,
            duration INT DEFAULT 0,
            user_agent VARCHAR(255),
            page VARCHAR(100),
            user_id VARCHAR(32) DEFAULT NULL,
            INDEX idx_date (date),
            INDEX idx_ip (ip),
            INDEX idx_user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (PDOException $e) {
        // 忽略建表错误
    }
}
// ==================== 通知/公告表初始化 ====================
function initNotificationTable() {
    global $pdo;
    if (!isset($pdo) || !$pdo instanceof PDO) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(32) NOT NULL,
            title VARCHAR(200) NOT NULL,
            content TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            is_read TINYINT(1) DEFAULT 0,
            INDEX idx_user_id (user_id),
            INDEX idx_is_read (is_read)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (PDOException $e) {
        // 忽略建表错误
    }
}
function initAnnouncementTable() {
    global $pdo;
    if (!isset($pdo) || !$pdo instanceof PDO) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS site_announcements (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(200) NOT NULL,
            content TEXT NOT NULL,
            type VARCHAR(20) DEFAULT 'info',
            is_active TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (PDOException $e) {
        // 忽略建表错误
    }
}
// ==================== 域名/数据库表初始化 ====================
// 确保后台查询所需的表存在（这些表原本只在 域名/api.php 首次访问时创建）
function initDomainTables() {
    global $pdo;
    if (!isset($pdo) || !$pdo instanceof PDO) return;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS domains (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(32) NOT NULL,
            domain VARCHAR(255) NOT NULL UNIQUE,
            path VARCHAR(500) NOT NULL,
            bt_site_id INT DEFAULT NULL,
            status ENUM('active','suspended','deleted') DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_domain (domain)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (PDOException $e) {
        // 忽略建表错误
    }
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_databases (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(32) NOT NULL,
            domain_id INT NOT NULL,
            db_name VARCHAR(64) NOT NULL UNIQUE,
            db_user VARCHAR(64) NOT NULL,
            db_pass VARCHAR(255) NOT NULL,
            db_host VARCHAR(64) DEFAULT 'localhost',
            db_port INT DEFAULT 3306,
            bt_db_id INT DEFAULT NULL,
            status ENUM('active','suspended','deleted') DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_domain (domain_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (PDOException $e) {
        // 忽略建表错误
    }
}
// ==================== 管理员权限系统 ====================
function getAdminConfigFile() {
    // 修复 #9: 存储在 /www/miyodata/ (Web 根目录外)，而非 Web 可访问目录
    $secureDir = getSecureDataDir();
    return $secureDir . '/admin_users.json';
}
function initAdminConfig() {
    $file = getAdminConfigFile();
    if (!file_exists($file)) {
        if (!isAuthenticated() || empty($_SESSION['user']['id'])) {
            return false;
        }
        $dir = dirname($file);
        if (!is_dir($dir)) {
            @mkdir($dir, 0750, true);
        }
        $admins = [$_SESSION['user']['id']];
        file_put_contents($file, json_encode($admins, JSON_PRETTY_PRINT), LOCK_EX);
        chmod($file, 0600);
        return true;
    }
    return null;
}
function isAdminUser() {
    if (!isAuthenticated() || empty($_SESSION['user']['id'])) {
        return false;
    }
    $file = getAdminConfigFile();
    if (!file_exists($file)) {
        $init = initAdminConfig();
        if ($init === true) {
            return true;
        }
        return false;
    }
    $content = file_get_contents($file);
    $admins = json_decode($content, true);
    if (!is_array($admins)) {
        return false;
    }
    return in_array($_SESSION['user']['id'], $admins, true);
}
function requireAdmin() {
    if (!isAdminUser()) {
        http_response_code(403);
        echo json_encode(['status' => -1, 'msg' => '无权访问，需要管理员权限']);
        exit;
    }
}
function requireAdminCsrf() {
    requireAdmin();
    $token = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || empty($token) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        echo json_encode(['status' => -1, 'msg' => '安全校验失败，请刷新页面重试']);
        exit;
    }
}
// ==================== 请求路由 ====================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => -1, 'msg' => '请求方式不允许']);
    exit;
}
$type = $_POST['type'] ?? '';
// 公开检查接口（只读，用于前端判断）
if ($type === 'check_admin') {
    if (!isAuthenticated()) {
        echo json_encode(['status' => -1, 'msg' => '未登录']);
        exit;
    }
    echo json_encode(['status' => isAdminUser() ? 1 : 0]);
    exit;
}
// 访问记录接口（仅需登录 + CSRF，无需管理员权限）
if ($type === 'record_visit' || $type === 'record_leave' || $type === 'update_duration') {
    if (!isAuthenticated()) {
        echo json_encode(['status' => -1, 'msg' => '未登录']);
        exit;
    }
    $token = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || empty($token) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        echo json_encode(['status' => -1, 'msg' => '安全校验失败，请刷新页面重试']);
        exit;
    }
    // 修复 #17: 访问记录接口添加频率限制
    enforceRateLimit('visit_record');
    global $pdo;
    if (!isset($pdo) || !$pdo instanceof PDO) {
        http_response_code(500);
        echo json_encode(['status' => -1, 'msg' => '数据库未初始化']);
        exit;
    }
    if ($type === 'record_visit') {
        initVisitTable();
        $ip = getRealIp();
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $page = trim($_POST['page'] ?? 'unknown');
        $userId = $_SESSION['user']['id'] ?? null;
        try {
            $stmt = $pdo->prepare("INSERT INTO visit_logs (ip, visited_at, date, user_agent, page, duration, user_id) VALUES (?, NOW(), CURDATE(), ?, ?, 0, ?)");
            $stmt->execute([$ip, $ua, $page, $userId]);
            echo json_encode(['status' => 1, 'visit_id' => $pdo->lastInsertId()]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '记录失败']);
        }
    } else if ($type === 'update_duration') {
        $visitId = (int)($_POST['visit_id'] ?? 0);
        $duration = (int)($_POST['duration'] ?? 0);
        if ($visitId <= 0 || $duration < 0) {
            echo json_encode(['status' => 0, 'msg' => '参数无效']);
            exit;
        }
        try {
            $stmt = $pdo->prepare("UPDATE visit_logs SET duration = ? WHERE id = ?");
            $stmt->execute([$duration, $visitId]);
            echo json_encode(['status' => 1]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '更新失败']);
        }
    } else if ($type === 'record_leave') {
        $visitId = (int)($_POST['visit_id'] ?? 0);
        $duration = (int)($_POST['duration'] ?? 0);
        if ($visitId <= 0 || $duration < 0) {
            echo json_encode(['status' => 0, 'msg' => '参数无效']);
            exit;
        }
        try {
            // 幂等性保护：只更新一次最终时长
            $stmt = $pdo->prepare("UPDATE visit_logs SET duration = ? WHERE id = ? AND duration < ?");
            $stmt->execute([$duration, $visitId, $duration]);
            echo json_encode(['status' => 1]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '更新失败']);
        }
    }
    exit;
}
// 用户通知接口（仅需登录 + CSRF，无需管理员权限）
if ($type === 'get_my_notifications' || $type === 'mark_notification_read' || $type === 'get_announcement') {
    if (!isAuthenticated()) {
        echo json_encode(['status' => -1, 'msg' => '未登录']);
        exit;
    }
    $token = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || empty($token) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        echo json_encode(['status' => -1, 'msg' => '安全校验失败，请刷新页面重试']);
        exit;
    }
    // 修复 #17: 用户通知接口添加频率限制
    enforceRateLimit('default');
    global $pdo;
    if (!isset($pdo) || !$pdo instanceof PDO) {
        http_response_code(500);
        echo json_encode(['status' => -1, 'msg' => '数据库未初始化']);
        exit;
    }
    if ($type === 'get_my_notifications') {
        initNotificationTable();
        $userId = $_SESSION['user']['id'];
        try {
            $stmt = $pdo->prepare("SELECT * FROM user_notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
            $stmt->execute([$userId]);
            $notifications = $stmt->fetchAll();
            $unreadCount = 0;
            foreach ($notifications as &$n) {
                if ((int)$n['is_read'] === 0) $unreadCount++;
            }
            unset($n);
            echo json_encode(['status' => 1, 'data' => ['notifications' => $notifications, 'unread_count' => $unreadCount]]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '查询失败']);
        }
    } else if ($type === 'mark_notification_read') {
        $notifId = (int)($_POST['notification_id'] ?? 0);
        if ($notifId <= 0) {
            echo json_encode(['status' => 0, 'msg' => '参数无效']);
            exit;
        }
        try {
            $stmt = $pdo->prepare("UPDATE user_notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
            $stmt->execute([$notifId, $_SESSION['user']['id']]);
            echo json_encode(['status' => 1]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '更新失败']);
        }
    } else if ($type === 'get_announcement') {
        initAnnouncementTable();
        try {
            $stmt = $pdo->prepare("SELECT * FROM site_announcements WHERE is_active = 1 ORDER BY updated_at DESC LIMIT 1");
            $stmt->execute();
            $announcement = $stmt->fetch();
            echo json_encode(['status' => 1, 'data' => $announcement ?: null]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '查询失败']);
        }
    }
    exit;
}
// 以下所有操作都需要管理员权限 + CSRF + 频率限制
requireAdminCsrf();
enforceRateLimit('admin_action');
global $pdo;
if (!isset($pdo) || !$pdo instanceof PDO) {
    http_response_code(500);
    echo json_encode(['status' => -1, 'msg' => '数据库未初始化']);
    exit;
}
switch ($type) {
    // ---------- 概览统计 ----------
    case 'get_stats':
        initVisitTable();
        initDomainTables();
        // 自动检查并降级过期用户的存储配额
        try {
            $pdo->prepare("UPDATE users SET storage_quota = 102400, storage_expires = NULL WHERE storage_quota > 102400 AND storage_expires IS NOT NULL AND storage_expires < NOW()")->execute();
        } catch (PDOException $e) {
            // 忽略降级失败
        }
        try {
            $userCount = (int)($pdo->query("SELECT COUNT(*) FROM users")->fetchColumn() ?: 0);
            $domainCount = (int)($pdo->query("SELECT COUNT(*) FROM domains WHERE status = 'active'")->fetchColumn() ?: 0);
            $todayReg = (int)($pdo->query("SELECT COUNT(*) FROM users WHERE DATE(reg_time) = CURDATE()")->fetchColumn() ?: 0);
            $todayLogin = (int)($pdo->query("SELECT COUNT(*) FROM security_logs WHERE DATE(time) = CURDATE() AND message LIKE '%登录成功%'")->fetchColumn() ?: 0);
            $blacklistCount = (int)($pdo->query("SELECT COUNT(*) FROM ip_blacklist WHERE until = 0 OR until > " . time())->fetchColumn() ?: 0);
            $dbCount = (int)($pdo->query("SELECT COUNT(*) FROM user_databases WHERE status = 'active'")->fetchColumn() ?: 0);
            $totalVisits = (int)($pdo->query("SELECT COUNT(*) FROM visit_logs")->fetchColumn() ?: 0);
            $todayVisits = (int)($pdo->query("SELECT COUNT(*) FROM visit_logs WHERE date = CURDATE()")->fetchColumn() ?: 0);
            $totalIps = (int)($pdo->query("SELECT COUNT(DISTINCT ip) FROM visit_logs")->fetchColumn() ?: 0);
            $todayIps = (int)($pdo->query("SELECT COUNT(DISTINCT ip) FROM visit_logs WHERE date = CURDATE()")->fetchColumn() ?: 0);
            
            // 优化：排除异常值（小于1秒和大于24小时的记录）
            $avgDuration = (int)($pdo->query("SELECT AVG(duration) FROM visit_logs WHERE duration >= 1 AND duration <= 86400")->fetchColumn() ?: 0);
            
            echo json_encode([
                'status' => 1,
                'data' => [
                    'user_count' => $userCount,
                    'domain_count' => $domainCount,
                    'db_count' => $dbCount,
                    'today_reg' => $todayReg,
                    'today_login' => $todayLogin,
                    'blacklist_count' => $blacklistCount,
                    'total_visits' => $totalVisits,
                    'today_visits' => $todayVisits,
                    'total_ips' => $totalIps,
                    'today_ips' => $todayIps,
                    'avg_duration' => $avgDuration
                ]
            ]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '查询失败']);
        }
        break;
    // ---------- 用户管理 ----------
    case 'get_users':
        initDomainTables();
        $page = max(1, (int)($_POST['page'] ?? 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;
        $search = trim($_POST['search'] ?? '');
        try {
            if ($search !== '') {
                $kw = '%' . $search . '%';
                $stmt = $pdo->prepare("SELECT SQL_CALC_FOUND_ROWS id, name, email, reg_time, storage_quota, storage_expires FROM users WHERE name LIKE ? OR email LIKE ? ORDER BY reg_time DESC LIMIT ? OFFSET ?");
                $stmt->execute([$kw, $kw, $limit, $offset]);
            } else {
                $stmt = $pdo->prepare("SELECT SQL_CALC_FOUND_ROWS id, name, email, reg_time, storage_quota, storage_expires FROM users ORDER BY reg_time DESC LIMIT ? OFFSET ?");
                $stmt->execute([$limit, $offset]);
            }
            $users = $stmt->fetchAll();
            $total = (int)($pdo->query("SELECT FOUND_ROWS()")->fetchColumn() ?: 0);
            foreach ($users as &$u) {
                $dstmt = $pdo->prepare("SELECT COUNT(*) FROM domains WHERE user_id = ? AND status = 'active'");
                $dstmt->execute([$u['id']]);
                $u['domain_count'] = (int)$dstmt->fetchColumn();
                $u['storage_quota'] = (int)($u['storage_quota'] ?? 102400);
            }
            unset($u);
            echo json_encode([
                'status' => 1,
                'data' => [
                    'users' => $users,
                    'total' => $total,
                    'page' => $page,
                    'pages' => (int)ceil($total / $limit)
                ]
            ]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '查询失败']);
        }
        break;
    case 'delete_user':
        $id = trim($_POST['id'] ?? '');
        if (empty($id)) {
            echo json_encode(['status' => 0, 'msg' => '参数缺失']);
            exit;
        }
        if ($id === ($_SESSION['user']['id'] ?? '')) {
            echo json_encode(['status' => 0, 'msg' => '不能删除当前登录账号']);
            exit;
        }
        try {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE domains SET status = 'deleted' WHERE user_id = ?")->execute([$id]);
            $pdo->prepare("UPDATE user_databases SET status = 'deleted' WHERE user_id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
            $pdo->commit();
            securityLog("管理员删除用户: {$id}");
            echo json_encode(['status' => 1, 'msg' => '删除成功']);
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            echo json_encode(['status' => 0, 'msg' => '删除失败: ' . $e->getMessage()]);
        }
        break;
    // ---------- 域名管理 ----------
    case 'get_domains':
        initDomainTables();
        $page = max(1, (int)($_POST['page'] ?? 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;
        $search = trim($_POST['search'] ?? '');
        try {
            if ($search !== '') {
                $kw = '%' . $search . '%';
                $stmt = $pdo->prepare("SELECT SQL_CALC_FOUND_ROWS d.*, u.name as user_name, u.email as user_email FROM domains d LEFT JOIN users u ON d.user_id = u.id WHERE d.domain LIKE ? AND d.status = 'active' ORDER BY d.created_at DESC LIMIT ? OFFSET ?");
                $stmt->execute([$kw, $limit, $offset]);
            } else {
                $stmt = $pdo->prepare("SELECT SQL_CALC_FOUND_ROWS d.*, u.name as user_name, u.email as user_email FROM domains d LEFT JOIN users u ON d.user_id = u.id WHERE d.status = 'active' ORDER BY d.created_at DESC LIMIT ? OFFSET ?");
                $stmt->execute([$limit, $offset]);
            }
            $domains = $stmt->fetchAll();
            $total = (int)($pdo->query("SELECT FOUND_ROWS()")->fetchColumn() ?: 0);
            echo json_encode([
                'status' => 1,
                'data' => [
                    'domains' => $domains,
                    'total' => $total,
                    'page' => $page,
                    'pages' => (int)ceil($total / $limit)
                ]
            ]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '查询失败']);
        }
        break;
    case 'delete_domain':
        $domainId = (int)($_POST['domain_id'] ?? 0);
        if ($domainId <= 0) {
            echo json_encode(['status' => 0, 'msg' => '参数无效']);
            exit;
        }
        try {
            $stmt = $pdo->prepare("SELECT * FROM domains WHERE id = ? AND status = 'active'");
            $stmt->execute([$domainId]);
            $domain = $stmt->fetch();
            if (!$domain) {
                echo json_encode(['status' => 0, 'msg' => '域名不存在']);
                exit;
            }
            $pdo->prepare("UPDATE domains SET status = 'deleted' WHERE id = ?")->execute([$domainId]);
            $pdo->prepare("UPDATE user_databases SET status = 'deleted' WHERE domain_id = ?")->execute([$domainId]);
            securityLog("管理员删除域名: {$domain['domain']}");
            echo json_encode(['status' => 1, 'msg' => '删除成功']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '删除失败']);
        }
        break;
    // ---------- 安全日志 ----------
    case 'get_logs':
        $page = max(1, (int)($_POST['page'] ?? 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;
        try {
            $stmt = $pdo->prepare("SELECT SQL_CALC_FOUND_ROWS * FROM security_logs ORDER BY time DESC LIMIT ? OFFSET ?");
            $stmt->execute([$limit, $offset]);
            $logs = $stmt->fetchAll();
            $total = (int)($pdo->query("SELECT FOUND_ROWS()")->fetchColumn() ?: 0);
            foreach ($logs as &$log) {
                $log['ip_type'] = isCdnIp($log['ip'] ?? '') ? 'cdn' : 'direct';
            }
            unset($log);
            echo json_encode([
                'status' => 1,
                'data' => [
                    'logs' => $logs,
                    'total' => $total,
                    'page' => $page,
                    'pages' => (int)ceil($total / $limit)
                ]
            ]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '查询失败']);
        }
        break;
    // ---------- 管理员管理 ----------
    case 'get_admins':
        try {
            $file = getAdminConfigFile();
            $adminIds = [];
            if (file_exists($file)) {
                $adminIds = json_decode(file_get_contents($file), true) ?: [];
            }
            $admins = [];
            foreach ($adminIds as $aid) {
                $stmt = $pdo->prepare("SELECT id, name, email FROM users WHERE id = ?");
                $stmt->execute([$aid]);
                $u = $stmt->fetch();
                if ($u) {
                    $admins[] = $u;
                }
            }
            echo json_encode(['status' => 1, 'data' => $admins]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '查询失败']);
        }
        break;
    case 'add_admin':
        $userId = trim($_POST['user_id'] ?? '');
        if (empty($userId)) {
            echo json_encode(['status' => 0, 'msg' => '参数缺失']);
            exit;
        }
        $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        if (!$stmt->fetch()) {
            echo json_encode(['status' => 0, 'msg' => '用户不存在']);
            exit;
        }
        $file = getAdminConfigFile();
        $admins = [];
        if (file_exists($file)) {
            $admins = json_decode(file_get_contents($file), true) ?: [];
        }
        if (!in_array($userId, $admins, true)) {
            $admins[] = $userId;
            file_put_contents($file, json_encode($admins, JSON_PRETTY_PRINT), LOCK_EX);
            chmod($file, 0600);
        }
        securityLog("管理员添加管理员: {$userId}");
        echo json_encode(['status' => 1, 'msg' => '添加成功']);
        break;
    case 'remove_admin':
        $userId = trim($_POST['user_id'] ?? '');
        if (empty($userId)) {
            echo json_encode(['status' => 0, 'msg' => '参数缺失']);
            exit;
        }
        if ($userId === ($_SESSION['user']['id'] ?? '')) {
            echo json_encode(['status' => 0, 'msg' => '不能移除当前账号的管理员权限']);
            exit;
        }
        $file = getAdminConfigFile();
        $admins = [];
        if (file_exists($file)) {
            $admins = json_decode(file_get_contents($file), true) ?: [];
        }
        $admins = array_values(array_diff($admins, [$userId]));
        file_put_contents($file, json_encode($admins, JSON_PRETTY_PRINT), LOCK_EX);
        chmod($file, 0600);
        securityLog("管理员移除管理员: {$userId}");
        echo json_encode(['status' => 1, 'msg' => '移除成功']);
        break;
    // ---------- 存储配额管理 ----------
    case 'activate_storage':
        $userId = trim($_POST['user_id'] ?? '');
        if (empty($userId)) {
            echo json_encode(['status' => 0, 'msg' => '参数缺失']);
            exit;
        }
        try {
            // 开通 520MB 存储空间，有效期三个月
            $quota520MB = 545259520;
            $expiresAt = date('Y-m-d H:i:s', strtotime('+3 months'));
            $stmt = $pdo->prepare("UPDATE users SET storage_quota = ?, storage_expires = ? WHERE id = ?");
            $stmt->execute([$quota520MB, $expiresAt, $userId]);
            if ($stmt->rowCount() === 0) {
                echo json_encode(['status' => 0, 'msg' => '用户不存在']);
                exit;
            }
            securityLog("管理员为用户 {$userId} 开通了 520MB 存储空间，有效期至 {$expiresAt}");
            echo json_encode(['status' => 1, 'msg' => '已成功开通 520MB 存储空间，有效期三个月']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '操作失败']);
        }
        break;
    case 'reset_storage':
        $userId = trim($_POST['user_id'] ?? '');
        if (empty($userId)) {
            echo json_encode(['status' => 0, 'msg' => '参数缺失']);
            exit;
        }
        try {
            // 重置为默认 100KB，清除有效期
            $quota100KB = 102400;
            $stmt = $pdo->prepare("UPDATE users SET storage_quota = ?, storage_expires = NULL WHERE id = ?");
            $stmt->execute([$quota100KB, $userId]);
            securityLog("管理员重置用户 {$userId} 的存储配额为默认值");
            echo json_encode(['status' => 1, 'msg' => '已重置存储配额为默认 100KB']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '操作失败']);
        }
        break;
    case 'restore_storage':
        $userId = trim($_POST['user_id'] ?? '');
        if (empty($userId)) {
            echo json_encode(['status' => 0, 'msg' => '参数缺失']);
            exit;
        }
        try {
            // 恢复用户网页空间：清除用户网页数据 + 重置三个月有效期
            $quota520MB = 545259520;
            $expiresAt = date('Y-m-d H:i:s', strtotime('+3 months'));
            
            // 先清除用户域名目录下的所有网页文件
            $stmt = $pdo->prepare("SELECT path FROM domains WHERE user_id = ? AND status = 'active' LIMIT 1");
            $stmt->execute([$userId]);
            $domain = $stmt->fetch();
            $clearedFiles = false;
            if ($domain && !empty($domain['path']) && is_dir($domain['path'])) {
                $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($domain['path'], RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::CHILD_FIRST
                );
                $count = 0;
                foreach ($files as $file) {
                    if ($file->isDir()) {
                        @rmdir($file->getRealPath());
                    } else {
                        @unlink($file->getRealPath());
                        $count++;
                    }
                }
                $clearedFiles = true;
            }
            
            // 更新存储配额和有效期
            $stmt = $pdo->prepare("UPDATE users SET storage_quota = ?, storage_expires = ? WHERE id = ?");
            $stmt->execute([$quota520MB, $expiresAt, $userId]);
            if ($stmt->rowCount() === 0) {
                echo json_encode(['status' => 0, 'msg' => '用户不存在']);
                exit;
            }
            
            $detail = $clearedFiles ? '，已清除网页数据' : '';
            securityLog("管理员恢复用户 {$userId} 的网页空间{$detail}，有效期至 {$expiresAt}");
            echo json_encode(['status' => 1, 'msg' => '已恢复网页空间（有效期三个月）' . $detail]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '操作失败']);
        }
        break;
    // ---------- 系统通知管理 ----------
    case 'send_notification':
        $userId = trim($_POST['user_id'] ?? '');
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        if (empty($userId) || empty($title) || empty($content)) {
            echo json_encode(['status' => 0, 'msg' => '参数缺失']);
            exit;
        }
        try {
            initNotificationTable();
            $stmt = $pdo->prepare("INSERT INTO user_notifications (user_id, title, content) VALUES (?, ?, ?)");
            $stmt->execute([$userId, $title, $content]);
            securityLog("管理员向用户 {$userId} 发送通知: {$title}");
            echo json_encode(['status' => 1, 'msg' => '通知发送成功']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '发送失败']);
        }
        break;
    case 'get_notifications_admin':
        $page = max(1, (int)($_POST['page'] ?? 1));
        $limit = 20;
        $offset = ($page - 1) * $limit;
        try {
            initNotificationTable();
            $stmt = $pdo->prepare("SELECT SQL_CALC_FOUND_ROWS n.*, u.name as user_name FROM user_notifications n LEFT JOIN users u ON n.user_id = u.id ORDER BY n.created_at DESC LIMIT ? OFFSET ?");
            $stmt->execute([$limit, $offset]);
            $notifications = $stmt->fetchAll();
            $total = (int)($pdo->query("SELECT FOUND_ROWS()")->fetchColumn() ?: 0);
            echo json_encode([
                'status' => 1,
                'data' => [
                    'notifications' => $notifications,
                    'total' => $total,
                    'page' => $page,
                    'pages' => (int)ceil($total / $limit)
                ]
            ]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '查询失败']);
        }
        break;
    case 'delete_notification':
        $notifId = (int)($_POST['notification_id'] ?? 0);
        if ($notifId <= 0) {
            echo json_encode(['status' => 0, 'msg' => '参数无效']);
            exit;
        }
        try {
            $pdo->prepare("DELETE FROM user_notifications WHERE id = ?")->execute([$notifId]);
            echo json_encode(['status' => 1, 'msg' => '删除成功']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '删除失败']);
        }
        break;
    // ---------- 公告管理 ----------
    case 'save_announcement':
        initAnnouncementTable();
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $type = trim($_POST['announcement_type'] ?? 'info');
        if (empty($title) || empty($content)) {
            echo json_encode(['status' => 0, 'msg' => '标题和内容不能为空']);
            exit;
        }
        try {
            // 先停用所有公告
            $pdo->prepare("UPDATE site_announcements SET is_active = 0")->execute();
            // 插入新公告
            $stmt = $pdo->prepare("INSERT INTO site_announcements (title, content, type, is_active) VALUES (?, ?, ?, 1)");
            $stmt->execute([$title, $content, $type]);
            securityLog("管理员更新公告: {$title}");
            echo json_encode(['status' => 1, 'msg' => '公告已更新']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '保存失败']);
        }
        break;
    case 'get_announcement':
        initAnnouncementTable();
        try {
            $stmt = $pdo->prepare("SELECT * FROM site_announcements WHERE is_active = 1 ORDER BY updated_at DESC LIMIT 1");
            $stmt->execute();
            $announcement = $stmt->fetch();
            echo json_encode(['status' => 1, 'data' => $announcement ?: null]);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '查询失败']);
        }
        break;
    case 'disable_announcement':
        initAnnouncementTable();
        try {
            $pdo->prepare("UPDATE site_announcements SET is_active = 0")->execute();
            securityLog("管理员关闭了公告");
            echo json_encode(['status' => 1, 'msg' => '公告已关闭']);
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '操作失败']);
        }
        break;
    default:
        echo json_encode(['status' => 0, 'msg' => '未知操作']);
}
