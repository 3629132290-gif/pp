let currentTab = 'dashboard';
let pageData = {
    users: { page: 1, pages: 1, search: '' },
    domains: { page: 1, pages: 1, search: '' },
    logs: { page: 1, pages: 1 },
    notifications: { page: 1, pages: 1 }
};
let currentFilePath = '/www/wwwroot';
function showToast(msg, isError) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.className = 'toast' + (isError ? ' error' : '');
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2500);
}
function toggleMobileSidebar() {
    const sb = document.getElementById('sidebar');
    const ov = document.getElementById('overlay');
    const isOpen = sb.classList.contains('open');
    if (isOpen) {
        sb.classList.remove('open');
        ov.classList.remove('show');
        document.body.style.overflow = '';
    } else {
        sb.classList.add('open');
        ov.classList.add('show');
        document.body.style.overflow = 'hidden';
    }
}
function closeMobileSidebar() {
    const sb = document.getElementById('sidebar');
    const ov = document.getElementById('overlay');
    sb.classList.remove('open');
    ov.classList.remove('show');
    document.body.style.overflow = '';
}
function toggleCollapse() {
    const sb = document.getElementById('sidebar');
    const icon = document.getElementById('collapseIcon');
    if (window.innerWidth <= 768 && sb.classList.contains('open')) {
        closeMobileSidebar();
        return;
    }
    sb.classList.toggle('collapsed');
    if (sb.classList.contains('collapsed')) {
        icon.classList.remove('fa-chevron-left');
        icon.classList.add('fa-chevron-right');
        localStorage.setItem('sb_admin', '1');
    } else {
        icon.classList.remove('fa-chevron-right');
        icon.classList.add('fa-chevron-left');
        localStorage.setItem('sb_admin', '0');
    }
}
function logout() {
    if (!confirm('确定要退出登录吗？')) return;
    $.ajax({
        url: '/注册登录/api.php',
        type: 'POST',
        data: { type: 'logout' },
        dataType: 'json',
        timeout: 10000,
        success: () => window.location.href = '/注册登录/注册登录.php',
        error: () => window.location.href = '/注册登录/注册登录.php'
    });
}
function switchTab(tab) {
    currentTab = tab;
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    document.querySelector(`.nav-item[data-nav="${tab}"]`)?.classList.add('active');
    const container = document.getElementById('page-content');
    container.innerHTML = '<div class="loading-state"><i class="fas fa-spinner fa-spin"></i><p>加载中...</p></div>';
    switch (tab) {
        case 'dashboard': loadDashboard(); break;
        case 'users': loadUsers(); break;
        case 'domains': loadDomains(); break;
        case 'logs': loadLogs(); break;
        case 'notifications': loadNotifications(); break;
        case 'announcement': loadAnnouncement(); break;
    }
    if (window.innerWidth <= 768) {
        closeMobileSidebar();
    }
}
function apiPost(data, success, error) {
    data.csrf_token = window.csrfToken;
    $.ajax({
        url: 'api.php',
        type: 'POST',
        data: data,
        dataType: 'json',
        timeout: 15000,
        success: function (res) {
            if (res.status === 1) { if (success) success(res); }
            else { showToast(res.msg || '操作失败', true); if (error) error(res); }
        },
        error: function (xhr) {
            let msg = '网络请求失败';
            if (xhr.status === 403) msg = '权限不足或安全校验失败';
            else if (xhr.status === 429) msg = '请求过于频繁';
            showToast(msg, true);
            if (error) error();
        }
    });
}
// ==================== 概览 ====================
function loadDashboard() {
    apiPost({ type: 'get_stats' }, function (res) {
        const d = res.data;
        document.getElementById('page-content').innerHTML = `
            <div class="section"><h2 class="section-title"><i class="fas fa-chart-line"></i> 概览</h2></div>
            <div class="card-grid">
                <div class="stat-card"><div class="stat-header"><span class="stat-label">注册用户</span><div class="stat-icon"><i class="fas fa-users"></i></div></div><div class="stat-value" data-count="${d.user_count}">0</div><div class="stat-desc">今日新增 ${d.today_reg}</div></div>
                <div class="stat-card"><div class="stat-header"><span class="stat-label">域名数量</span><div class="stat-icon"><i class="fas fa-globe"></i></div></div><div class="stat-value" data-count="${d.domain_count}">0</div><div class="stat-desc">活跃域名</div></div>
                <div class="stat-card"><div class="stat-header"><span class="stat-label">数据库</span><div class="stat-icon"><i class="fas fa-database"></i></div></div><div class="stat-value" data-count="${d.db_count}">0</div><div class="stat-desc">用户数据库</div></div>
                <div class="stat-card"><div class="stat-header"><span class="stat-label">今日登录</span><div class="stat-icon"><i class="fas fa-sign-in-alt"></i></div></div><div class="stat-value" data-count="${d.today_login}">0</div><div class="stat-desc">成功登录次数</div></div>
                <div class="stat-card"><div class="stat-header"><span class="stat-label">黑名单IP</span><div class="stat-icon"><i class="fas fa-ban"></i></div></div><div class="stat-value" data-count="${d.blacklist_count}">0</div><div class="stat-desc">当前被封禁</div></div>
            </div>
            <div class="section" style="margin-top:24px"><h2 class="section-title"><i class="fas fa-chart-pie"></i> 访问统计</h2></div>
            <div class="card-grid">
                <div class="stat-card"><div class="stat-header"><span class="stat-label">总访问量</span><div class="stat-icon"><i class="fas fa-eye"></i></div></div><div class="stat-value" data-count="${d.total_visits}">0</div><div class="stat-desc">累计访问次数</div></div>
                <div class="stat-card"><div class="stat-header"><span class="stat-label">今日访问量</span><div class="stat-icon"><i class="fas fa-chart-bar"></i></div></div><div class="stat-value" data-count="${d.today_visits}">0</div><div class="stat-desc">今日访问次数</div></div>
                <div class="stat-card"><div class="stat-header"><span class="stat-label">总访问IP</span><div class="stat-icon"><i class="fas fa-network-wired"></i></div></div><div class="stat-value" data-count="${d.total_ips}">0</div><div class="stat-desc">独立IP数</div></div>
                <div class="stat-card"><div class="stat-header"><span class="stat-label">今日访问IP</span><div class="stat-icon"><i class="fas fa-user-clock"></i></div></div><div class="stat-value" data-count="${d.today_ips}">0</div><div class="stat-desc">今日独立IP</div></div>
                <div class="stat-card"><div class="stat-header"><span class="stat-label">平均访问时长</span><div class="stat-icon"><i class="fas fa-clock"></i></div></div><div class="stat-value" data-seconds="${d.avg_duration}">0秒</div><div class="stat-desc">用户平均停留时间</div></div>
            </div>
        `;
        animateNumbers();
    });
}
function animateNumbers() {
    document.querySelectorAll('[data-count]').forEach(el => {
        const target = parseInt(el.dataset.count) || 0;
        const dur = 600;
        const start = performance.now();
        function upd(now) {
            const p = Math.min((now - start) / dur, 1);
            const ease = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.floor(ease * target).toLocaleString();
            if (p < 1) requestAnimationFrame(upd);
        }
        requestAnimationFrame(upd);
    });
    
    // 新增：秒数格式化动画
    document.querySelectorAll('[data-seconds]').forEach(el => {
        const target = parseInt(el.dataset.seconds) || 0;
        const dur = 600;
        const start = performance.now();
        function upd(now) {
            const p = Math.min((now - start) / dur, 1);
            const ease = 1 - Math.pow(1 - p, 3);
            const current = Math.floor(ease * target);
            el.textContent = formatDuration(current);
            if (p < 1) requestAnimationFrame(upd);
        }
        requestAnimationFrame(upd);
    });
}
function formatDuration(seconds) {
    if (!seconds || seconds <= 0) return '0秒';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}时${m}分${s}秒`;
    if (m > 0) return `${m}分${s}秒`;
    return `${s}秒`;
}
// ==================== 用户管理 ====================
function formatStorageQuota(bytes) {
    if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(0) + ' MB';
    if (bytes >= 1024) return (bytes / 1024).toFixed(0) + ' KB';
    return bytes + ' B';
}
function loadUsers() {
    const container = document.getElementById('page-content');
    container.innerHTML = `
        <div class="section"><h2 class="section-title"><i class="fas fa-users"></i> 用户管理</h2></div>
        <div class="toolbar">
            <input type="text" class="search-input" id="userSearch" placeholder="搜索昵称或邮箱..." value="${escapeHtml(pageData.users.search)}">
            <button class="btn btn-primary" onclick="searchUsers()"><i class="fas fa-search"></i> 搜索</button>
            <button class="btn" onclick="refreshUsers()"><i class="fas fa-rotate-right"></i> 刷新</button>
        </div>
        <div class="table-wrapper"><table class="data-table"><thead><tr><th>ID</th><th>昵称</th><th>邮箱</th><th>注册时间</th><th>域名数</th><th>存储配额</th><th>操作</th></tr></thead><tbody id="usersTableBody"><tr><td colspan="7" class="empty-state">加载中...</td></tr></tbody></table></div>
        <div class="pagination" id="usersPagination"></div>
    `;
    document.getElementById('userSearch').addEventListener('keydown', e => { if (e.key === 'Enter') searchUsers(); });
    fetchUsers();
}
function fetchUsers() {
    apiPost({ type: 'get_users', page: pageData.users.page, search: pageData.users.search }, function (res) {
        const data = res.data;
        pageData.users.page = data.page;
        pageData.users.pages = data.pages;
        const tbody = document.getElementById('usersTableBody');
        if (!data.users.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><i class="fas fa-inbox" style="font-size:32px;opacity:.3"></i><div>暂无用户</div></td></tr>';
        } else {
            tbody.innerHTML = data.users.map(u => {
                const quota = u.storage_quota || 102400;
                const isActivated = quota >= 104857600; // 大于100MB视为已开通
                const quotaLabel = formatStorageQuota(quota);
                const expiresAt = u.storage_expires || null;
                const isExpired = expiresAt && new Date(expiresAt) < new Date();
                const expiresDisplay = expiresAt
                    ? (isExpired
                        ? `<span style="color:#dc2626;font-size:11px;">已过期 (${expiresAt})</span>`
                        : `<span style="color:#16a34a;font-size:11px;">到期: ${expiresAt}</span>`)
                    : '';
                const quotaBadge = isActivated 
                    ? `<span style="color:#16a34a;font-weight:700;">${quotaLabel}</span> <span style="font-size:11px;background:#dcfce7;color:#16a34a;padding:1px 6px;border-radius:3px;">LV2</span>${expiresDisplay ? '<br>' + expiresDisplay : ''}`
                    : `<span style="color:#999;">${quotaLabel}</span> <span style="font-size:11px;background:#f5f5f5;color:#999;padding:1px 6px;border-radius:3px;">LV1</span>`;
                let storageBtn = '';
                if (isActivated && !isExpired) {
                    // 已开通且未过期：显示重置和恢复按钮
                    storageBtn = `<button class="btn btn-sm" onclick="resetStorage('${escapeHtml(u.id)}','${escapeHtml(u.name)}')" style="color:#f59e0b;border-color:#f59e0b;" title="降级为默认100KB"><i class="fas fa-undo"></i> 降级</button>`
                        + `<button class="btn btn-sm" onclick="restoreStorage('${escapeHtml(u.id)}','${escapeHtml(u.name)}')" style="color:#3b82f6;border-color:#3b82f6;" title="清除网页数据并重置有效期"><i class="fas fa-sync"></i> 恢复</button>`;
                } else if (isActivated && isExpired) {
                    // 已过期：显示恢复和降级按钮
                    storageBtn = `<button class="btn btn-sm btn-primary" onclick="restoreStorage('${escapeHtml(u.id)}','${escapeHtml(u.name)}')" title="清除网页数据并重置三个月有效期"><i class="fas fa-sync"></i> 恢复</button>`
                        + `<button class="btn btn-sm" onclick="resetStorage('${escapeHtml(u.id)}','${escapeHtml(u.name)}')" style="color:#f59e0b;border-color:#f59e0b;" title="降级为默认100KB"><i class="fas fa-undo"></i> 降级</button>`;
                } else {
                    // 未开通
                    storageBtn = `<button class="btn btn-sm btn-primary" onclick="activateStorage('${escapeHtml(u.id)}','${escapeHtml(u.name)}')" title="开通520MB存储空间（有效期三个月）"><i class="fas fa-rocket"></i> 开通</button>`;
                }
                return `
                <tr>
                    <td><code style="font-size:12px">${escapeHtml(u.id)}</code></td>
                    <td>${escapeHtml(u.name)}</td>
                    <td>${escapeHtml(u.email)}</td>
                    <td>${escapeHtml(u.reg_time)}</td>
                    <td>${u.domain_count || 0}</td>
                    <td>${quotaBadge}</td>
                    <td class="actions">
                        ${storageBtn}
                        <button class="btn btn-sm btn-danger" onclick="deleteUser('${escapeHtml(u.id)}','${escapeHtml(u.name)}')"><i class="fas fa-trash"></i> 删除</button>
                    </td>
                </tr>
            `}).join('');
        }
        renderPagination('usersPagination', data.page, data.pages, 'users');
    });
}
function searchUsers() {
    pageData.users.search = document.getElementById('userSearch').value.trim();
    pageData.users.page = 1;
    fetchUsers();
}
function refreshUsers() { pageData.users.page = 1; pageData.users.search = ''; fetchUsers(); }
function deleteUser(id, name) {
    if (!confirm(`确定要删除用户 "${name}" 吗？\n此操作将删除其所有域名和数据，不可恢复！`)) return;
    apiPost({ type: 'delete_user', id: id }, function () {
        showToast('删除成功');
        fetchUsers();
    });
}
function activateStorage(id, name) {
    if (!confirm(`确定要为用户 "${name}" 开通 520MB 存储空间吗？\n有效期三个月，到期后自动降回100KB。`)) return;
    apiPost({ type: 'activate_storage', user_id: id }, function () {
        showToast('操作成功');
        fetchUsers();
    });
}
function resetStorage(id, name) {
    if (!confirm(`确定要降级用户 "${name}" 的存储空间为默认 100KB 吗？\n此操作不可恢复！`)) return;
    apiPost({ type: 'reset_storage', user_id: id }, function () {
        showToast('操作成功');
        fetchUsers();
    });
}
function restoreStorage(id, name) {
    if (!confirm(`确定要恢复用户 "${name}" 的网页空间吗？\n将清除该用户的所有网页文件，并重置三个月有效期。`)) return;
    apiPost({ type: 'restore_storage', user_id: id }, function () {
        showToast('操作成功');
        fetchUsers();
    });
}
// ==================== 域名管理 ====================
function loadDomains() {
    document.getElementById('page-content').innerHTML = `
        <div class="section"><h2 class="section-title"><i class="fas fa-globe"></i> 域名管理</h2></div>
        <div class="toolbar">
            <input type="text" class="search-input" id="domainSearch" placeholder="搜索域名..." value="${escapeHtml(pageData.domains.search)}">
            <button class="btn btn-primary" onclick="searchDomains()"><i class="fas fa-search"></i> 搜索</button>
            <button class="btn" onclick="refreshDomains()"><i class="fas fa-rotate-right"></i> 刷新</button>
        </div>
        <div class="table-wrapper"><table class="data-table"><thead><tr><th>域名</th><th>用户</th><th>路径</th><th>创建时间</th><th>操作</th></tr></thead><tbody id="domainsTableBody"><tr><td colspan="5" class="empty-state">加载中...</td></tr></tbody></table></div>
        <div class="pagination" id="domainsPagination"></div>
    `;
    document.getElementById('domainSearch').addEventListener('keydown', e => { if (e.key === 'Enter') searchDomains(); });
    fetchDomains();
}
function fetchDomains() {
    apiPost({ type: 'get_domains', page: pageData.domains.page, search: pageData.domains.search }, function (res) {
        const data = res.data;
        pageData.domains.page = data.page;
        pageData.domains.pages = data.pages;
        const tbody = document.getElementById('domainsTableBody');
        if (!data.domains.length) {
            tbody.innerHTML = '<tr><td colspan="5" class="empty-state"><i class="fas fa-inbox" style="font-size:32px;opacity:.3"></i><div>暂无域名</div></td></tr>';
        } else {
            tbody.innerHTML = data.domains.map(d => `
                <tr>
                    <td><a href="http://${escapeHtml(d.domain)}" target="_blank" rel="noopener">${escapeHtml(d.domain)}</a></td>
                    <td>${escapeHtml(d.user_name || '未知')}<br><small style="color:#999">${escapeHtml(d.user_email || '')}</small></td>
                    <td><code style="font-size:12px">${escapeHtml(d.path)}</code></td>
                    <td>${escapeHtml(d.created_at)}</td>
                    <td class="actions">
                        <button class="btn btn-sm btn-danger" onclick="deleteDomain(${d.id},'${escapeHtml(d.domain)}')"><i class="fas fa-trash"></i> 删除</button>
                    </td>
                </tr>
            `).join('');
        }
        renderPagination('domainsPagination', data.page, data.pages, 'domains');
    });
}
function searchDomains() {
    pageData.domains.search = document.getElementById('domainSearch').value.trim();
    pageData.domains.page = 1;
    fetchDomains();
}
function refreshDomains() { pageData.domains.page = 1; pageData.domains.search = ''; fetchDomains(); }
function deleteDomain(id, domain) {
    if (!confirm(`确定要删除域名 "${domain}" 吗？\n此操作不可恢复！`)) return;
    apiPost({ type: 'delete_domain', domain_id: id }, function () {
        showToast('删除成功');
        fetchDomains();
    });
}
// ==================== 安全日志 ====================
function loadLogs() {
    document.getElementById('page-content').innerHTML = `
        <div class="section"><h2 class="section-title"><i class="fas fa-shield-alt"></i> 安全日志</h2></div>
        <div class="toolbar">
            <button class="btn" onclick="refreshLogs()"><i class="fas fa-rotate-right"></i> 刷新</button>
        </div>
        <div class="file-browser"><div class="file-list" id="logsList"></div></div>
        <div class="pagination" id="logsPagination"></div>
    `;
    fetchLogs();
}
function fetchLogs() {
    apiPost({ type: 'get_logs', page: pageData.logs.page }, function (res) {
        const data = res.data;
        pageData.logs.page = data.page;
        pageData.logs.pages = data.pages;
        const list = document.getElementById('logsList');
        if (!data.logs.length) {
            list.innerHTML = '<div class="empty-state"><i class="fas fa-inbox" style="font-size:32px;opacity:.3"></i><div>暂无日志</div></div>';
        } else {
            list.innerHTML = data.logs.map(l => {
                const ipHtml = l.ip_type === 'cdn'
                    ? `<span class="log-ip" title="CDN节点IP（建议修改 ../注册登录/api.php 的 securityLog 函数使用 getRealIp() 记录真实IP）">${escapeHtml(l.ip)} <small style="color:#f59e0b">[CDN]</small></span>`
                    : `<span class="log-ip">${escapeHtml(l.ip)}</span>`;
                return `
                <div class="log-item">
                    <div class="log-time">${escapeHtml(l.time)}</div>
                    <div>${ipHtml}<span class="log-msg">${escapeHtml(l.message)}</span></div>
                </div>
            `}).join('');
        }
        renderPagination('logsPagination', data.page, data.pages, 'logs');
    });
}
function refreshLogs() { pageData.logs.page = 1; fetchLogs(); }
// ==================== 分页 ====================
function renderPagination(id, page, pages, type) {
    const el = document.getElementById(id);
    if (!el || pages <= 1) { if (el) el.innerHTML = ''; return; }
    let html = `<button ${page <= 1 ? 'disabled' : ''} onclick="goToPage('${type}',${page - 1})"><i class="fas fa-chevron-left"></i></button>`;
    for (let i = 1; i <= pages; i++) {
        if (i === 1 || i === pages || (i >= page - 1 && i <= page + 1)) {
            html += `<button class="${i === page ? 'active' : ''}" onclick="goToPage('${type}',${i})">${i}</button>`;
        } else if (i === page - 2 || i === page + 2) {
            html += `<span style="padding:0 4px;color:#999">...</span>`;
        }
    }
    html += `<button ${page >= pages ? 'disabled' : ''} onclick="goToPage('${type}',${page + 1})"><i class="fas fa-chevron-right"></i></button>`;
    el.innerHTML = html;
}
function goToPage(type, page) {
    pageData[type].page = page;
    if (type === 'users') fetchUsers();
    else if (type === 'domains') fetchDomains();
    else if (type === 'logs') fetchLogs();
    else if (type === 'notifications') fetchNotifications();
}
// ==================== 通知管理 ====================
function loadNotifications() {
    const container = document.getElementById('page-content');
    container.innerHTML = `
        <div class="section"><h2 class="section-title"><i class="fas fa-bell"></i> 系统通知管理</h2></div>
        <div class="toolbar">
            <button class="btn btn-primary" onclick="openSendNotificationModal()"><i class="fas fa-paper-plane"></i> 发送通知</button>
            <button class="btn" onclick="refreshNotifications()"><i class="fas fa-rotate-right"></i> 刷新</button>
        </div>
        <div class="table-wrapper"><table class="data-table"><thead><tr><th>ID</th><th>接收用户</th><th>标题</th><th>内容</th><th>时间</th><th>状态</th><th>操作</th></tr></thead><tbody id="notificationsTableBody"><tr><td colspan="7" class="empty-state">加载中...</td></tr></tbody></table></div>
        <div class="pagination" id="notificationsPagination"></div>
    `;
    fetchNotifications();
}
function fetchNotifications() {
    apiPost({ type: 'get_notifications_admin', page: pageData.notifications.page }, function (res) {
        const data = res.data;
        pageData.notifications.page = data.page;
        pageData.notifications.pages = data.pages;
        const tbody = document.getElementById('notificationsTableBody');
        if (!data.notifications.length) {
            tbody.innerHTML = '<tr><td colspan="7" class="empty-state"><i class="fas fa-inbox" style="font-size:32px;opacity:.3"></i><div>暂无通知</div></td></tr>';
        } else {
            tbody.innerHTML = data.notifications.map(n => `
                <tr>
                    <td><code style="font-size:12px">${n.id}</code></td>
                    <td>${escapeHtml(n.user_name || n.user_id)}</td>
                    <td>${escapeHtml(n.title)}</td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(n.content)}</td>
                    <td style="font-size:12px">${escapeHtml(n.created_at)}</td>
                    <td>${parseInt(n.is_read) === 1 ? '<span class="badge badge-success">已读</span>' : '<span class="badge badge-warning">未读</span>'}</td>
                    <td class="actions">
                        <button class="btn btn-sm btn-danger" onclick="deleteNotification(${n.id})"><i class="fas fa-trash"></i> 删除</button>
                    </td>
                </tr>
            `).join('');
        }
        renderPagination('notificationsPagination', data.page, data.pages, 'notifications');
    });
}
function refreshNotifications() { pageData.notifications.page = 1; fetchNotifications(); }
function deleteNotification(id) {
    if (!confirm('确定要删除这条通知吗？')) return;
    apiPost({ type: 'delete_notification', notification_id: id }, function () {
        showToast('删除成功');
        fetchNotifications();
    });
}
function openSendNotificationModal() {
    let modalHtml = `
    <div class="modal-overlay" id="sendNotifModal">
        <div class="modal">
            <div class="modal-header">
                <span class="modal-title">发送系统通知</span>
                <button class="modal-close" onclick="closeModal('sendNotifModal')"><i class="fas fa-times"></i></button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label>用户ID</label>
                    <input type="text" class="form-input" id="notifUserId" placeholder="输入用户ID（可在用户管理中查看）">
                </div>
                <div class="form-group">
                    <label>通知标题</label>
                    <input type="text" class="form-input" id="notifTitle" placeholder="输入通知标题">
                </div>
                <div class="form-group">
                    <label>通知内容</label>
                    <textarea class="form-input" id="notifContent" rows="4" placeholder="输入通知内容" style="resize:vertical"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn" onclick="closeModal('sendNotifModal')">取消</button>
                <button class="btn btn-primary" onclick="sendNotification()"><i class="fas fa-paper-plane"></i> 发送</button>
            </div>
        </div>
    </div>`;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    openModal('sendNotifModal');
}
function sendNotification() {
    const userId = document.getElementById('notifUserId').value.trim();
    const title = document.getElementById('notifTitle').value.trim();
    const content = document.getElementById('notifContent').value.trim();
    if (!userId || !title || !content) {
        showToast('请填写完整信息', true);
        return;
    }
    apiPost({ type: 'send_notification', user_id: userId, title: title, content: content }, function () {
        showToast('通知发送成功');
        closeModal('sendNotifModal');
        fetchNotifications();
    });
}
// ==================== 公告管理 ====================
function loadAnnouncement() {
    const container = document.getElementById('page-content');
    container.innerHTML = `
        <div class="section"><h2 class="section-title"><i class="fas fa-bullhorn"></i> 公告管理</h2></div>
        <div class="card-grid" style="grid-template-columns:1fr;max-width:700px;">
            <div class="stat-card" style="padding:24px;">
                <div class="stat-header"><span class="stat-label">编辑公告</span><div class="stat-icon"><i class="fas fa-edit"></i></div></div>
                <div class="form-group" style="margin-top:16px">
                    <label>公告标题</label>
                    <input type="text" class="form-input" id="annTitle" placeholder="输入公告标题">
                </div>
                <div class="form-group">
                    <label>公告内容</label>
                    <textarea class="form-input" id="annContent" rows="4" placeholder="输入公告内容" style="resize:vertical"></textarea>
                </div>
                <div class="form-group">
                    <label>公告类型</label>
                    <select class="form-input" id="annType">
                        <option value="info">信息（蓝色）</option>
                        <option value="success">成功（绿色）</option>
                        <option value="warning">警告（橙色）</option>
                        <option value="danger">危险（红色）</option>
                    </select>
                </div>
                <div style="display:flex;gap:10px;margin-top:8px;">
                    <button class="btn btn-primary" onclick="saveAnnouncement()"><i class="fas fa-save"></i> 保存并发布</button>
                    <button class="btn btn-danger" onclick="disableAnnouncement()"><i class="fas fa-times-circle"></i> 关闭公告</button>
                </div>
            </div>
        </div>
    `;
    // 加载当前公告
    apiPost({ type: 'get_announcement' }, function (res) {
        if (res.data) {
            document.getElementById('annTitle').value = res.data.title || '';
            document.getElementById('annContent').value = res.data.content || '';
            document.getElementById('annType').value = res.data.type || 'info';
        }
    });
}
function saveAnnouncement() {
    const title = document.getElementById('annTitle').value.trim();
    const content = document.getElementById('annContent').value.trim();
    const type = document.getElementById('annType').value;
    if (!title || !content) {
        showToast('标题和内容不能为空', true);
        return;
    }
    apiPost({ type: 'save_announcement', title: title, content: content, announcement_type: type }, function () {
        showToast('公告已更新');
    });
}
function disableAnnouncement() {
    if (!confirm('确定要关闭公告吗？关闭后用户将不再看到公告。')) return;
    apiPost({ type: 'disable_announcement' }, function () {
        showToast('公告已关闭');
        document.getElementById('annTitle').value = '';
        document.getElementById('annContent').value = '';
    });
}
// ==================== 模态框 ====================
function openModal(id) {
    document.getElementById(id).classList.add('active');
    document.body.style.overflow = 'hidden';
    const modal = document.querySelector('#' + id + ' .modal');
    if (modal && window.innerWidth <= 768) {
        let startY = 0, currentY = 0, isDragging = false;
        modal.dataset.modalId = id;
        modal.addEventListener('touchstart', function(e) {
            if (e.target.closest('.modal-body') && e.target.closest('.modal-body').scrollTop === 0) {
                startY = e.touches[0].clientY;
                isDragging = true;
            }
        }, { passive: true });
        modal.addEventListener('touchmove', function(e) {
            if (!isDragging) return;
            currentY = e.touches[0].clientY;
            const delta = currentY - startY;
            if (delta > 0) {
                modal.style.transform = 'translateY(' + delta + 'px)';
                modal.style.transition = 'none';
            }
        }, { passive: true });
        modal.addEventListener('touchend', function(e) {
            if (!isDragging) return;
            isDragging = false;
            modal.style.transition = '';
            const delta = currentY - startY;
            if (delta > 80) {
                closeModal(id);
            } else {
                modal.style.transform = '';
            }
        }, { passive: true });
    }
}
function closeModal(id) {
    const el = document.getElementById(id);
    el.classList.remove('active');
    const modal = document.querySelector('#' + id + ' .modal');
    if (modal) modal.style.transform = '';
    if (!document.querySelector('.modal-overlay.active')) {
        document.body.style.overflow = '';
    }
}
// ==================== 工具函数 ====================
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
}
function formatDate(ts) {
    return new Date(ts * 1000).toLocaleString('zh-CN');
}
// ==================== 初始化 ====================
window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
        document.body.style.overflow = '';
        document.getElementById('overlay').classList.remove('show');
        const sb = document.getElementById('sidebar');
        sb.classList.remove('open');
    }
});
document.addEventListener('DOMContentLoaded', function () {
    if (window.innerWidth > 768 && localStorage.getItem('sb_admin') === '1') {
        const sb = document.getElementById('sidebar');
        const icon = document.getElementById('collapseIcon');
        if (sb) sb.classList.add('collapsed');
        if (icon) { icon.classList.remove('fa-chevron-left'); icon.classList.add('fa-chevron-right'); }
    }
    apiPost({ type: 'check_admin' }, function (res) {
        if (res.status !== 1) {
            document.getElementById('page-content').innerHTML = `
                <div class="empty-state" style="padding-top:100px;">
                    <i class="fas fa-lock" style="font-size:48px;color:#dc2626;"></i>
                    <h2 style="margin:16px 0 8px;">无权访问</h2>
                    <p style="color:#666;">您没有管理员权限，请联系超级管理员。</p>
                    <a href="/部署/部署.php" class="btn btn-primary" style="margin-top:16px;text-decoration:none;">返回前台</a>
                </div>
            `;
            document.querySelector('.sidebar-nav').style.display = 'none';
            return;
        }
        switchTab('dashboard');
    });
});
