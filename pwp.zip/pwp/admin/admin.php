<?php
require_once __DIR__ . '/../注册登录/api.php';
if (!isAuthenticated()) {
    header('Location: /注册登录/注册登录.php');
    exit;
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$currentUser = [
    'name'  => htmlspecialchars($_SESSION['user']['name'] ?? '管理员', ENT_QUOTES, 'UTF-8'),
    'email' => htmlspecialchars($_SESSION['user']['email'] ?? '', ENT_QUOTES, 'UTF-8'),
];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#0a0a0a">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<title>管理后台 - Miyo</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      integrity="sha384-t1nt8BQoYMLFN5p42tRAtuAAFQaCQODekUVeKKZrEnEyp4H2R0RHFz0KWpmj7i8g" crossorigin="anonymous">
<link rel="stylesheet" href="css.css">
</head>
<body>
<div class="app">
    <div class="overlay" id="overlay" onclick="toggleMobileSidebar()"></div>
    <header class="header-bar">
        <div class="left">
            <button class="menu-toggle" id="menuToggle" onclick="toggleMobileSidebar()">
                <i class="fas fa-bars"></i>
            </button>
            <img src="../logo1.png" alt="Logo" class="logo-img" onerror="this.style.display='none'">
            <span class="title">miyo 管理后台</span>
        </div>
        <div class="user-info">
            <span class="user-name"><?php echo $currentUser['name']; ?></span>
            <button class="logout-btn" onclick="logout()">
                <i class="fas fa-sign-out-alt"></i>
                <span class="btn-text">退出</span>
            </button>
        </div>
    </header>
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <button class="collapse-btn" onclick="toggleCollapse()" title="折叠菜单">
                <i class="fas fa-chevron-left" id="collapseIcon"></i>
            </button>
        </div>
        <nav class="sidebar-nav">
            <a href="javascript:void(0)" class="nav-item active" data-nav="dashboard" onclick="switchTab('dashboard')">
                <i class="fas fa-chart-line"></i><span>概览</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="users" onclick="switchTab('users')">
                <i class="fas fa-users"></i><span>用户管理</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="domains" onclick="switchTab('domains')">
                <i class="fas fa-globe"></i><span>域名管理</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="logs" onclick="switchTab('logs')">
                <i class="fas fa-shield-alt"></i><span>安全日志</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="notifications" onclick="switchTab('notifications')">
                <i class="fas fa-bell"></i><span>通知管理</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="announcement" onclick="switchTab('announcement')">
                <i class="fas fa-bullhorn"></i><span>公告管理</span>
            </a>
            <a href="/部署/部署.php" class="nav-item">
                <i class="fas fa-arrow-left"></i><span>返回前台</span>
            </a>
        </nav>
        <div class="sidebar-footer">Miyo Admin v1.0</div>
    </aside>
    <main class="main-content" id="mainContent">
        <div class="content-wrapper" id="page-content">
            <div class="loading-state"><i class="fas fa-spinner fa-spin"></i><p>加载中...</p></div>
        </div>
    </main>
</div>
<div class="toast" id="toast"></div>
<script>
window.csrfToken = "<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>";
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha384-1H217gwSVyLSIfaLxHbE7dRb3v4mYCKbpQvzx0cegeju1MVsGrX5xXxAvs/HgeFs" crossorigin="anonymous"></script>
<script src="js.js"></script>
<script>
// 访问时长统计（自动记录页面停留时间，支持标签页切换）
(function() {
    let visitId = null;
    let startTime = Date.now();
    let totalDuration = 0;
    let isVisible = true;
    let recorded = false;
    
    function recordVisit() {
        if (recorded) return;
        recorded = true;
        var params = new URLSearchParams();
        params.append('type', 'record_visit');
        params.append('csrf_token', window.csrfToken);
        params.append('page', 'admin');
        fetch('api.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: params.toString()
        }).then(function(r){ return r.json(); }).then(function(res){
            if (res.status === 1) visitId = res.visit_id;
        }).catch(function(){});
    }
    
    function updateDuration() {
        if (!visitId || !isVisible) return;
        var now = Date.now();
        totalDuration += Math.floor((now - startTime) / 1000);
        startTime = now;
        
        var params = new URLSearchParams();
        params.append('type', 'update_duration');
        params.append('visit_id', visitId);
        params.append('duration', totalDuration);
        params.append('csrf_token', window.csrfToken);
        
        // 使用beacon确保数据发送成功
        if (navigator.sendBeacon) {
            navigator.sendBeacon('api.php', new Blob([params.toString()], {type: 'application/x-www-form-urlencoded'}));
        }
    }
    
    function recordLeave() {
        if (!visitId) return;
        if (isVisible) {
            totalDuration += Math.floor((Date.now() - startTime) / 1000);
        }
        
        var params = new URLSearchParams();
        params.append('type', 'record_leave');
        params.append('visit_id', visitId);
        params.append('duration', totalDuration);
        params.append('csrf_token', window.csrfToken);
        
        if (navigator.sendBeacon) {
            navigator.sendBeacon('api.php', new Blob([params.toString()], {type: 'application/x-www-form-urlencoded'}));
        } else {
            fetch('api.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: params.toString(),
                keepalive: true
            }).catch(function(){});
        }
        
        visitId = null;
    }
    
    recordVisit();
    
    // 页面卸载时记录最终时长
    window.addEventListener('beforeunload', recordLeave);
    
    // 标签页可见性变化处理
    document.addEventListener('visibilitychange', function() {
        if (document.visibilityState === 'hidden') {
            isVisible = false;
            updateDuration();
        } else if (document.visibilityState === 'visible') {
            isVisible = true;
            startTime = Date.now();
        }
    });
    
    // 每30秒自动同步一次时长，防止页面意外关闭丢失数据
    setInterval(updateDuration, 30000);
})();
</script>
</body>
</html>
