/**
 * 关于页面脚本
 * 适配iframe嵌入与独立访问
 */
// ===== 返回功能 =====
function goBack() {
    // 检查是否在iframe中运行
    if (window.self !== window.top) {
        // 在iframe中，通知父页面返回控制面板
        try {
            window.parent.showDashboard();
        } catch (e) {
            // 跨域或父页面不可访问时，使用历史回退
            window.history.back();
        }
    } else {
        // 独立访问时，跳转到部署中心
        window.location.href = '/部署/部署.php';
    }
}
// ===== 页面初始化 =====
document.addEventListener('DOMContentLoaded', function() {
    // 为卡片添加悬浮动画增强
    document.querySelectorAll('.card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            const icon = this.querySelector('.card-icon i');
            if (icon) {
                icon.style.animation = 'iconWiggle 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)';
                setTimeout(() => {
                    icon.style.animation = '';
                }, 500);
            }
        });
    });
    // 为功能列表项添加点击反馈
    document.querySelectorAll('.features-list li').forEach(item => {
        item.addEventListener('click', function() {
            this.style.transform = 'translateX(8px)';
            setTimeout(() => {
                this.style.transform = '';
            }, 200);
        });
    });
});
// ===== 图标摇摆动画（与部署中心保持一致） =====
@keyframes iconWiggle {
    0%   { transform: scale(1.0) rotate(0deg); }
    25%  { transform: scale(1.25) rotate(8deg); }
    50%  { transform: scale(1.15) rotate(-5deg); }
    75%  { transform: scale(1.2) rotate(3deg); }
    100% { transform: scale(1.15) rotate(-5deg); }
}
