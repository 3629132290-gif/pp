<?php
/**
 * 二级域名管理 API
 * 地址: /域名/api.php
 * 安全特性: CSRF防护、频率限制、路径遍历防护、输入过滤、SQL注入防护、XSS输出编码
 * 新增: 创建域名时自动创建MySQL数据库，密码加密存储
 */
if (ob_get_level() > 0) ob_clean();
// 修复 #10 & #11: 统一安全响应头 + Session Cookie 安全属性
require_once __DIR__ . '/../security_headers.php';
initSecureSession();
sendSecurityHeaders();
error_reporting(E_ALL);
ini_set('display_errors', 0);
header('Content-Type: application/json; charset=utf-8');

// ==================== 数据库配置（安全加载） ====================
// 修复 C-01: 数据库凭据不再硬编码
require_once __DIR__ . '/../secure_config.php';
try {
    $pdo = createSecurePdo();
} catch (RuntimeException $e) {
    http_response_code(500);
    echo json_encode(['status' => -1, 'msg' => '数据库配置未就绪，请联系管理员']);
    exit;
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => -1, 'msg' => '数据库连接失败']);
    exit;
}

// 建表（domains 存储二级域名信息）
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS domains (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(32) NOT NULL,
        domain VARCHAR(255) NOT NULL UNIQUE,
        path VARCHAR(500) NOT NULL,
        bt_site_id INT DEFAULT NULL,
        status ENUM('active','suspended','deleted') DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user (user_id),
        INDEX idx_domain (domain)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => -1, 'msg' => '数据表初始化失败']);
    exit;
}

// 建表（user_databases 存储数据库信息，密码加密）
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_databases (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(32) NOT NULL,
        domain_id INT NOT NULL,
        db_name VARCHAR(64) NOT NULL UNIQUE,
        db_user VARCHAR(64) NOT NULL,
        db_pass VARCHAR(255) NOT NULL,
        db_host VARCHAR(64) DEFAULT 'localhost',
        db_port INT DEFAULT 3306,
        bt_db_id INT DEFAULT NULL,
        status ENUM('active','suspended','deleted') DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user (user_id),
        INDEX idx_domain (domain_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => -1, 'msg' => '数据库表初始化失败']);
    exit;
}

// ==================== 加密函数（AES-256-CBC） ====================
function getDbSecret() {
    $secretFile = __DIR__ . '/../data/.db_secret';
    $secret = file_exists($secretFile) ? file_get_contents($secretFile) : null;
    if (!$secret || strlen($secret) < 32) {
        $secret = bin2hex(random_bytes(32));
        @mkdir(__DIR__ . '/../data', 0750, true);
        file_put_contents($secretFile, $secret, LOCK_EX);
        chmod($secretFile, 0600);
    }
    return substr(hash('sha256', $secret), 0, 32);
}

function encryptDbPass($plaintext) {
    $key = getDbSecret();
    $iv = random_bytes(16);
    $encrypted = openssl_encrypt($plaintext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $encrypted);
}

function decryptDbPass($ciphertext) {
    $key = getDbSecret();
    $data = base64_decode($ciphertext);
    if ($data === false || strlen($data) < 16) return null;
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    $decrypted = openssl_decrypt($encrypted, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted !== false ? $decrypted : null;
}

// ==================== 认证函数（与注册登录系统 session 兼容） ====================
function getClientIP() {
    // 修复 H-05: 默认仅信任 REMOTE_ADDR，防止 IP 伪造
    if (getenv('TRUST_CF_IP') === 'true' && !empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = trim(explode(',', $_SERVER['HTTP_CF_CONNECTING_IP'])[0]);
        if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
    }
    if (!empty($_SERVER['REMOTE_ADDR'])) {
        $ip = trim($_SERVER['REMOTE_ADDR']);
        if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
    }
    return '0.0.0.0';
}

function securityLog($msg) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO security_logs (ip, message) VALUES (?, ?)");
        $stmt->execute([getClientIP(), $msg]);
    } catch (PDOException $e) {}
}

function generateAuthToken($userId) {
    $secretFile = __DIR__ . '/../data/.auth_secret';
    $secret = file_exists($secretFile) ? file_get_contents($secretFile) : null;
    if (!$secret) {
        $secret = bin2hex(random_bytes(32));
        @mkdir(__DIR__ . '/../data', 0750, true);
        file_put_contents($secretFile, $secret, LOCK_EX);
        chmod($secretFile, 0600);
    }
    $time = time();
    $payload = session_id() . '|' . $userId . '|' . $time;
    $sig = hash_hmac('sha256', $payload, $secret);
    return $sig . '|' . $time;
}

function verifyAuthToken($token, $userId) {
    if (empty($token) || strpos($token, '|') === false) return false;
    list($sig, $time) = explode('|', $token, 2);
    if (!is_numeric($time) || $time < 1) return false;
    if (time() - (int)$time > 86400) return false;
    $secretFile = __DIR__ . '/../data/.auth_secret';
    $secret = file_exists($secretFile) ? file_get_contents($secretFile) : null;
    if (!$secret) return false;
    $payload = session_id() . '|' . $userId . '|' . $time;
    $expected = hash_hmac('sha256', $payload, $secret);
    return hash_equals($expected, $sig);
}

function isAuthenticated() {
    if (empty($_SESSION['user']) || empty($_SESSION['user']['id']) || empty($_SESSION['auth_token'])) return false;
    return verifyAuthToken($_SESSION['auth_token'], $_SESSION['user']['id']);
}

function requireAuth() {
    if (!isAuthenticated()) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        http_response_code(401);
        echo json_encode(['status' => -1, 'msg' => '登录已过期，请重新登录']);
        exit;
    }
}

// ==================== 频率限制 ====================
$RATE_LIMIT_CONFIG = [
    'domain_create' => [15, 3600],
    'domain_delete' => [15, 3600],
    'domain_update' => [25, 3600],
    'db_reset_pass' => [10, 3600],
    'default'     => [200, 60],
];

function checkRateLimit($action = 'default', $ip = null) {
    global $pdo, $RATE_LIMIT_CONFIG;
    if ($ip === null) $ip = getClientIP();
    if ($ip === '127.0.0.1' || $ip === '::1') return true;
    $config = $RATE_LIMIT_CONFIG[$action] ?? $RATE_LIMIT_CONFIG['default'];
    list($max, $window) = $config;
    $now = time();

    try {
        $stmt = $pdo->prepare("SELECT * FROM rate_limit WHERE ip = ? AND action = ?");
        $stmt->execute([$ip, $action]);
        $row = $stmt->fetch();

        if (!$row) {
            $pdo->prepare("INSERT INTO rate_limit (ip, action, count, window_start, violations) VALUES (?, ?, 1, ?, 0)")
                ->execute([$ip, $action, $now]);
            return true;
        }

        if ($now - $row['window_start'] > $window) {
            $pdo->prepare("UPDATE rate_limit SET count = 1, window_start = ?, violations = ? WHERE ip = ? AND action = ?")
                ->execute([$now, $row['violations'], $ip, $action]);
            return true;
        }

        $newCount = $row['count'] + 1;
        if ($newCount > $max) {
            $pdo->prepare("UPDATE rate_limit SET count = ?, violations = violations + 1 WHERE ip = ? AND action = ?")
                ->execute([$newCount, $ip, $action]);
            securityLog("频率限制触发: {$action}, IP: {$ip}");
            return false;
        }

        $pdo->prepare("UPDATE rate_limit SET count = ? WHERE ip = ? AND action = ?")
            ->execute([$newCount, $ip, $action]);
        return true;
    } catch (PDOException $e) {
        return true;
    }
}

function enforceRateLimit($action = 'default') {
    if (!checkRateLimit($action)) {
        http_response_code(429);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => -1, 'msg' => '请求过于频繁，请稍后再试']);
        exit;
    }
}

// ==================== 校验函数 ====================
function validateCsrfToken($token) {
    if (empty($_SESSION['csrf_token']) || empty($token)) return false;
    return hash_equals($_SESSION['csrf_token'], $token);
}

function validatePrefix($prefix) {
    if (empty($prefix)) return '域名前缀不能为空';
    $len = strlen($prefix);
    if ($len < 3 || $len > 20) return '域名前缀长度应为3-20个字符';
    if (!preg_match('/^[a-z0-9-]+$/', $prefix)) return '域名前缀只能包含小写字母、数字和横线';
    if (strpos($prefix, '--') !== false) return '域名前缀不能包含连续的横线';
    if ($prefix[0] === '-' || $prefix[$len-1] === '-') return '域名前缀不能以横线开头或结尾';
    $reserved = ['www','mail','ftp','admin','api','test','localhost','127','0','phpmyadmin','bt','panel','cdn','dns','mx','ns1','ns2','smtp','pop','imap','web','blog','shop','app','dev','staging','m','mobile','wap'];
    if (in_array($prefix, $reserved)) return '该前缀为系统保留，不可使用';
    return true;
}

// ==================== 宝塔API客户端（仅允许本机调用） ====================
// 修复 C-03: 宝塔 API 密钥从安全配置加载，不再硬编码
class BtApiClient {
    private $panel;
    private $key;
    private $timeout = 30;
    private $cookieFile;

    public function __construct() {
        $btConfig = SecureConfig::getInstance()->getBtConfig();
        $this->panel = $btConfig['panel'] ?? 'http://127.0.0.1:8888';
        $this->key   = $btConfig['api_key'] ?? '';
        $this->cookieFile = __DIR__ . '/../data/.bt_cookie_' . md5($this->panel);
        if (!file_exists($this->cookieFile)) {
            @mkdir(__DIR__ . '/../data', 0750, true);
            touch($this->cookieFile);
            chmod($this->cookieFile, 0600);
        }
    }

    private function getKeyData() {
        $now = time();
        return [
            'request_token' => md5($now . '' . md5($this->key)),
            'request_time'  => $now
        ];
    }

    public function request($endpoint, $data = []) {
        $url = rtrim($this->panel, '/') . $endpoint;
        $postData = array_merge($this->getKeyData(), $data);

        $ch = curl_init();
        // 宝塔面板运行在 localhost，默认 HTTP，无需 SSL 验证
        $curlSslVerifypeer = strpos($url, 'https://') === 0;
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_POST => 1,
            CURLOPT_POSTFIELDS => http_build_query($postData),
            CURLOPT_COOKIEJAR => $this->cookieFile,
            CURLOPT_COOKIEFILE => $this->cookieFile,
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_HEADER => 0,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => $curlSslVerifypeer,
            CURLOPT_SSL_VERIFYHOST => $curlSslVerifypeer ? 2 : 0,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded']
        ]);

        $result = curl_exec($ch);
        $err = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($err) throw new Exception('连接失败: ' . $err);
        if ($httpCode !== 200) throw new Exception('返回HTTP ' . $httpCode);

        $json = json_decode($result, true);
        if ($json === null && !empty($result)) return ['raw' => $result];
        return $json;
    }

    public function addSite($domain, $path, $phpVersion = '80') {
        $webname = json_encode([
            'domain' => $domain,
            'domainlist' => [],
            'count' => 0
        ], JSON_UNESCAPED_UNICODE);

        return $this->request('/site?action=AddSite', [
            'webname' => $webname,
            'path' => $path,
            'type_id' => 0,
            'type' => 'PHP',
            'version' => $phpVersion,
            'port' => 80,
            'ps' => 'Miyo用户域名: ' . $domain,
            'ftp' => 'false',
            'sql' => 'false',
            'codeing' => 'utf8'
        ]);
    }

    public function getSiteList() {
        return $this->request('/data?action=getData', [
            'table' => 'sites',
            'limit' => 9999,
            'p' => 1,
            'order' => 'id desc'
        ]);
    }

    public function deleteSite($siteId, $domain, $deletePath = true) {
        return $this->request('/site?action=DeleteSite', [
            'id' => $siteId,
            'webname' => $domain,
            'ftp' => '',
            'database' => '',
            'path' => $deletePath ? '1' : '0'
        ]);
    }

    public function updateSiteDomain($siteId, $oldDomain, $newDomain) {
        return $this->request('/site?action=ModifySite', [
            'id' => $siteId,
            'webname' => json_encode([
                'domain' => $newDomain,
                'domainlist' => [],
                'count' => 0
            ], JSON_UNESCAPED_UNICODE),
            'path' => '/www/wwwroot/' . $newDomain,
            'ps' => 'Miyo用户域名: ' . $newDomain
        ]);
    }

    // ==================== 数据库管理API ====================
    public function getDatabaseList() {
        return $this->request('/data?action=getData', [
            'table' => 'databases',
            'limit' => 9999,
            'p' => 1,
            'order' => 'id desc'
        ]);
    }

    public function addDatabase($dbName, $dbUser, $password, $ps = '') {
        return $this->request('/database?action=AddDatabase', [
            'name' => $dbName,
            'codeing' => 'utf8mb4',
            'db_user' => $dbUser,
            'password' => $password,
            'dtype' => 'MySQL',
            'dataAccess' => '127.0.0.1',
            'ps' => $ps,
            'address' => '127.0.0.1'
        ]);
    }

    public function deleteDatabase($dbId, $dbName) {
        return $this->request('/database?action=DeleteDatabase', [
            'id' => $dbId,
            'name' => $dbName
        ]);
    }

    public function resetDatabasePassword($dbId, $dbName, $newPassword) {
        return $this->request('/database?action=ResDatabasePassword', [
            'id' => $dbId,
            'name' => $dbName,
            'password' => $newPassword
        ]);
    }

    // 设置数据库容量限制（企业版功能，非企业版面板会忽略）
    public function setDatabaseQuota($dbId, $dbName, $quotaMB = 30) {
        return $this->request('/database?action=SetDatabaseQuota', [
            'id' => $dbId,
            'name' => $dbName,
            'quota' => $quotaMB
        ]);
    }
}

// ==================== 业务辅助函数 ====================
function getUserDomain($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM domains WHERE user_id = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

function getUserDatabase($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM user_databases WHERE user_id = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$userId]);
    $db = $stmt->fetch();
    if ($db && !empty($db['db_pass'])) {
        $db['db_pass_plain'] = decryptDbPass($db['db_pass']);
    }
    return $db;
}

function generateDbCredentials($userId, $prefix) {
    // 生成安全的数据库凭据
    $safePrefix = preg_replace('/[^a-z0-9]/', '', strtolower($prefix));
    $random = bin2hex(random_bytes(4));
    $dbName = 'miyo_' . $safePrefix . '_' . $random;
    $dbUser = 'miyo_' . $safePrefix . '_' . $random;
    // 限制长度（MySQL用户名最多32字符，数据库名最多64字符）
    $dbName = substr($dbName, 0, 64);
    $dbUser = substr($dbUser, 0, 32);
    $password = bin2hex(random_bytes(16)); // 32位随机密码
    return [
        'db_name' => $dbName,
        'db_user' => $dbUser,
        'db_pass' => $password
    ];
}

// ==================== 请求路由 ====================
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => -1, 'msg' => '请求方式不允许']);
    exit;
}

requireAuth();
$userId = $_SESSION['user']['id'];
$userName = $_SESSION['user']['name'] ?? '未知';
$type = $_POST['type'] ?? '';

try {
    switch ($type) {
        case 'get_csrf_token':
            if (empty($_SESSION['csrf_token'])) {
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            }
            echo json_encode(['status' => 1, 'token' => $_SESSION['csrf_token']]);
            break;

        case 'check_domain':
            $domain = getUserDomain($userId);
            echo json_encode([
                'status' => 1,
                'has_domain' => !empty($domain),
                'domain' => $domain ?: null
            ]);
            break;

        case 'create_domain':
            enforceRateLimit('domain_create');
            if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
                http_response_code(403);
                echo json_encode(['status' => -1, 'msg' => '安全校验失败，请刷新页面重试']);
                exit;
            }

            // 一个用户只能有一个二级域名
            if (getUserDomain($userId)) {
                echo json_encode(['status' => 0, 'msg' => '您已拥有二级域名，每个用户仅限一个']);
                exit;
            }

            $prefix = strtolower(trim($_POST['prefix'] ?? ''));
            $validation = validatePrefix($prefix);
            if ($validation !== true) {
                echo json_encode(['status' => 0, 'msg' => $validation]);
                exit;
            }

            $domain = $prefix . '.miyohost.cn';
            $rootPath = '/www/wwwroot/' . $domain;

            // 路径安全校验（防止路径遍历）
            if (strpos($rootPath, '..') !== false || strpos($domain, "\0") !== false) {
                echo json_encode(['status' => 0, 'msg' => '域名包含非法字符']);
                exit;
            }

            // 检查域名是否已被占用
            $stmt = $pdo->prepare("SELECT id FROM domains WHERE domain = ? AND status = 'active' LIMIT 1");
            $stmt->execute([$domain]);
            if ($stmt->fetch()) {
                echo json_encode(['status' => 0, 'msg' => '该域名已被使用，请更换前缀']);
                exit;
            }

            // 调用宝塔API（仅本机）
            $bt = new BtApiClient();

            // 预检：检查宝塔中是否已有该域名
            try {
                $list = $bt->getSiteList();
                if (!empty($list['data']) && is_array($list['data'])) {
                    foreach ($list['data'] as $s) {
                        if (($s['name'] ?? '') === $domain) {
                            echo json_encode(['status' => 0, 'msg' => '该域名已被使用']);
                            exit;
                        }
                    }
                }
            } catch (Exception $e) {
                securityLog("获取列表失败: " . $e->getMessage());
            }

            // 创建站点
            $result = $bt->addSite($domain, $rootPath);
            if (isset($result['status']) && $result['status'] === false) {
                $msg = $result['msg'] ?? '绑定域名失败';
                securityLog("创建失败 [{$domain}]: " . $msg);
                echo json_encode(['status' => 0, 'msg' => '创建失败: ' . $msg]);
                exit;
            }

            // 优化：通过查询列表获取准确的 siteId（宝塔创建是异步的，需要轮询确认）
            $btSiteId = null;
            $retry = 0;
            $maxRetry = 15; // 最多轮询15次
            while ($retry < $maxRetry && !$btSiteId) {
                usleep(300000); // 每次等待0.3秒，总计最多4.5秒
                try {
                    $list = $bt->getSiteList();
                    if (!empty($list['data']) && is_array($list['data'])) {
                        foreach ($list['data'] as $s) {
                            if (($s['name'] ?? '') === $domain) {
                                $btSiteId = (int)$s['id'];
                                break 2;
                            }
                        }
                    }
                } catch (Exception $e) {
                    // 查询失败继续尝试
                }
                $retry++;
            }

            // 备选：从返回结果获取
            if (!$btSiteId) {
                if (isset($result['siteId']) && is_numeric($result['siteId'])) {
                    $btSiteId = (int)$result['siteId'];
                } elseif (isset($result['id']) && is_numeric($result['id'])) {
                    $btSiteId = (int)$result['id'];
                }
            }

            // 确保站点目录存在（宝塔通常会自动创建，但做二次保障）
            if (!is_dir($rootPath)) {
                $mkdirOk = @mkdir($rootPath, 0755, true);
                if (!$mkdirOk && !is_dir($rootPath)) {
                    // 目录创建失败，清理已创建的站点
                    if ($btSiteId) {
                        try { $bt->deleteSite($btSiteId, $domain, false); } catch (Exception $e) {}
                    }
                    securityLog("目录创建失败 [{$domain}]: {$rootPath}");
                    echo json_encode(['status' => 0, 'msg' => '站点目录创建失败，请检查磁盘空间或权限']);
                    exit;
                }
            }

            // 宝塔面板会自动创建 index.html 作为默认首页，无需手动写入
            // 确保站点目录存在
            if (!is_dir($rootPath)) {
                @mkdir($rootPath, 0755, true);
            }
            @chmod($rootPath, 0755);

            // ==================== 创建数据库 ====================
            $dbCredentials = generateDbCredentials($userId, $prefix);
            $btDbId = null;
            $dbCreated = false;

            try {
                // 预检：检查宝塔中是否已有同名数据库
                $dbList = $bt->getDatabaseList();
                if (!empty($dbList['data']) && is_array($dbList['data'])) {
                    foreach ($dbList['data'] as $d) {
                        if (($d['name'] ?? '') === $dbCredentials['db_name']) {
                            throw new Exception('数据库名已存在');
                        }
                    }
                }

                $dbResult = $bt->addDatabase(
                    $dbCredentials['db_name'],
                    $dbCredentials['db_user'],
                    $dbCredentials['db_pass'],
                    'Miyo用户数据库: ' . $domain
                );

                if (isset($dbResult['status']) && $dbResult['status'] === false) {
                    throw new Exception($dbResult['msg'] ?? '创建数据库失败');
                }

                // 轮询获取数据库ID
                $dbRetry = 0;
                $maxDbRetry = 15;
                while ($dbRetry < $maxDbRetry && !$btDbId) {
                    usleep(300000);
                    try {
                        $dbList = $bt->getDatabaseList();
                        if (!empty($dbList['data']) && is_array($dbList['data'])) {
                            foreach ($dbList['data'] as $d) {
                                if (($d['name'] ?? '') === $dbCredentials['db_name']) {
                                    $btDbId = (int)$d['id'];
                                    break 2;
                                }
                            }
                        }
                    } catch (Exception $e) {}
                    $dbRetry++;
                }

                if (!$btDbId) {
                    if (isset($dbResult['id']) && is_numeric($dbResult['id'])) {
                        $btDbId = (int)$dbResult['id'];
                    }
                }

                $dbCreated = true;
                securityLog("数据库创建成功 [{$domain}]: {$dbCredentials['db_name']}");

                // 尝试设置数据库容量限制为30MB（企业版功能）
                if ($btDbId) {
                    try {
                        $bt->setDatabaseQuota($btDbId, $dbCredentials['db_name'], 30);
                    } catch (Exception $e) {
                        securityLog("设置数据库容量限制失败（非企业版可能不支持）: " . $e->getMessage());
                    }
                }
            } catch (Exception $e) {
                securityLog("数据库创建失败 [{$domain}]: " . $e->getMessage());
                // 数据库创建失败不阻断主流程，但记录日志
            }

            // 数据库写入（带事务和失败回滚）
            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("INSERT INTO domains (user_id, domain, path, bt_site_id, status, created_at) VALUES (?, ?, ?, ?, 'active', NOW())");
                $stmt->execute([$userId, $domain, $rootPath, $btSiteId]);
                $domainId = $pdo->lastInsertId();

                // 如果数据库创建成功，写入数据库记录
                if ($dbCreated) {
                    $encryptedPass = encryptDbPass($dbCredentials['db_pass']);
                    $stmt2 = $pdo->prepare("INSERT INTO user_databases (user_id, domain_id, db_name, db_user, db_pass, db_host, db_port, bt_db_id, status, created_at) VALUES (?, ?, ?, ?, ?, 'localhost', 3306, ?, 'active', NOW())");
                    $stmt2->execute([$userId, $domainId, $dbCredentials['db_name'], $dbCredentials['db_user'], $encryptedPass, $btDbId]);
                }

                $pdo->commit();

                securityLog("创建域名成功: {$domain}, 用户: {$userName}, siteId: " . ($btSiteId ?: 'unknown') . ", db: " . ($dbCreated ? $dbCredentials['db_name'] : 'none'));

                $response = [
                    'status' => 1,
                    'msg' => '域名绑定成功' . ($dbCreated ? '' : '，数据库异常'),
                    'domain' => $domain,
                    'path' => $rootPath,
                    'url' => 'http://' . $domain
                ];

                // 修复 C-04: 数据库密码不再明文返回，改用一次性令牌
                if ($dbCreated) {
                    $viewToken = bin2hex(random_bytes(16));
                    $_SESSION['db_view_token_' . $viewToken] = [
                        'db_pass' => $dbCredentials['db_pass'],
                        'expires' => time() + 300 // 5分钟有效
                    ];
                    $response['database'] = [
                        'db_name' => $dbCredentials['db_name'],
                        'db_user' => $dbCredentials['db_user'],
                        'db_host' => 'localhost',
                        'db_port' => 3306,
                        'view_token' => $viewToken  // 前端用此令牌获取密码
                    ];
                }

                echo json_encode($response);
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                // 清理宝塔站点和数据库，避免 orphaned 资源
                if ($btSiteId) {
                    try { $bt->deleteSite($btSiteId, $domain, false); } catch (Exception $e2) {}
                }
                if ($btDbId) {
                    try { $bt->deleteDatabase($btDbId, $dbCredentials['db_name']); } catch (Exception $e2) {}
                }
                securityLog("数据库写入失败 [{$domain}]: " . $e->getMessage());
                echo json_encode(['status' => 0, 'msg' => '数据保存失败，请稍后重试']);
                exit;
            }
            break;

        case 'update_domain':
            enforceRateLimit('domain_update');
            if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
                http_response_code(403);
                echo json_encode(['status' => -1, 'msg' => '安全校验失败']);
                exit;
            }

            $oldDomain = getUserDomain($userId);
            if (!$oldDomain) {
                echo json_encode(['status' => 0, 'msg' => '您没有可编辑的域名']);
                exit;
            }

            $prefix = strtolower(trim($_POST['prefix'] ?? ''));
            $validation = validatePrefix($prefix);
            if ($validation !== true) {
                echo json_encode(['status' => 0, 'msg' => $validation]);
                exit;
            }

            $newDomain = $prefix . '.miyohost.cn';
            $newPath = '/www/wwwroot/' . $newDomain;

            // 路径安全校验
            if (strpos($newPath, '..') !== false || strpos($newDomain, "\0") !== false) {
                echo json_encode(['status' => 0, 'msg' => '域名包含非法字符']);
                exit;
            }

            // 检查新域名是否已被占用（排除自己）
            $stmt = $pdo->prepare("SELECT id FROM domains WHERE domain = ? AND status = 'active' AND id != ? LIMIT 1");
            $stmt->execute([$newDomain, $oldDomain['id']]);
            if ($stmt->fetch()) {
                echo json_encode(['status' => 0, 'msg' => '该域名已被使用，请更换前缀']);
                exit;
            }

            // 调用宝塔API更新域名
            $bt = new BtApiClient();
            try {
                if (!empty($oldDomain['bt_site_id'])) {
                    $result = $bt->updateSiteDomain((int)$oldDomain['bt_site_id'], $oldDomain['domain'], $newDomain);
                    if (isset($result['status']) && $result['status'] === false) {
                        throw new Exception($result['msg'] ?? '更新域名失败');
                    }
                }
            } catch (Exception $e) {
                securityLog("更新失败 [{$oldDomain['domain']} -> {$newDomain}]: " . $e->getMessage());
                echo json_encode(['status' => 0, 'msg' => '更新失败: ' . $e->getMessage()]);
                exit;
            }

            // 更新数据库
            $stmt = $pdo->prepare("UPDATE domains SET domain = ?, path = ?, updated_at = NOW() WHERE id = ?");
            $stmt->execute([$newDomain, $newPath, $oldDomain['id']]);

            securityLog("更新域名成功: {$oldDomain['domain']} -> {$newDomain}, 用户: {$userName}");
            echo json_encode([
                'status' => 1,
                'msg' => '域名更新成功',
                'domain' => $newDomain,
                'path' => $newPath,
                'url' => 'http://' . $newDomain
            ]);
            break;

        case 'delete_domain':
            enforceRateLimit('domain_delete');
            if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
                http_response_code(403);
                echo json_encode(['status' => -1, 'msg' => '安全校验失败']);
                exit;
            }

            $domain = getUserDomain($userId);
            if (!$domain) {
                echo json_encode(['status' => 0, 'msg' => '您没有可删除的域名']);
                exit;
            }

            $bt = new BtApiClient();
            $siteDeleted = false;
            $dbDeleted = false;

            try {
                // 优先使用数据库记录的 bt_site_id 删除站点
                if (!empty($domain['bt_site_id'])) {
                    $result = $bt->deleteSite((int)$domain['bt_site_id'], $domain['domain'], true);
                    if (isset($result['status']) && $result['status'] === false) {
                        throw new Exception($result['msg'] ?? '删除站点失败');
                    }
                    $siteDeleted = true;
                } else {
                    // 如果没有 bt_site_id，从宝塔列表中按域名查找
                    $list = $bt->getSiteList();
                    if (!empty($list['data']) && is_array($list['data'])) {
                        foreach ($list['data'] as $s) {
                            if (($s['name'] ?? '') === $domain['domain']) {
                                $result = $bt->deleteSite((int)$s['id'], $domain['domain'], true);
                                if (isset($result['status']) && $result['status'] === false) {
                                    throw new Exception($result['msg'] ?? '删除站点失败');
                                }
                                $siteDeleted = true;
                                break;
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                securityLog("删除站点失败 [{$domain['domain']}]: " . $e->getMessage());
                echo json_encode(['status' => 0, 'msg' => '删除失败: ' . $e->getMessage() . '，出现异常']);
                exit;
            }

            // 删除关联的数据库
            $userDb = getUserDatabase($userId);
            if ($userDb) {
                try {
                    if (!empty($userDb['bt_db_id'])) {
                        $bt->deleteDatabase((int)$userDb['bt_db_id'], $userDb['db_name']);
                        $dbDeleted = true;
                    } else {
                        $dbList = $bt->getDatabaseList();
                        if (!empty($dbList['data']) && is_array($dbList['data'])) {
                            foreach ($dbList['data'] as $d) {
                                if (($d['name'] ?? '') === $userDb['db_name']) {
                                    $bt->deleteDatabase((int)$d['id'], $userDb['db_name']);
                                    $dbDeleted = true;
                                    break;
                                }
                            }
                        }
                    }
                } catch (Exception $e) {
                    securityLog("删除数据库失败 [{$userDb['db_name']}]: " . $e->getMessage());
                    // 数据库删除失败不阻断主流程
                }
            }

            // 如果宝塔里确实找不到这个站点，也允许清理数据库记录（避免死数据）
            if (!$siteDeleted && !empty($domain['bt_site_id'])) {
                securityLog("未找到站点 [{$domain['domain']}], 仅清理数据库记录");
            }

            $stmt = $pdo->prepare("UPDATE domains SET status = 'deleted', updated_at = NOW() WHERE id = ?");
            $stmt->execute([$domain['id']]);

            // 同时标记数据库为删除状态
            if ($userDb) {
                $stmt = $pdo->prepare("UPDATE user_databases SET status = 'deleted', updated_at = NOW() WHERE id = ?");
                $stmt->execute([$userDb['id']]);
            }

            securityLog("删除域名: {$domain['domain']}, 用户: {$userName}, 数据库: " . ($dbDeleted ? '已删除' : '未删除'));
            echo json_encode(['status' => 1, 'msg' => '域名已删除' . ($dbDeleted ? '，关联数据库已清理' : '')]);
            break;

        // ==================== 数据库管理接口 ====================
        case 'check_database':
            $db = getUserDatabase($userId);
            $domain = getUserDomain($userId);
            // 返回数据库信息（包含解密后的密码，前端控制显示/隐藏）
            echo json_encode([
                'status' => 1,
                'has_database' => !empty($db),
                'has_domain' => !empty($domain),
                'database' => $db ? [
                    'db_name' => $db['db_name'],
                    'db_user' => $db['db_user'],
                    'db_pass' => $db['db_pass_plain'] ?? '',
                    'db_host' => $db['db_host'],
                    'db_port' => (int)$db['db_port'],
                    'created_at' => $db['created_at']
                ] : null
            ]);
            break;

        case 'reset_db_password':
            enforceRateLimit('db_reset_pass');
            if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
                http_response_code(403);
                echo json_encode(['status' => -1, 'msg' => '安全校验失败']);
                exit;
            }

            $userDb = getUserDatabase($userId);
            if (!$userDb) {
                echo json_encode(['status' => 0, 'msg' => '您没有可重置密码的数据库']);
                exit;
            }

            $newPassword = bin2hex(random_bytes(16));
            $bt = new BtApiClient();

            try {
                if (!empty($userDb['bt_db_id'])) {
                    $result = $bt->resetDatabasePassword((int)$userDb['bt_db_id'], $userDb['db_name'], $newPassword);
                    if (isset($result['status']) && $result['status'] === false) {
                        throw new Exception($result['msg'] ?? '重置密码失败');
                    }
                } else {
                    // 通过名称查找数据库ID
                    $dbList = $bt->getDatabaseList();
                    if (!empty($dbList['data']) && is_array($dbList['data'])) {
                        foreach ($dbList['data'] as $d) {
                            if (($d['name'] ?? '') === $userDb['db_name']) {
                                $result = $bt->resetDatabasePassword((int)$d['id'], $userDb['db_name'], $newPassword);
                                if (isset($result['status']) && $result['status'] === false) {
                                    throw new Exception($result['msg'] ?? '重置密码失败');
                                }
                                break;
                            }
                        }
                    } else {
                        throw new Exception('未找到数据库');
                    }
                }

                // 更新本地数据库记录
                $encryptedPass = encryptDbPass($newPassword);
                $stmt = $pdo->prepare("UPDATE user_databases SET db_pass = ?, updated_at = NOW() WHERE id = ?");
                $stmt->execute([$encryptedPass, $userDb['id']]);

                securityLog("重置数据库密码: {$userDb['db_name']}, 用户: {$userName}");
                echo json_encode([
                    'status' => 1,
                    'msg' => '数据库密码已重置',
                    'db_pass' => $newPassword
                ]);
            } catch (Exception $e) {
                securityLog("重置数据库密码失败 [{$userDb['db_name']}]: " . $e->getMessage());
                echo json_encode(['status' => 0, 'msg' => '重置失败: ' . $e->getMessage()]);
            }
            break;

        // 修复 C-04: 通过一次性令牌获取数据库密码
        case 'view_db_pass':
            $token = trim($_POST['view_token'] ?? '');
            if (empty($token)) {
                echo json_encode(['status' => 0, 'msg' => '参数缺失']);
                exit;
            }
            $sessionKey = 'db_view_token_' . $token;
            if (!isset($_SESSION[$sessionKey])) {
                echo json_encode(['status' => 0, 'msg' => '令牌无效或已过期']);
                exit;
            }
            $tokenData = $_SESSION[$sessionKey];
            if (time() > $tokenData['expires']) {
                unset($_SESSION[$sessionKey]);
                echo json_encode(['status' => 0, 'msg' => '令牌已过期，请刷新页面']);
                exit;
            }
            // 一次性使用，立即销毁
            $pass = $tokenData['db_pass'];
            unset($_SESSION[$sessionKey]);
            echo json_encode(['status' => 1, 'db_pass' => $pass]);
            break;

        default:
            echo json_encode(['status' => 0, 'msg' => '未知操作类型']);
    }
} catch (Exception $e) {
    securityLog("域名API异常: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => -1, 'msg' => '服务器内部错误']);
}
