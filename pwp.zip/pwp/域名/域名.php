<?php
/**
 * 二级域名管理页面
 * 地址: /域名/域名.php
 * 未登录用户自动重定向到登录页
 * 修复：iframe嵌入时完全隐藏重复的顶部导航、侧边栏和页面标题
 */
require_once __DIR__ . '/../注册登录/api.php';
if (!isAuthenticated()) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    header('Location: /注册登录/注册登录.php');
    exit;
}
$currentUser = [
    'name'  => htmlspecialchars($_SESSION['user']['name'] ?? '用户', ENT_QUOTES, 'UTF-8'),
    'email' => htmlspecialchars($_SESSION['user']['email'] ?? '', ENT_QUOTES, 'UTF-8'),
];
// 生成CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>二级域名管理 - Miyo</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      integrity="sha384-t1nt8BQoYMLFN5p42tRAtuAAFQaCQODekUVeKKZrEnEyp4H2R0RHFz0KWpmj7i8g" crossorigin="anonymous">
<link rel="stylesheet" href="css.css">
<style>
/* iframe嵌入模式专用样式 - 彻底移除所有重复元素 */
body.iframe-mode .header-bar,
body.iframe-mode .sidebar,
body.iframe-mode .overlay,
body.iframe-mode .page-title {
    display: none !important;
}

body.iframe-mode .main-content {
    margin-top: 0 !important;
    padding: 0 !important;
    height: 100vh !important;
}

body.iframe-mode .content-wrapper {
    max-width: 100% !important;
    padding: 20px 20px 52px !important;
}

@media (max-width: 768px) {
    body.iframe-mode .content-wrapper {
        padding: 16px 16px 48px !important;
    }
}

/* 表单输入实时校验状态 */
.form-input.input-error { border-color: #ef4444 !important; background-color: #fef2f2; }
.form-input.input-success { border-color: #22c55e !important; background-color: #f0fdf4; }
.input-hint { font-size: 12px; margin-top: 6px; color: #ef4444; min-height: 18px; }
</style>
</head>
<body>
<div class="app">
    <div class="overlay" id="overlay" onclick="toggleMobileSidebar()"></div>
    <header class="header-bar">
        <div class="left">
            <button class="menu-toggle" id="menuToggle" onclick="toggleMobileSidebar()" aria-label="菜单">
                <i class="fas fa-bars"></i>
            </button>
            <img src="../logo1.png" alt="Logo" class="logo-img" onerror="this.style.display='none'">
            <span class="title">miyo 二级域名</span>
        </div>
        <div class="user-info">
            <span class="user-name"><?php echo $currentUser['name']; ?></span>
            <button class="logout-btn" onclick="logout()">
                <i class="fas fa-sign-out-alt"></i>
                <span class="btn-text">退出</span>
            </button>
        </div>
    </header>
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <button class="collapse-btn" onclick="toggleCollapse()" title="折叠菜单">
                <i class="fas fa-chevron-left" id="collapseIcon"></i>
            </button>
        </div>
        <nav class="sidebar-nav">
            <a href="/部署/部署.php" class="nav-item">
                <i class="fas fa-home"></i>
                <span>概览</span>
            </a>
            <a href="javascript:void(0)" class="nav-item active" onclick="return false;">
                <i class="fas fa-globe"></i>
                <span>二级域名</span>
            </a>
            <a href="/数据库/数据库.php" class="nav-item">
                <i class="fas fa-database"></i>
                <span>数据库</span>
            </a>
            <a href="/文件/文件.php" class="nav-item">
                <i class="fas fa-folder"></i>
                <span>文件管理</span>
            </a>
            <a href="/文件/文件.php" class="nav-item">
                <i class="fas fa-server"></i>
                <span>网站管理</span>
            </a>
        </nav>
        <div class="sidebar-footer">Miyo v3.0 · 免费网页托管</div>
    </aside>
    <main class="main-content" id="mainContent">
        <div class="content-wrapper" id="page-content">
            <div class="loading-state">
                <i class="fas fa-spinner fa-spin"></i>
                <p>加载中...</p>
            </div>
        </div>
    </main>
</div>
<div class="toast" id="toast"></div>
<script>
window.currentUser = <?php echo json_encode($currentUser); ?>;
window.csrfToken = "<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>";

// 自动检测iframe嵌入并应用样式
if (window.self !== window.top) {
    document.body.classList.add('iframe-mode');
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha384-1H217gwSVyLSIfaLxHbE7dRb3v4mYCKbpQvzx0cegeju1MVsGrX5xXxAvs/HgeFs" crossorigin="anonymous"></script>
<script src="js.js"></script>
</body>
</html>
