/**
 * 二级域名管理前端脚本
 * 安全特性：CSRF防护、输入校验、XSS防护（escapeHtml）
 */
let csrfToken = window.csrfToken || '';
let hasDomain = false;
let currentDomain = null;
function showToast(msg, duration = 2500) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), duration);
}
function toggleMobileSidebar() {
    const sb = document.getElementById('sidebar');
    const ov = document.getElementById('overlay');
    sb.classList.toggle('open');
    ov.classList.toggle('show');
}
function toggleCollapse() {
    const sb = document.getElementById('sidebar');
    const icon = document.getElementById('collapseIcon');
    if (window.innerWidth <= 768 && sb.classList.contains('open')) {
        sb.classList.remove('open');
        document.getElementById('overlay').classList.remove('show');
        return;
    }
    sb.classList.toggle('collapsed');
    if (sb.classList.contains('collapsed')) {
        icon.classList.remove('fa-chevron-left');
        icon.classList.add('fa-chevron-right');
        localStorage.setItem('sb', '1');
    } else {
        icon.classList.remove('fa-chevron-right');
        icon.classList.add('fa-chevron-left');
        localStorage.setItem('sb', '0');
    }
}
function logout() {
    if (!confirm('确定要退出登录吗？')) return;
    $.ajax({
        url: '/注册登录/api.php',
        type: 'POST',
        data: { type: 'logout' },
        dataType: 'json',
        timeout: 10000,
        success: function() {
            window.location.href = '/注册登录/注册登录.php';
        },
        error: function() {
            window.location.href = '/注册登录/注册登录.php';
        }
    });
}
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
// 前端域名前缀校验（与后端保持一致）
function validatePrefixInput(prefix) {
    if (!prefix) return '请输入域名前缀';
    if (prefix.length < 3 || prefix.length > 20) return '前缀不规范喵';
    if (!/^[a-z0-9-]+$/.test(prefix)) return '只能包含小写字母、数字和横线';
    if (prefix.includes('--')) return '不能包含连续的横线';
    if (prefix[0] === '-' || prefix[prefix.length - 1] === '-') return '不能以横线开头或结尾';
    const reserved = ['www','mail','ftp','admin','api','test','localhost','127','0','phpmyadmin','bt','panel','cdn','dns','mx','ns1','ns2','smtp','pop','imap','web','blog','shop','app','dev','staging','m','mobile','wap'];
    if (reserved.includes(prefix)) return '这个前缀我要用哦喵';
    return true;
}
// 加载用户域名状态
function loadStatus() {
    $.ajax({
        url: 'api.php',
        type: 'POST',
        data: { type: 'check_domain' },
        dataType: 'json',
        timeout: 10000,
        success: function(res) {
            if (res.status === 1) {
                hasDomain = res.has_domain;
                currentDomain = res.domain;
                if (hasDomain && currentDomain) {
                    renderDomainInfo(currentDomain);
                } else {
                    renderBindForm();
                }
            } else {
                showToast(res.msg || '加载失败');
                renderBindForm();
            }
        },
        error: function() {
            showToast('刷新重试喵');
            renderBindForm();
        }
    });
}
// 渲染绑定表单（无域名时）
function renderBindForm() {
    const container = document.getElementById('page-content');
    container.innerHTML = `
        <div class="domain-page">
            <h1 class="page-title">域名绑定</h1>
            <div class="action-bar">
                <button class="btn btn-primary" onclick="showCustomDomainTip()" id="toggleBindBtn" title="不支持绑定自己的域名喵">
                    <i class="fas fa-plus"></i> 添加域名
                </button>
                <button class="btn btn-success" onclick="toggleBindForm()" id="toggleSubdomainBtn">
                    <i class="fas fa-plus"></i> 二级域名
                </button>
            </div>
            <div class="bind-form" id="bindForm" style="display:none;">
                <div class="bind-form-title">绑定域名</div>
                <div class="form-row">
                    <input type="text" id="domain-prefix" class="form-input" placeholder="请输入域名前缀..." maxlength="20" autocomplete="off" spellcheck="false">
                    <span class="form-suffix">miyohost.cn</span>
                </div>
                <div class="input-hint" id="inputHint"></div>
                <button class="btn btn-success" id="bindBtn" onclick="bindDomain()" disabled>
                    <i class="fas fa-check"></i> 确认绑定
                </button>
            </div>
            <div class="domain-table-wrapper">
                <table class="domain-table">
                    <thead>
                        <tr>
                            <th>域名</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="2">
                                <div class="empty-state">
                                    <i class="fas fa-globe" style="font-size: 32px; color: #d4d4d4; margin-bottom: 12px;"></i>
                                    <div>暂无绑定域名</div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    `;
    
    const input = document.getElementById('domain-prefix');
    if (input) {
        input.addEventListener('input', function() {
            this.value = this.value.toLowerCase();
            const hint = document.getElementById('inputHint');
            const bindBtn = document.getElementById('bindBtn');
            const validation = validatePrefixInput(this.value);
            
            if (validation === true) {
                this.classList.remove('input-error');
                this.classList.add('input-success');
                if (hint) hint.textContent = '';
                if (bindBtn) bindBtn.disabled = false;
            } else {
                this.classList.remove('input-success');
                this.classList.add('input-error');
                if (hint) hint.textContent = validation;
                if (bindBtn) bindBtn.disabled = true;
            }
        });
        
        // 初始触发一次校验，确保按钮状态正确
        input.dispatchEvent(new Event('input'));
    }
}
// 显示自定义域名提示
function showCustomDomainTip() {
    showToast('不支持自定义域名喵');
}
// 切换绑定表单显示/隐藏
function toggleBindForm() {
    const form = document.getElementById('bindForm');
    const btn = document.getElementById('toggleSubdomainBtn');
    if (!form || !btn) return;
    if (form.style.display === 'none') {
        form.style.display = 'block';
        btn.innerHTML = '<i class="fas fa-times"></i> 取消添加';
        btn.classList.remove('btn-success');
        btn.classList.add('btn-outline-success');
        setTimeout(() => {
            const input = document.getElementById('domain-prefix');
            if (input) {
                input.focus();
                input.dispatchEvent(new Event('input'));
            }
        }, 100);
    } else {
        form.style.display = 'none';
        btn.innerHTML = '<i class="fas fa-plus"></i> 二级域名';
        btn.classList.add('btn-success');
        btn.classList.remove('btn-outline-success');
    }
}
// 渲染域名信息（有域名时）
function renderDomainInfo(domain) {
    const container = document.getElementById('page-content');
    const domainName = escapeHtml(domain.domain);
    const created = escapeHtml(domain.created_at);
    const url = 'http://' + domain.domain;
    
    container.innerHTML = `
        <div class="domain-page">
            <h1 class="page-title">域名绑定</h1>
            <div class="action-bar">
                <button class="btn btn-primary" onclick="showCustomDomainTip()" id="toggleBindBtn" title="目前仅支持二级域名，自定义域名功能开发中">
                    <i class="fas fa-plus"></i> 添加域名
                </button>
                <button class="btn btn-success" disabled title="您已拥有二级域名，每个用户仅限一个">
                    <i class="fas fa-plus"></i> 二级域名
                </button>
            </div>
            
            <div class="domain-table-wrapper">
                <table class="domain-table">
                    <thead>
                        <tr>
                            <th>域名</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="domain-name">
                                    <a href="${escapeHtml(url)}" target="_blank" rel="noopener">${domainName}</a>
                                </div>
                                <div class="domain-meta"> ${created}</div>
                            </td>
                            <td>
                                <div class="domain-actions">
                                    <button class="btn btn-danger" onclick="deleteDomain()">
                                        <i class="fas fa-trash-alt"></i> 删除
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    `;
}
// 绑定域名
function bindDomain() {
    const prefixInput = document.getElementById('domain-prefix');
    const prefix = prefixInput.value.trim().toLowerCase();
    const validation = validatePrefixInput(prefix);
    
    if (validation !== true) {
        showToast(validation);
        prefixInput.focus();
        return;
    }
    
    const btn = document.getElementById('bindBtn');
    const originalHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 绑定中...';
    
    $.ajax({
        url: 'api.php',
        type: 'POST',
        data: {
            type: 'create_domain',
            prefix: prefix,
            csrf_token: csrfToken
        },
        dataType: 'json',
        timeout: 60000,
        success: function(data) {
            showToast(data.msg);
            if (data.status === 1) {
                // 如果是 iframe 嵌入模式，通知父窗口（部署中心）刷新存储空间数据
                if (window.self !== window.top && window.parent) {
                    try {
                        window.parent.postMessage({ type: 'domain_bound' }, '*');
                    } catch (e) {
                        // 忽略跨域错误
                    }
                }
                setTimeout(() => loadStatus(), 800);
            } else {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
                if (data.msg && data.msg.indexOf('安全校验') !== -1) {
                    setTimeout(() => location.reload(), 1500);
                }
            }
        },
        error: function(xhr, status) {
            let msg = '刷新重试喵';
            if (status === 'timeout') msg = '请求超时了喵，请稍后刷新查看';
            else if (xhr.status === 429) msg = '操作太频繁了喵';
            else if (xhr.status === 403) msg = '刷新重试喵';
            showToast(msg);
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        }
    });
}
// 删除域名（三重确认）
function deleteDomain() {
    if (!confirm('亚美咯!')) return;
    if (!confirm('雅蠛蝶!')) return;
    if (!confirm('达咩达咩，域名会西内的喵')) return;
    
    $.ajax({
        url: 'api.php',
        type: 'POST',
        data: {
            type: 'delete_domain',
            csrf_token: csrfToken
        },
        dataType: 'json',
        timeout: 20000,
        success: function(data) {
            showToast(data.msg);
            if (data.status === 1) {
                setTimeout(() => loadStatus(), 800);
            }
        },
        error: function(xhr, status) {
            let msg = '删除失败了喵';
            if (status === 'timeout') msg = '请求超时了喵';
            showToast(msg);
        }
    });
}
// 初始化
document.addEventListener('DOMContentLoaded', function() {
    // 恢复侧边栏折叠状态（仅桌面端）
    if (window.innerWidth > 768 && localStorage.getItem('sb') === '1') {
        const sb = document.getElementById('sidebar');
        const icon = document.getElementById('collapseIcon');
        if (sb) sb.classList.add('collapsed');
        if (icon) {
            icon.classList.remove('fa-chevron-left');
            icon.classList.add('fa-chevron-right');
        }
    }
    loadStatus();
});
