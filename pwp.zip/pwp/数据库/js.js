/**
 * 数据库管理前端脚本
 * 安全特性：CSRF防护、XSS防护（escapeHtml）、密码本地显示控制
 * 双模式：standalone（独立页面）/ iframe-embed（被部署.php嵌入）
 */
(function() {
    'use strict';

    let csrfToken = window.csrfToken || '';
    let currentDb = null;
    let hasDomain = false;
    let _dbPassword = null;  // 修复 #5: 内存中存储密码，不从 HTML 获取

    // ===== 工具函数 =====
    function showToast(msg, duration) {
        duration = duration || 2500;
        var t = document.getElementById('toast');
        if (!t) return;
        t.textContent = msg;
        t.classList.add('show');
        setTimeout(function() { t.classList.remove('show'); }, duration);
    }

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // ===== 侧边栏控制 =====
    window.toggleMobileSidebar = function() {
        var sb = document.getElementById('sidebar');
        var ov = document.getElementById('overlay');
        if (!sb || !ov) return;
        sb.classList.toggle('open');
        ov.classList.toggle('show');
    };

    window.toggleCollapse = function() {
        var sb = document.getElementById('sidebar');
        var icon = document.getElementById('collapseIcon');
        if (!sb) return;
        if (window.innerWidth <= 768 && sb.classList.contains('open')) {
            sb.classList.remove('open');
            var ov = document.getElementById('overlay');
            if (ov) ov.classList.remove('show');
            return;
        }
        sb.classList.toggle('collapsed');
        if (icon) {
            if (sb.classList.contains('collapsed')) {
                icon.classList.remove('fa-chevron-left');
                icon.classList.add('fa-chevron-right');
                localStorage.setItem('sb', '1');
            } else {
                icon.classList.remove('fa-chevron-right');
                icon.classList.add('fa-chevron-left');
                localStorage.setItem('sb', '0');
            }
        }
    };

    // ===== 登出 =====
    window.logout = function() {
        if (!confirm('确定要退出登录吗？')) return;
        try {
            $.ajax({
                url: '/注册登录/api.php',
                type: 'POST',
                data: { type: 'logout' },
                dataType: 'json',
                timeout: 10000,
                success: function() { window.location.href = '/注册登录/注册登录.php'; },
                error: function() { window.location.href = '/注册登录/注册登录.php'; }
            });
        } catch (e) {
            window.location.href = '/注册登录/注册登录.php';
        }
    };

    // ===== 复制功能 =====
    window.copyToClipboard = function(text, btn) {
        if (!text && text !== 0) return;
        text = String(text);
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(function() {
                markCopied(btn);
            }).catch(function() { fallbackCopy(text, btn); });
        } else {
            fallbackCopy(text, btn);
        }
    };

    window.copyConnectionString = function() {
        function doCopy(pass) {
            var connStr = 'mysql://' + (window._dbUser || '') + ':' + (pass || '') + '@'
                + (window._dbHost || '') + ':' + (window._dbPort || '3306') + '/' + (window._dbName || '');
            var btn = document.querySelector('.db-connection-string .copy-btn-mini');
            copyToClipboard(connStr, btn);
        }
        fetchDbPassword(function(pass) { doCopy(pass); });
    };

    function fallbackCopy(text, btn) {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.cssText = 'position:fixed;opacity:0;pointer-events:none;';
        document.body.appendChild(textarea);
        textarea.select();
        try { document.execCommand('copy'); markCopied(btn); }
        catch (e) { showToast('复制失败，请手动复制'); }
        document.body.removeChild(textarea);
    }

    function markCopied(btn) {
        if (btn) {
            var orig = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-check"></i>';
            btn.classList.add('copied');
            setTimeout(function() {
                btn.innerHTML = orig;
                btn.classList.remove('copied');
            }, 1500);
        }
        showToast('已复制到剪贴板');
    }

    // ===== 密码获取（修复 #5: 一次性令牌 API） =====
    function fetchDbPassword(callback) {
        // 如果已经有密码缓存，直接使用
        if (_dbPassword !== null) {
            callback(_dbPassword);
            return;
        }
        // 通过一次性令牌从服务端获取密码
        var token = window._dbToken || '';
        if (!token) {
            callback('');
            return;
        }
        $.ajax({
            url: window.location.href,
            type: 'POST',
            data: {
                action: 'get_db_password',
                _db_token: token,
                csrf_token: csrfToken
            },
            dataType: 'json',
            timeout: 5000,
            success: function(res) {
                if (res.status === 1) {
                    _dbPassword = res.password || '';
                    callback(_dbPassword);
                } else {
                    callback('');
                }
            },
            error: function() {
                callback('');
            }
        });
    }

    // ===== 密码切换 =====
    window.togglePassword = function() {
        var display = document.getElementById('db-pass-display');
        var btn = document.getElementById('togglePassBtn');
        if (!display || !btn) return;
        if (display.classList.contains('password-mask')) {
            if (_dbPassword !== null) {
                display.textContent = _dbPassword || '未知';
                display.classList.remove('password-mask');
                display.classList.add('password-text');
                btn.innerHTML = '<i class="fas fa-eye-slash"></i>';
                btn.title = '隐藏';
            } else {
                // 首次点击：通过 API 获取密码
                fetchDbPassword(function(pass) {
                    display.textContent = pass || '未知';
                    display.classList.remove('password-mask');
                    display.classList.add('password-text');
                    btn.innerHTML = '<i class="fas fa-eye-slash"></i>';
                    btn.title = '隐藏';
                });
            }
        } else {
            display.textContent = '················';
            display.classList.remove('password-text');
            display.classList.add('password-mask');
            btn.innerHTML = '<i class="fas fa-eye"></i>';
            btn.title = '显示';
        }
    };

    // ===== 异步加载数据库状态 =====
    function loadStatus() {
        $.ajax({
            url: '../域名/api.php',
            type: 'POST',
            data: { type: 'check_database' },
            dataType: 'json',
            timeout: 10000,
            success: function(res) {
                if (res.status === 1) {
                    hasDomain = res.has_domain;
                    currentDb = res.database;
                    if (!hasDomain) {
                        renderNoDomain();
                    } else if (!currentDb) {
                        renderNoDatabase();
                    } else {
                        renderDatabaseInfo(currentDb);
                    }
                } else {
                    renderNoDomain();
                }
            },
            error: function() {
                renderNoDomain();
            }
        });
    }

    // ===== JS 渲染函数（PHP未输出内容时的回退方案）=====
    function renderNoDomain() {
        var c = document.getElementById('page-content');
        if (!c) return;
        c.innerHTML = '<h1 class="page-title">数据库管理</h1>' +
        '<div class="card" style="margin-bottom:0;">' +
        '<div class="no-domain-guide">' +
        '<div class="guide-icon-wrap"><i class="fas fa-database"></i></div>' +
        '<h2>还没有绑定域名</h2>' +
        '<p>绑定域名后，系统将自动为您创建专属的 MySQL 数据库，您可以在下方查看数据库连接信息。</p>' +
        '<div class="guide-steps">' +
        '<div class="guide-step"><span class="guide-step-num">1</span><span>前往二级域名页面</span></div>' +
        '<div class="guide-step-arrow"><i class="fas fa-chevron-right"></i></div>' +
        '<div class="guide-step"><span class="guide-step-num">2</span><span>输入域名前缀并绑定</span></div>' +
        '<div class="guide-step-arrow"><i class="fas fa-chevron-right"></i></div>' +
        '<div class="guide-step"><span class="guide-step-num">3</span><span>返回此页面查看数据库</span></div>' +
        '</div>' +
        '<a href="/域名/域名.php" class="btn-guide"><i class="fas fa-arrow-right"></i> 前往绑定域名</a>' +
        '</div></div>';
    }

    function renderNoDatabase() {
        var c = document.getElementById('page-content');
        if (!c) return;
        c.innerHTML = '<h1 class="page-title">数据库管理</h1>' +
        '<div class="card" style="margin-bottom:0;">' +
        '<div class="no-db-state">' +
        '<div class="no-db-icon-wrap"><i class="fas fa-database"></i></div>' +
        '<h3>暂无数据库</h3>' +
        '<p>您的域名尚未分配数据库，请删除域名后重新创建以自动获取数据库。</p>' +
        '<a href="/域名/域名.php" class="btn-guide"><i class="fas fa-globe"></i> 前往域名管理</a>' +
        '</div></div>';
    }

    function renderDatabaseInfo(db) {
        var c = document.getElementById('page-content');
        if (!c) return;
        var dbn = escapeHtml(db.db_name), dbu = escapeHtml(db.db_user);
        var dbh = escapeHtml(db.db_host), dbp = escapeHtml(db.db_port);
        var crt = escapeHtml(db.created_at);

        _dbPassword = db.db_pass || '';  // 修复 #5: 仅内存存储，不挂 window
        window._dbUser = dbu;
        window._dbHost = dbh;
        window._dbPort = dbp;
        window._dbName = dbn;

        c.innerHTML =
        '<h1 class="page-title">数据库管理</h1>' +
        '<div class="db-status-banner"><div class="db-status-dot"></div><span>数据库运行正常</span></div>' +
        '<div class="db-info-card-enhanced">' +
        '<div class="db-card-header">' +
        '<div class="db-card-icon"><i class="fas fa-database"></i></div>' +
        '<div class="db-card-title-group"><div class="db-card-title">数据库信息</div><div class="db-card-subtitle">MySQL 连接详情</div></div>' +
        '</div>' +
        '<div class="db-info-grid">' +
        '<div class="db-info-item">' +
        '<div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-tag" style="color:var(--primary);"></i></div>' +
        '<div class="db-info-item-content"><div class="db-info-item-label">数据库名</div><div class="db-info-item-value"><code>' + dbn + '</code><button class="copy-btn-mini" onclick="copyToClipboard(\'' + dbn + '\',this)" title="复制"><i class="fas fa-copy"></i></button></div></div>' +
        '</div>' +
        '<div class="db-info-item">' +
        '<div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-user" style="color:var(--primary);"></i></div>' +
        '<div class="db-info-item-content"><div class="db-info-item-label">用户名</div><div class="db-info-item-value"><code>' + dbu + '</code><button class="copy-btn-mini" onclick="copyToClipboard(\'' + dbu + '\',this)" title="复制"><i class="fas fa-copy"></i></button></div></div>' +
        '</div>' +
        '<div class="db-info-item">' +
        '<div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-key" style="color:var(--primary);"></i></div>' +
        '<div class="db-info-item-content"><div class="db-info-item-label">密码</div><div class="db-info-item-value"><code id="db-pass-display" class="password-mask">················</code><button class="copy-btn-mini" onclick="togglePassword()" title="显示" id="togglePassBtn"><i class="fas fa-eye"></i></button></div></div>' +
        '</div>' +
        '<div class="db-info-item">' +
        '<div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-server" style="color:var(--primary);"></i></div>' +
        '<div class="db-info-item-content"><div class="db-info-item-label">主机地址</div><div class="db-info-item-value"><code>' + dbh + '</code><button class="copy-btn-mini" onclick="copyToClipboard(\'' + dbh + '\',this)" title="复制"><i class="fas fa-copy"></i></button></div></div>' +
        '</div>' +
        '<div class="db-info-item">' +
        '<div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-plug" style="color:var(--primary);"></i></div>' +
        '<div class="db-info-item-content"><div class="db-info-item-label">端口</div><div class="db-info-item-value"><code>' + dbp + '</code><button class="copy-btn-mini" onclick="copyToClipboard(\'' + dbp + '\',this)" title="复制"><i class="fas fa-copy"></i></button></div></div>' +
        '</div>' +
        '<div class="db-info-item">' +
        '<div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-clock" style="color:var(--primary);"></i></div>' +
        '<div class="db-info-item-content"><div class="db-info-item-label">创建时间</div><div class="db-info-item-value" style="font-weight:600;font-size:14px;">' + crt + '</div></div>' +
        '</div>' +
        '</div>' +
        '<div class="db-card-footer">' +
        '<div class="db-connection-string"><i class="fas fa-link"></i><span>连接字符串</span><code>mysql://' + dbu + ':****@' + dbh + ':' + dbp + '/' + dbn + '</code><button class="copy-btn-mini" onclick="copyConnectionString()" title="复制"><i class="fas fa-copy"></i></button></div>' +
        '<div class="info-hint"><i class="fas fa-info-circle"></i><span>数据库空间限制为 30MB，请合理使用。</span></div>' +
        '</div></div>';
    }

    // ===== 初始化 =====
    document.addEventListener('DOMContentLoaded', function() {
        // 恢复侧边栏折叠状态（桌面端）
        if (window.innerWidth > 768 && localStorage.getItem('sb') === '1') {
            var sb = document.getElementById('sidebar');
            var icon = document.getElementById('collapseIcon');
            if (sb) sb.classList.add('collapsed');
            if (icon) { icon.classList.remove('fa-chevron-left'); icon.classList.add('fa-chevron-right'); }
        }

        // PHP已渲染内容时跳过异步加载
        if (window.pageRenderMode === 'loading') {
            loadStatus();
        }
    });

})();