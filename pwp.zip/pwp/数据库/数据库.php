<?php
/**
 * 数据库管理页面
 * 地址: /数据库/数据库.php
 * 未登录用户自动重定向到登录页
 * 安全特性: CSRF防护、XSS输出编码、密码仅在服务端解密
 * 
 * 支持两种模式:
 * - standalone: 独立页面，显示header+sidebar+content
 * - iframe-embed: iframe嵌入模式（被部署.php嵌入），仅显示内容卡片，无标题、无导航
 */
require_once __DIR__ . '/../注册登录/api.php';
if (!isAuthenticated()) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    header('Location: /注册登录/注册登录.php');
    exit;
}

$currentUser = [
    'name'  => htmlspecialchars($_SESSION['user']['name'] ?? '用户', ENT_QUOTES, 'UTF-8'),
    'email' => htmlspecialchars($_SESSION['user']['email'] ?? '', ENT_QUOTES, 'UTF-8'),
];
$userId = $_SESSION['user']['id'];

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// 修复 #5: 通过一次性令牌安全获取数据库密码（不写入 HTML）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'get_db_password') {
    header('Content-Type: application/json');
    $token = $_POST['_db_token'] ?? '';
    $storedToken = $_SESSION['_db_password_token'] ?? '';
    if (empty($token) || empty($storedToken) || !hash_equals($storedToken, $token)) {
        // 令牌无效或已过期
        unset($_SESSION['_db_password_token'], $_SESSION['_db_password_decrypted']);
        echo json_encode(['status' => 0, 'msg' => '令牌无效或已过期']);
        exit;
    }
    // 验证 CSRF
    $csrf = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $csrf)) {
        echo json_encode(['status' => 0, 'msg' => 'CSRF 验证失败']);
        exit;
    }
    $password = $_SESSION['_db_password_decrypted'] ?? '';
    // 一次性令牌：使用后立即销毁
    unset($_SESSION['_db_password_token'], $_SESSION['_db_password_decrypted']);
    echo json_encode(['status' => 1, 'password' => $password]);
    exit;
}

require_once __DIR__ . '/../secure_config.php';

function getDbSecret() {
    $secretFile = __DIR__ . '/../data/.db_secret';
    $secret = file_exists($secretFile) ? file_get_contents($secretFile) : null;
    if (!$secret || strlen($secret) < 32) {
        $secret = bin2hex(random_bytes(32));
        @mkdir(__DIR__ . '/../data', 0750, true);
        file_put_contents($secretFile, $secret, LOCK_EX);
        chmod($secretFile, 0600);
    }
    return substr(hash('sha256', $secret), 0, 32);
}
function decryptDbPass($ciphertext) {
    $key = getDbSecret();
    $data = base64_decode($ciphertext);
    if ($data === false || strlen($data) < 16) return null;
    $iv = substr($data, 0, 16);
    $encrypted = substr($data, 16);
    $decrypted = openssl_decrypt($encrypted, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return $decrypted !== false ? $decrypted : null;
}

$hasDomain = false;
$hasDatabase = false;
$dbInfo = null;
try {
    $pdo = createSecurePdo();
    $stmt = $pdo->prepare("SELECT * FROM domains WHERE user_id = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$userId]);
    $userDomain = $stmt->fetch();
    $hasDomain = !empty($userDomain);
    if ($hasDomain) {
        $stmtDb = $pdo->prepare("SELECT * FROM user_databases WHERE user_id = ? AND status = 'active' LIMIT 1");
        $stmtDb->execute([$userId]);
        $userDb = $stmtDb->fetch();
        $hasDatabase = !empty($userDb);
        if ($hasDatabase) {
            $dbPass = !empty($userDb['db_pass']) ? decryptDbPass($userDb['db_pass']) : '';
            $dbInfo = [
                'db_name'    => htmlspecialchars($userDb['db_name'], ENT_QUOTES, 'UTF-8'),
                'db_user'    => htmlspecialchars($userDb['db_user'], ENT_QUOTES, 'UTF-8'),
                'db_pass'    => $dbPass,
                'db_host'    => htmlspecialchars($userDb['db_host'] ?? 'localhost', ENT_QUOTES, 'UTF-8'),
                'db_port'    => (int)($userDb['db_port'] ?? 3306),
                'created_at' => htmlspecialchars($userDb['created_at'] ?? '', ENT_QUOTES, 'UTF-8'),
            ];
        }
    }
} catch (Exception $e) {
    $hasDomain = null;
}

$renderMode = 'loading';
if ($hasDomain === false) {
    $renderMode = 'no_domain';
} elseif ($hasDomain === true && $hasDatabase === false) {
    $renderMode = 'no_database';
} elseif ($hasDomain === true && $hasDatabase === true) {
    $renderMode = 'database_info';
    // 修复 #5: 生成一次性密码令牌，密码通过 API 获取而非写入 HTML
    $_SESSION['_db_password_token'] = bin2hex(random_bytes(16));
    $_SESSION['_db_password_decrypted'] = $dbPass;
}

// ---- 渲染函数 ----
function renderPageTitle() {
    echo '<h1 class="page-title">数据库管理</h1>';
}
function renderStatusBanner() {
    echo '<div class="db-status-banner"><div class="db-status-dot"></div><span>数据库运行正常</span></div>';
}
function renderDatabaseCard($dbInfo) {
    $name = $dbInfo['db_name']; $user = $dbInfo['db_user'];
    $host = $dbInfo['db_host']; $port = $dbInfo['db_port']; $created = $dbInfo['created_at'];
    $passJs = htmlspecialchars($dbInfo['db_pass'] ?? '', ENT_QUOTES, 'UTF-8');
    echo <<<HTML
<div class="db-info-card-enhanced">
    <div class="db-card-header">
        <div class="db-card-icon"><i class="fas fa-database"></i></div>
        <div class="db-card-title-group">
            <div class="db-card-title">数据库信息</div>
            <div class="db-card-subtitle">MySQL 连接详情</div>
        </div>
    </div>
    <div class="db-info-grid">
        <div class="db-info-item">
            <div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-tag" style="color:var(--primary);"></i></div>
            <div class="db-info-item-content">
                <div class="db-info-item-label">数据库名</div>
                <div class="db-info-item-value">
                    <code>{$name}</code>
                    <button class="copy-btn-mini" onclick="copyToClipboard('{$name}',this)" title="复制"><i class="fas fa-copy"></i></button>
                </div>
            </div>
        </div>
        <div class="db-info-item">
            <div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-user" style="color:var(--primary);"></i></div>
            <div class="db-info-item-content">
                <div class="db-info-item-label">用户名</div>
                <div class="db-info-item-value">
                    <code>{$user}</code>
                    <button class="copy-btn-mini" onclick="copyToClipboard('{$user}',this)" title="复制"><i class="fas fa-copy"></i></button>
                </div>
            </div>
        </div>
        <div class="db-info-item">
            <div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-key" style="color:var(--primary);"></i></div>
            <div class="db-info-item-content">
                <div class="db-info-item-label">密码</div>
                <div class="db-info-item-value">
                    <code id="db-pass-display" class="password-mask">················</code>
                    <button class="copy-btn-mini" onclick="togglePassword()" title="显示" id="togglePassBtn"><i class="fas fa-eye"></i></button>
                </div>
            </div>
        </div>
        <div class="db-info-item">
            <div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-server" style="color:var(--primary);"></i></div>
            <div class="db-info-item-content">
                <div class="db-info-item-label">主机地址</div>
                <div class="db-info-item-value"><code>{$host}</code>
                    <button class="copy-btn-mini" onclick="copyToClipboard('{$host}',this)" title="复制"><i class="fas fa-copy"></i></button>
                </div>
            </div>
        </div>
        <div class="db-info-item">
            <div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-plug" style="color:var(--primary);"></i></div>
            <div class="db-info-item-content">
                <div class="db-info-item-label">端口</div>
                <div class="db-info-item-value"><code>{$port}</code>
                    <button class="copy-btn-mini" onclick="copyToClipboard('{$port}',this)" title="复制"><i class="fas fa-copy"></i></button>
                </div>
            </div>
        </div>
        <div class="db-info-item">
            <div class="db-info-item-icon" style="background:#fff;border:1px solid var(--border);"><i class="fas fa-clock" style="color:var(--primary);"></i></div>
            <div class="db-info-item-content">
                <div class="db-info-item-label">创建时间</div>
                <div class="db-info-item-value" style="font-weight:600;font-size:14px;">{$created}</div>
            </div>
        </div>
    </div>
    <div class="db-card-footer">
        <div class="db-connection-string">
            <i class="fas fa-link"></i><span>连接字符串</span>
            <code>mysql://{$user}:****@{$host}:{$port}/{$name}</code>
            <button class="copy-btn-mini" onclick="copyConnectionString()" title="复制"><i class="fas fa-copy"></i></button>
        </div>
        <div class="info-hint">
            <i class="fas fa-info-circle"></i>
            <span>数据库空间限制为 30MB，请合理使用。</span>
        </div>
    </div>
</div>
HTML;
}
function renderNoDomain() {
    echo <<<HTML
<div class="card" style="margin-bottom:0;">
    <div class="no-domain-guide">
        <div class="guide-icon-wrap"><i class="fas fa-database"></i></div>
        <h2>还没有绑定域名</h2>
        <p>绑定域名后，系统将自动为您创建专属的 MySQL 数据库，您可以在下方查看数据库连接信息。</p>
        <div class="guide-steps">
            <div class="guide-step"><span class="guide-step-num">1</span><span>前往二级域名页面</span></div>
            <div class="guide-step-arrow"><i class="fas fa-chevron-right"></i></div>
            <div class="guide-step"><span class="guide-step-num">2</span><span>输入域名前缀并绑定</span></div>
            <div class="guide-step-arrow"><i class="fas fa-chevron-right"></i></div>
            <div class="guide-step"><span class="guide-step-num">3</span><span>返回此页面查看数据库</span></div>
        </div>
        <a href="/域名/域名.php" class="btn-guide"><i class="fas fa-arrow-right"></i> 前往绑定域名</a>
    </div>
</div>
HTML;
}
function renderNoDatabase() {
    echo <<<HTML
<div class="card" style="margin-bottom:0;">
    <div class="no-db-state">
        <div class="no-db-icon-wrap"><i class="fas fa-database"></i></div>
        <h3>暂无数据库</h3>
        <p>您的域名尚未分配数据库，请删除域名后重新创建以自动获取数据库。</p>
        <a href="/域名/域名.php" class="btn-guide"><i class="fas fa-globe"></i> 前往域名管理</a>
    </div>
</div>
HTML;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>数据库管理 - Miyo</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      integrity="sha384-t1nt8BQoYMLFN5p42tRAtuAAFQaCQODekUVeKKZrEnEyp4H2R0RHFz0KWpmj7i8g" crossorigin="anonymous">
<link rel="stylesheet" href="css.css">
</head>
<body class="standalone">
<script>
/** 首帧即判断嵌入模式，避免 FOUC（闪烁） */
(function() {
    if (window.self !== window.top) {
        document.body.className = 'iframe-embed';
    } else {
        document.body.className = 'standalone';
    }
})();
</script>
<div class="app">
    <div class="overlay" id="overlay" onclick="toggleMobileSidebar()"></div>
    <header class="header-bar">
        <div class="left">
            <button class="menu-toggle" id="menuToggle" onclick="toggleMobileSidebar()" aria-label="菜单"><i class="fas fa-bars"></i></button>
            <span class="title">miyo 数据库</span>
        </div>
        <div class="user-info">
            <span class="user-name"><?php echo $currentUser['name']; ?></span>
            <button class="logout-btn" onclick="logout()"><i class="fas fa-sign-out-alt"></i>退出</button>
        </div>
    </header>
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <button class="collapse-btn" onclick="toggleCollapse()" title="折叠"><i class="fas fa-chevron-left" id="collapseIcon"></i></button>
        </div>
        <nav class="sidebar-nav">
            <a href="/部署/部署.php" class="nav-item"><i class="fas fa-home"></i><span>概览</span></a>
            <a href="/域名/域名.php" class="nav-item"><i class="fas fa-globe"></i><span>二级域名</span></a>
            <a href="/SSL/ssl.html" class="nav-item"><i class="fas fa-lock"></i><span>SSL证书</span></a>
            <a href="javascript:void(0)" class="nav-item active" onclick="return false;"><i class="fas fa-database"></i><span>数据库</span></a>
            <a href="/文件/文件.php" class="nav-item"><i class="fas fa-folder"></i><span>文件管理</span></a>
            <a href="/文件/文件.php" class="nav-item"><i class="fas fa-server"></i><span>网站管理</span></a>
            <a href="/防护/防护.html" class="nav-item"><i class="fas fa-shield-alt"></i><span>安全防护</span></a>
        </nav>
        <div class="sidebar-footer">Miyo v3.0 · 免费网页托管</div>
    </aside>
    <main class="main-content" id="mainContent">
        <div class="content-wrapper" id="page-content">
            <?php
            if ($renderMode === 'no_domain') {
                renderPageTitle();
                renderNoDomain();
            } elseif ($renderMode === 'no_database') {
                renderPageTitle();
                renderNoDatabase();
            } elseif ($renderMode === 'database_info') {
                renderPageTitle();
                renderStatusBanner();
                renderDatabaseCard($dbInfo);
            } else {
                echo '<div class="loading-state"><i class="fas fa-spinner fa-spin"></i><p>加载中…</p></div>';
            }
            ?>
        </div>
    </main>
</div>
<div class="toast" id="toast"></div>
<script>
window.currentUser = <?php echo json_encode($currentUser); ?>;
window.csrfToken = "<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>";
window.pageRenderMode = "<?php echo $renderMode; ?>";
<?php if ($renderMode === 'database_info'): ?>
// 修复 #5: 不直接在 HTML 中暴露数据库密码，改用一次性令牌从服务端获取
window._dbToken = "<?php echo $_SESSION['_db_password_token'] ?? ''; ?>";
window._dbUser = "<?php echo $dbInfo['db_user']; ?>";
window._dbHost = "<?php echo $dbInfo['db_host']; ?>";
window._dbPort = "<?php echo $dbInfo['db_port']; ?>";
window._dbName = "<?php echo $dbInfo['db_name']; ?>";
<?php endif; ?>
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha384-1H217gwSVyLSIfaLxHbE7dRb3v4mYCKbpQvzx0cegeju1MVsGrX5xXxAvs/HgeFs" crossorigin="anonymous"></script>
<script src="js.js"></script>
</body>
</html>