<?php
/**
 * MiyoHost 统一安全初始化模块
 * ============================================================================
 * 用途：集中设置安全响应头、Session Cookie 安全属性，供所有页面统一引用
 * 
 * 修复项：
 *  - #10: 添加关键安全响应头 (CSP/HSTS/X-Content-Type/X-Frame/Referrer)
 *  - #11: 修复 Session Cookie 缺少 Secure/HttpOnly/SameSite 属性
 * ============================================================================
 */

/**
 * 设置安全 Session Cookie 参数
 * 必须在 session_start() 之前调用
 */
function initSecureSession() {
    // 检测是否 HTTPS
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
        || (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

    $cookieParams = [
        'lifetime' => 86400,            // 24 小时
        'path'     => '/',
        'domain'   => '',               // 当前域名
        'secure'   => $isHttps,         // 仅 HTTPS 传输
        'httponly' => true,             // 禁止 JavaScript 访问
        'samesite' => 'Lax',            // 防止 CSRF
    ];

    // PHP 7.3+ 支持 samesite 数组写法
    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params($cookieParams);
    } else {
        session_set_cookie_params(
            $cookieParams['lifetime'],
            $cookieParams['path'],
            $cookieParams['domain'],
            $cookieParams['secure'],
            $cookieParams['httponly']
        );
    }

    // 设置 Session 名称（避免默认 PHPSESSID 暴露技术栈）
    if (session_status() === PHP_SESSION_NONE) {
        session_name('MIYOSESSID');
        session_start();
    }

    // 补充：如果 PHP < 7.3 且需要 SameSite，通过 header 设置
    if (PHP_VERSION_ID < 70300) {
        $sameSite = 'Lax';
        $currentParams = session_get_cookie_params();
        $cookieValue = session_name() . '=' . session_id() . '; path=' . $currentParams['path']
            . ($currentParams['secure'] ? '; secure' : '')
            . '; httponly; SameSite=' . $sameSite;
        header('Set-Cookie: ' . $cookieValue);
    }
}

/**
 * 发送安全响应头
 * 在输出任何内容之前调用
 */
function sendSecurityHeaders() {
    // HSTS: 强制浏览器使用 HTTPS（一年有效期）
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
    }

    // 禁止 MIME 类型嗅探
    header('X-Content-Type-Options: nosniff');

    // 防止点击劫持（同源允许，iframe 嵌入自身页面）
    header('X-Frame-Options: SAMEORIGIN');

    // Referrer 策略：同源发送完整，跨域只发源
    header('Referrer-Policy: strict-origin-when-cross-origin');

    // 禁用浏览器 XSS 过滤器（已废弃但保留兼容）
    header('X-XSS-Protection: 0');

    // 内容安全策略 (CSP)
    // 允许本站、CDN、Google Fonts 等资源
    $csp = "default-src 'self'; "
         . "script-src 'self' 'unsafe-inline' 'unsafe-eval' "
         . "cdnjs.cloudflare.com cdn.bootcdn.net cdn.jsdelivr.net unpkg.com; "
         . "style-src 'self' 'unsafe-inline' "
         . "cdnjs.cloudflare.com cdn.bootcdn.net fonts.googleapis.com; "
         . "font-src 'self' cdnjs.cloudflare.com cdn.bootcdn.net fonts.gstatic.com; "
         . "img-src 'self' data: blob:; "
         . "connect-src 'self'; "
         . "frame-ancestors 'self'; "
         . "form-action 'self'; "
         . "base-uri 'self';";
    header('Content-Security-Policy: ' . $csp);

    // 权限策略：限制敏感 API
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}