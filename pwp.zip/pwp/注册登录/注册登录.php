<?php
require_once __DIR__ . '/api.php';

// 新增：仅在登录注册页面，已登录用户自动跳转到部署中心
if (isAuthenticated()) {
    header('Location: /部署/部署.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>登录您的Miyo账号 - Miyo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      integrity="sha384-t1nt8BQoYMLFN5p42tRAtuAAFQaCQODekUVeKKZrEnEyp4H2R0RHFz0KWpmj7i8g" crossorigin="anonymous">
    <link rel="stylesheet" href="css.css">
</head>
<body>
    <div class="header-bar">
        <a href="../index.html" class="back-btn"><i class="fas fa-chevron-left"></i></a>
        <span class="title">登录您的Miyo账号</span>
    </div>
    <div class="main-container">
        <div class="bg-grid"></div>
        <div class="logo-section">
            <img src="../logo1.png" alt="Logo">
            <h1></h1>
            <p></p>
        </div>
        <div class="tab-switch">
            <button class="active" onclick="switchTab('login')" id="tab-login-btn">登录</button>
            <button onclick="switchTab('register')" id="tab-register-btn">注册</button>
        </div>
        <!-- 登录表单 -->
        <div class="form-container" id="login-form">
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-user"></i>
                    <input type="text" id="login-identifier" placeholder="昵称" autocomplete="username">
                </div>
            </div>
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="login-password" placeholder="密码" autocomplete="current-password">
                </div>
            </div>
            <div class="form-group">
                <div class="captcha-row">
                    <div class="input-wrapper captcha-input">
                        <i class="fas fa-shield-alt"></i>
                        <input type="text" id="login-captcha" placeholder="验证码" maxlength="5" autocomplete="off">
                    </div>
                    <div class="captcha-img-wrap" id="loginCaptchaWrap" onclick="refreshCaptcha('login')">
                        <img id="loginCaptchaImg" src="" alt="验证码">
                        <div class="captcha-refresh-overlay"><i class="fas fa-sync-alt"></i></div>
                    </div>
                </div>
            </div>
            <button class="submit-btn" id="loginBtn" onclick="doLogin()">
                <i class="fas fa-sign-in-alt"></i>
                立即登录
            </button>
        </div>
        <!-- 注册表单 -->
        <div class="form-container" id="register-form" style="display:none;">
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-user"></i>
                    <input type="text" id="reg-name" placeholder="昵称" autocomplete="username">
                </div>
            </div>
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-envelope"></i>
                    <input type="email" id="reg-email" placeholder="邮箱" autocomplete="email">
                </div>
            </div>
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="reg-password" placeholder="密码" autocomplete="new-password">
                </div>
            </div>
            <div class="form-group">
                <div class="code-row">
                    <div class="input-wrapper">
                        <i class="fas fa-shield-alt"></i>
                        <input type="text" id="reg-code" placeholder="邮箱验证码">
                    </div>
                    <button class="code-btn" id="send-code-btn" onclick="sendCode()">获取验证码</button>
                </div>
            </div>
            <div class="form-group">
                <div class="captcha-row">
                    <div class="input-wrapper captcha-input">
                        <i class="fas fa-image"></i>
                        <input type="text" id="reg-captcha" placeholder="图片验证码" maxlength="5" autocomplete="off">
                    </div>
                    <div class="captcha-img-wrap" id="regCaptchaWrap" onclick="refreshCaptcha('reg')">
                        <img id="regCaptchaImg" src="" alt="验证码">
                        <div class="captcha-refresh-overlay"><i class="fas fa-sync-alt"></i></div>
                    </div>
                </div>
            </div>
            <button class="submit-btn" id="regBtn" onclick="doRegister()">
                <i class="fas fa-user-plus"></i>
                立即注册
            </button>
        </div>
        <div class="footer-hint">
            登录即表示您同意服务条款和隐私政策
        </div>
    </div>
    <div class="toast" id="toast"></div>

    <script src="https://cdn.bootcdn.net/ajax/libs/jquery/3.6.0/jquery.min.js"
        integrity="sha384-vtXRMe3mGCbOeY7l30aIg8H9p3GdeSe4IFlP6G8JMa7o7lXvnz3GFKzPxzJdPfGK" crossorigin="anonymous"></script>
    <script src="js.js"></script>
</body>
</html>
