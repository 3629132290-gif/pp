let countdown = 0;
function showToast(msg, duration = 2500) {
    const toast = document.getElementById('toast');
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, duration);
}
function switchTab(tab) {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const loginBtn = document.getElementById('tab-login-btn');
    const registerBtn = document.getElementById('tab-register-btn');
    if (tab === 'login') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        loginBtn.classList.add('active');
        registerBtn.classList.remove('active');
        refreshCaptcha('login');
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        loginBtn.classList.remove('active');
        registerBtn.classList.add('active');
        refreshCaptcha('reg');
    }
}
function refreshCaptcha(type) {
    const img = document.getElementById(type + 'CaptchaImg');
    const wrap = document.getElementById(type + 'CaptchaWrap');
    if (!img || !wrap) return;
    wrap.classList.add('loading');
    wrap.style.borderColor = '#e5e5e5';
    $.ajax({
        url: 'api.php?' + new Date().getTime(), // 加时间戳防缓存
        type: 'POST',
        data: { 
            type: 'get_captcha',
            captcha_type: type // 传递验证码类型，后端使用独立Session键
        },
        dataType: 'json',
        timeout: 10000,
        cache: false, // 强制不缓存
        success: function(res) {
            wrap.classList.remove('loading');
            if (res.status === 1 && res.data && res.data.img) {
                img.src = res.data.img;
                img.style.opacity = '1';
                wrap.title = '点击刷新验证码';
            } else {
                img.style.opacity = '0.3';
                wrap.title = res.msg || '验证码加载失败，点击重试';
                showToast(res.msg || '验证码加载失败');
                // 失败后自动重试一次
                setTimeout(() => refreshCaptcha(type), 1000);
            }
        },
        error: function(xhr, status, err) {
            wrap.classList.remove('loading');
            img.style.opacity = '0.3';
            let msg = '验证码加载失败';
            if (status === 'timeout') msg = '请求超时了喵';
            else if (xhr.status === 500) msg = '服务器过载了喵';
            else if (xhr.status === 0) msg = '连接不了服务器喵';
            wrap.title = msg + '，点击重试喵';
            showToast(msg + '，请刷新喵');
            // 失败后自动重试一次
            setTimeout(() => refreshCaptcha(type), 1500);
        }
    });
}
function doLogin() {
    const identifier = document.getElementById('login-identifier').value.trim();
    const password = document.getElementById('login-password').value.trim();
    const captcha = document.getElementById('login-captcha').value.trim();
    if (!identifier || !password) {
        showToast('请填写账号和密码喵');
        return;
    }
    if (!captcha) {
        showToast('验证码呢喵');
        document.getElementById('login-captcha').focus();
        return;
    }
    const btn = document.getElementById('loginBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>登录中...';
    $.ajax({
        url: 'api.php',
        type: 'POST',
        data: {
            type: 'login',
            identifier: identifier,
            password: password,
            captcha: captcha
        },
        dataType: 'json',
        timeout: 15000,
        success: function(data) {
            showToast(data.msg);
            if (data.status === 1) {
                setTimeout(() => {
                    window.location.href = '/部署/部署.php';
                }, 800);
            } else {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-sign-in-alt"></i>立即登录';
                refreshCaptcha('login');
                document.getElementById('login-captcha').value = '';
                document.getElementById('login-captcha').focus();
            }
        },
        error: function(xhr, status) {
            let msg = '验证码输错了喵';
            if (status === 'timeout') msg = '请求超时了喵';
            else if (xhr.status === 500) msg = '服务器好像出问题了喵';
            showToast(msg);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-sign-in-alt"></i>立即登录';
        }
    });
}
function sendCode() {
    const email = document.getElementById('reg-email').value.trim();
    if (!email) {
        showToast('请输入邮箱');
        return;
    }
    if (countdown > 0) return;
    $.ajax({
        url: 'api.php',
        type: 'POST',
        data: {
            type: 'send_reg_code',
            email: email
        },
        dataType: 'json',
        timeout: 15000,
        success: function(data) {
            showToast(data.msg);
            if (data.status === 1) {
                countdown = 60;
                const btn = document.getElementById('send-code-btn');
                btn.disabled = true;
                btn.textContent = countdown + '秒后重试';
                const timer = setInterval(function() {
                    countdown--;
                    btn.textContent = countdown + '秒后重试';
                    if (countdown <= 0) {
                        clearInterval(timer);
                        btn.disabled = false;
                        btn.textContent = '获取验证码';
                    }
                }, 1000);
            }
        },
        error: function(xhr, status) {
            let msg = '验证码输错了喵';
            if (status === 'timeout') msg = '请求超时了喵';
            else if (xhr.status === 500) msg = '服务器过载了喵';
            showToast(msg);
        }
    });
}
function doRegister() {
    const name = document.getElementById('reg-name').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const password = document.getElementById('reg-password').value.trim();
    const code = document.getElementById('reg-code').value.trim();
    const captcha = document.getElementById('reg-captcha').value.trim();
    if (!name || !email || !password || !code) {
        showToast('请填写注册信息喵');
        return;
    }
    if (name.length < 2 || name.length > 20) {
        showToast('昵称不合规范哦喵');
        return;
    }
    if (password.length < 6) {
        showToast('密码至少6位哦喵');
        return;
    }
    if (!captcha) {
        showToast('我的验证码呢喵');
        document.getElementById('reg-captcha').focus();
        return;
    }
    const btn = document.getElementById('regBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>注册中...';
    $.ajax({
        url: 'api.php',
        type: 'POST',
        data: {
            type: 'register',
            name: name,
            email: email,
            password: password,
            code: code,
            captcha: captcha
        },
        dataType: 'json',
        timeout: 15000,
        success: function(data) {
            showToast(data.msg);
            if (data.status === 1) {
                setTimeout(() => {
                    window.location.href = '/部署/部署.php';
                }, 800);
            } else {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-user-plus"></i>立即注册';
                refreshCaptcha('reg');
                document.getElementById('reg-captcha').value = '';
                document.getElementById('reg-captcha').focus();
            }
        },
        error: function(xhr, status) {
            let msg = '验证码输错了喵';
            if (status === 'timeout') msg = '请求超时了喵';
            else if (xhr.status === 500) msg = '服务器过载了喵';
            showToast(msg);
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-user-plus"></i>立即注册';
        }
    });
}
document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        const loginForm = document.getElementById('login-form');
        if (loginForm.style.display !== 'none') {
            doLogin();
        } else {
            doRegister();
        }
    }
});
document.addEventListener('DOMContentLoaded', function() {
    // 页面加载时只加载当前显示的登录验证码，避免并发冲突
    refreshCaptcha('login');
});
