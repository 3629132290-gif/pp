<?php
// 修复 #10 & #11: 统一安全响应头 + Session Cookie 安全属性
require_once __DIR__ . '/../security_headers.php';
initSecureSession();
sendSecurityHeaders();
// 先清理所有可能的输出（解决BOM头/提前输出破坏base64问题）
ob_clean();
error_reporting(E_ALL);
ini_set('display_errors', 0);
// 禁止浏览器缓存验证码
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
// ==================== 数据库配置（安全加载） ====================
// 修复 C-01: 数据库凭据不再硬编码，通过安全配置加载器读取
require_once __DIR__ . '/../secure_config.php';
try {
    $pdo = createSecurePdo();
} catch (RuntimeException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => -1, 'msg' => '数据库配置未就绪，请联系管理员']);
    exit;
} catch (PDOException $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => -1, 'msg' => '数据库连接失败']);
    exit;
}
// 建表（容错）
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(32) PRIMARY KEY,
        name VARCHAR(20) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        reg_time DATETIME NOT NULL,
        storage_quota BIGINT NOT NULL DEFAULT 102400,
        storage_expires DATETIME DEFAULT NULL,
        INDEX idx_email (email),
        INDEX idx_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // 兼容旧表：如果 users 表已存在但缺少 storage_quota 列，则自动添加
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN storage_quota BIGINT NOT NULL DEFAULT 102400");
    } catch (PDOException $e) {
        // 列已存在时忽略错误 (Duplicate column)
    }
    // 兼容旧表：添加 storage_expires 列（存储配额过期时间）
    try {
        $pdo->exec("ALTER TABLE users ADD COLUMN storage_expires DATETIME DEFAULT NULL");
    } catch (PDOException $e) {
        // 列已存在时忽略错误
    }
    $pdo->exec("CREATE TABLE IF NOT EXISTS ip_blacklist (
        ip VARCHAR(45) PRIMARY KEY,
        time INT NOT NULL,
        until INT NOT NULL,
        reason VARCHAR(100) NOT NULL,
        count INT DEFAULT 1
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS rate_limit (
        ip VARCHAR(45) NOT NULL,
        action VARCHAR(30) NOT NULL,
        count INT DEFAULT 0,
        window_start INT NOT NULL,
        violations INT DEFAULT 0,
        PRIMARY KEY (ip, action)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS security_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        time DATETIME DEFAULT CURRENT_TIMESTAMP,
        ip VARCHAR(45) NOT NULL,
        message TEXT NOT NULL,
        INDEX idx_time (time)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // 修复 #20: 登录/验证码失败计数从 Session 迁移到数据库
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
        ip VARCHAR(45) NOT NULL,
        attempt_type VARCHAR(20) NOT NULL DEFAULT 'login',
        count INT DEFAULT 0,
        first_attempt INT NOT NULL,
        last_attempt INT NOT NULL,
        PRIMARY KEY (ip, attempt_type),
        INDEX idx_last_attempt (last_attempt)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (PDOException $e) {
    // 表创建失败不阻断，记录即可
}
// 修复 C-02: SMTP 配置通过安全加载器获取，不再从明文 config.php 读取
$config = SecureConfig::getInstance()->getSmtpConfig();
// ==================== 配置 ====================
$GLOBALS['RATE_LIMIT_CONFIG'] = [
    'login'         => [20, 60],
    'login_fail'    => [15, 3600],
    'register'      => [10, 3600],
    'visit_record'  => [30, 60],    // 修复 #17: 访问记录接口频率限制
    'send_code'     => [10, 60],
    'site_create'   => [20, 60],
    'site_delete'   => [20, 60],
    'file_upload'   => [50, 60],
    'file_edit'     => [100, 60],
    'domain_apply'  => [10, 3600],
    'admin_action'  => [100, 60],
    'default'       => [200, 60],
];
$GLOBALS['AUTO_BLACKLIST_RULES'] = [
    'rate_limit'    => [20, 86400, '频繁触发频率限制'],
    'login_fail'    => [15, 3600, '登录失败次数过多'],
    'captcha_fail'  => [20, 3600, '验证码校验失败次数过多'],
];
// ==================== 工具函数 ====================
// 修复 H-05: 默认仅信任 REMOTE_ADDR，防止 IP 伪造
// 仅在明确配置反向代理时才信任代理头
function getClientIP() {
    // 如果使用 Cloudflare，设置环境变量 TRUST_CF_IP=true
    if (getenv('TRUST_CF_IP') === 'true' && !empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = trim(explode(',', $_SERVER['HTTP_CF_CONNECTING_IP'])[0]);
        if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
    }
    // 默认只信任 REMOTE_ADDR（不可伪造）
    if (!empty($_SERVER['REMOTE_ADDR'])) {
        $ip = trim($_SERVER['REMOTE_ADDR']);
        if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
    }
    return '0.0.0.0';
}
function securityLog($msg) {
    global $pdo;
    try {
        $stmt = $pdo->prepare("INSERT INTO security_logs (ip, message) VALUES (?, ?)");
        $stmt->execute([getClientIP(), $msg]);
    } catch (PDOException $e) {
        // 忽略日志写入失败
    }
}
// ==================== 会话安全工具 ====================
function generateAuthToken($userId) {
    // 使用服务器端密钥 + 会话ID + 用户ID + 时间戳生成不可伪造的签名
    $secret = defined('AUTH_SECRET') ? AUTH_SECRET : (file_exists(__DIR__ . '/../data/.auth_secret') 
        ? file_get_contents(__DIR__ . '/../data/.auth_secret') 
        : null);
    if (!$secret) {
        $secret = bin2hex(random_bytes(32));
        @mkdir(__DIR__ . '/../data', 0750, true);
        file_put_contents(__DIR__ . '/../data/.auth_secret', $secret, LOCK_EX);
        chmod(__DIR__ . '/../data/.auth_secret', 0600);
    }
    $time = time();
    $payload = session_id() . '|' . $userId . '|' . $time;
    $sig = hash_hmac('sha256', $payload, $secret);
    return $sig . '|' . $time;
}

function verifyAuthToken($token, $userId) {
    if (empty($token) || strpos($token, '|') === false) return false;
    list($sig, $time) = explode('|', $token, 2);
    if (!is_numeric($time) || $time < 1) return false;
    // Token 24小时过期
    if (time() - (int)$time > 86400) return false;
    $secret = defined('AUTH_SECRET') ? AUTH_SECRET : (file_exists(__DIR__ . '/../data/.auth_secret') 
        ? file_get_contents(__DIR__ . '/../data/.auth_secret') 
        : null);
    if (!$secret) return false;
    $payload = session_id() . '|' . $userId . '|' . $time;
    $expected = hash_hmac('sha256', $payload, $secret);
    return hash_equals($expected, $sig);
}

function isAuthenticated() {
    if (empty($_SESSION['user']) || empty($_SESSION['user']['id']) || empty($_SESSION['auth_token'])) {
        return false;
    }
    return verifyAuthToken($_SESSION['auth_token'], $_SESSION['user']['id']);
}

function requireAuth() {
    if (!isAuthenticated()) {
        // 清除可能损坏的会话数据
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }
        session_destroy();
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => -1, 'msg' => '登录已过期，请重新登录']);
        exit;
    }
}

function setAuthenticatedSession($user) {
    // 防止会话固定攻击
    session_regenerate_id(true);
    $_SESSION['user'] = $user;
    $_SESSION['auth_token'] = generateAuthToken($user['id']);
    $_SESSION['auth_ip'] = getClientIP();
    $_SESSION['auth_time'] = time();
}

function clearAuthenticatedSession() {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'],
            $params['secure'], $params['httponly']
        );
    }
    session_destroy();
}
// ==================== IP黑名单 ====================
function isIPBlacklisted($ip = null) {
    global $pdo;
    if ($ip === null) $ip = getClientIP();
    try {
        $stmt = $pdo->prepare("SELECT * FROM ip_blacklist WHERE ip = ?");
        $stmt->execute([$ip]);
        $row = $stmt->fetch();
        if (!$row) return false;
        if ($row['until'] == 0 || $row['until'] > time()) {
            return true;
        }
        $pdo->prepare("DELETE FROM ip_blacklist WHERE ip = ?")->execute([$ip]);
    } catch (PDOException $e) {
        return false;
    }
    return false;
}
function blacklistIP($ip = null, $duration = 3600, $reason = '自动拉黑') {
    global $pdo;
    if ($ip === null) $ip = getClientIP();
    try {
        $stmt = $pdo->prepare("INSERT INTO ip_blacklist (ip, time, until, reason, count) 
            VALUES (?, ?, ?, ?, 1)
            ON DUPLICATE KEY UPDATE 
            time = VALUES(time), until = VALUES(until), reason = VALUES(reason), count = count + 1");
        $until = $duration === 0 ? 0 : time() + $duration;
        $stmt->execute([$ip, time(), $until, $reason]);
        securityLog("IP拉黑: {$ip}, 原因: {$reason}, 时长: {$duration}秒");
    } catch (PDOException $e) {
        // 忽略
    }
}
function checkIPBlacklist() {
    $ip = getClientIP();
    if (isIPBlacklisted($ip)) {
        global $pdo;
        $info = [];
        try {
            $stmt = $pdo->prepare("SELECT * FROM ip_blacklist WHERE ip = ?");
            $stmt->execute([$ip]);
            $info = $stmt->fetch();
        } catch (PDOException $e) {
            $info = ['until' => 0, 'reason' => '未知'];
        }
        $remain = ($info['until'] ?? 0) == 0 ? '永久' : ceil((($info['until'] ?? time()) - time()) / 60) . '分钟';
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => -1, 'msg' => "访问受限，剩余: {$remain}，原因: " . ($info['reason'] ?? '未知')]);
        exit;
    }
}
checkIPBlacklist();
// ==================== 频率限制 ====================
function checkRateLimit($action = 'default', $ip = null) {
    global $pdo;
    if ($ip === null) $ip = getClientIP();
    if ($ip === '127.0.0.1' || $ip === '::1') return true;
    $config = $GLOBALS['RATE_LIMIT_CONFIG'][$action] ?? $GLOBALS['RATE_LIMIT_CONFIG']['default'];
    list($maxRequests, $window) = $config;
    $now = time();
    try {
        $stmt = $pdo->prepare("SELECT * FROM rate_limit WHERE ip = ? AND action = ?");
        $stmt->execute([$ip, $action]);
        $row = $stmt->fetch();
        if (!$row) {
            $pdo->prepare("INSERT INTO rate_limit (ip, action, count, window_start, violations) VALUES (?, ?, 1, ?, 0)")
                ->execute([$ip, $action, $now]);
            return true;
        }
        if ($now - $row['window_start'] > $window) {
            $pdo->prepare("UPDATE rate_limit SET count = 1, window_start = ?, violations = ? WHERE ip = ? AND action = ?")
                ->execute([$now, $row['violations'], $ip, $action]);
            return true;
        }
        $newCount = $row['count'] + 1;
        if ($newCount > $maxRequests) {
            $newViolations = $row['violations'] + 1;
            $pdo->prepare("UPDATE rate_limit SET count = ?, violations = ? WHERE ip = ? AND action = ?")
                ->execute([$newCount, $newViolations, $ip, $action]);
            $rule = $GLOBALS['AUTO_BLACKLIST_RULES']['rate_limit'];
            if ($newViolations >= $rule[0]) {
                blacklistIP($ip, $rule[1], $rule[2]);
            }
            securityLog("频率限制触发: {$action}, IP: {$ip}");
            return false;
        }
        $pdo->prepare("UPDATE rate_limit SET count = ? WHERE ip = ? AND action = ?")
            ->execute([$newCount, $ip, $action]);
        return true;
    } catch (PDOException $e) {
        return true; // 数据库故障时不阻断正常请求
    }
}
function enforceRateLimit($action = 'default') {
    if (!checkRateLimit($action)) {
        http_response_code(429);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => -1, 'msg' => '请求过于频繁，请稍后再试']);
        exit;
    }
}
// 修复 #20: 登录/验证码失败计数使用数据库存储，不受浏览器 Cookie 清除影响
function recordLoginFailure($ip = null, $type = 'login') {
    if ($ip === null) $ip = getClientIP();
    global $pdo;
    $now = time();
    $rule = $GLOBALS['AUTO_BLACKLIST_RULES'][$type === 'captcha' ? 'captcha_fail' : 'login_fail'];
    try {
        // 清理过期的失败记录（超过窗口期）
        $pdo->prepare("DELETE FROM login_attempts WHERE last_attempt < ?")
            ->execute([$now - $rule[1]]);
        // 插入或更新计数
        $stmt = $pdo->prepare(
            "INSERT INTO login_attempts (ip, attempt_type, count, first_attempt, last_attempt) 
             VALUES (?, ?, 1, ?, ?) 
             ON DUPLICATE KEY UPDATE 
             count = IF(last_attempt > ?, count + 1, 1),
             first_attempt = IF(last_attempt > ?, first_attempt, ?),
             last_attempt = ?"
        );
        $stmt->execute([$ip, $type, $now, $now, $now - $rule[1], $now - $rule[1], $now, $now]);
        // 检查是否超过阈值
        $stmt = $pdo->prepare("SELECT count FROM login_attempts WHERE ip = ? AND attempt_type = ?");
        $stmt->execute([$ip, $type]);
        $result = $stmt->fetch();
        if ($result && (int)$result['count'] >= $rule[0]) {
            blacklistIP($ip, $rule[1], $rule[2]);
            $pdo->prepare("DELETE FROM login_attempts WHERE ip = ? AND attempt_type = ?")
                ->execute([$ip, $type]);
        }
    } catch (PDOException $e) {
        // 数据库故障时降级为不阻断请求
    }
}
function clearLoginFailure($ip = null, $type = 'login') {
    if ($ip === null) $ip = getClientIP();
    global $pdo;
    try {
        $pdo->prepare("DELETE FROM login_attempts WHERE ip = ? AND attempt_type = ?")
            ->execute([$ip, $type]);
    } catch (PDOException $e) {
        // 忽略
    }
}
// ==================== 图片验证码（修复并发冲突版） ====================
function generateImageCaptcha($captchaType = 'default') {
    if (!extension_loaded('gd')) {
        return ['error' => '服务器GD库未安装，请联系管理员'];
    }
    $width = 160;
    $height = 60;
    $codeLen = 5;
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 移除易混淆字符
    $code = '';
    for ($i = 0; $i < $codeLen; $i++) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    // 强制清理缓冲区，防止任何提前输出破坏图片
    ob_clean();
    $img = imagecreatetruecolor($width, $height);
    if (!$img) {
        return ['error' => '图像创建失败'];
    }
    $bg = imagecolorallocate($img, 245, 245, 245);
    imagefill($img, 0, 0, $bg);
    // 背景噪点
    for ($i = 0; $i < 800; $i++) {
        $color = imagecolorallocate($img, random_int(180, 240), random_int(180, 240), random_int(180, 240));
        imagesetpixel($img, random_int(0, $width - 1), random_int(0, $height - 1), $color);
    }
    // 干扰线
    for ($i = 0; $i < 8; $i++) {
        $color = imagecolorallocate($img, random_int(100, 200), random_int(100, 200), random_int(100, 200));
        imageline($img, random_int(0, $width), random_int(0, $height), random_int(0, $width), random_int(0, $height), $color);
    }
    // 干扰弧线
    for ($i = 0; $i < 4; $i++) {
        $color = imagecolorallocatealpha($img, random_int(100, 180), random_int(100, 180), random_int(100, 180), 80);
        imagearc($img, random_int(0, $width), random_int(0, $height), random_int(80, 160), random_int(40, 80), random_int(0, 360), random_int(0, 360), $color);
    }
    // 文字绘制（修复字体缺失问题，自动降级）
    $fontFile = __DIR__ . '/../data/security/font.ttf';
    $hasTtf = file_exists($fontFile) && is_readable($fontFile);
    for ($i = 0; $i < $codeLen; $i++) {
        $char = $code[$i];
        $size = rand(20, 28);
        $angle = rand(-35, 35);
        $x = 15 + $i * 28 + rand(-5, 5);
        $y = 40 + rand(-8, 8);
        $color = imagecolorallocate($img, rand(30, 100), rand(30, 100), rand(30, 100));
        
        if ($hasTtf) {
            @imagettftext($img, $size, $angle, $x, $y, $color, $fontFile, $char);
        } else {
            imagestring($img, 5, $x, $y - 15, $char, $color);
        }
    }
    // 前景噪点
    for ($i = 0; $i < 300; $i++) {
        $color = imagecolorallocatealpha($img, random_int(50, 150), random_int(50, 150), random_int(50, 150), 60);
        imagesetpixel($img, random_int(0, $width - 1), random_int(0, $height - 1), $color);
    }
    // 模糊效果
    $tmp = imagecreatetruecolor($width - 1, $height - 1);
    if ($tmp) {
        imagecopy($tmp, $img, 0, 0, 0, 0, $width - 1, $height - 1);
        imagecopymerge($img, $tmp, 1, 1, 0, 0, $width - 1, $height - 1, 30);
        imagedestroy($tmp);
    }
    // 保存验证码到session（使用独立键名，彻底解决并发覆盖问题）
    $_SESSION[$captchaType . '_image_captcha'] = $code;
    $_SESSION[$captchaType . '_image_captcha_time'] = time();
    // 生成base64图片（确保无多余输出）
    ob_start();
    imagepng($img);
    $data = ob_get_clean();
    imagedestroy($img);
    if (empty($data)) {
        return ['error' => '图像编码失败'];
    }
    return [
        'img' => 'data:image/png;base64,' . base64_encode($data)
    ];
}
function verifyImageCaptcha($input, $captchaType = 'default') {
    if (!isset($_SESSION[$captchaType . '_image_captcha']) || !isset($_SESSION[$captchaType . '_image_captcha_time'])) {
        return false;
    }
    if (time() - $_SESSION[$captchaType . '_image_captcha_time'] > 300) {
        unset($_SESSION[$captchaType . '_image_captcha'], $_SESSION[$captchaType . '_image_captcha_time']);
        return false;
    }
    $result = strtoupper($input) === strtoupper($_SESSION[$captchaType . '_image_captcha']);
    if ($result) {
        unset($_SESSION[$captchaType . '_image_captcha'], $_SESSION[$captchaType . '_image_captcha_time']);
    }
    return $result;
}
function enforceImageCaptcha($input, $captchaType = 'default') {
    if (empty($input)) {
        http_response_code(400);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 0, 'msg' => '请输入验证码']);
        exit;
    }
    if (!verifyImageCaptcha($input, $captchaType)) {
        $ip = getClientIP();
        // 修复 #20: 使用数据库记录验证码失败，不再依赖 Session
        recordLoginFailure($ip, 'captcha');
        http_response_code(400);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status' => 0, 'msg' => '验证码错误，请重试']);
        exit;
    }
}
// ==================== 密码工具 ====================
function verifyPassword($plainPassword, $storedHash) {
    if (password_verify($plainPassword, $storedHash)) {
        return true;
    }
    if (preg_match('/^[a-f0-9]{32}$/i', $storedHash) && md5($plainPassword) === $storedHash) {
        return 'legacy';
    }
    if (password_verify(md5($plainPassword), $storedHash)) {
        return 'legacy';
    }
    return false;
}
function hashPassword($plainPassword) {
    return password_hash($plainPassword, PASSWORD_BCRYPT);
}
function checkCodeFrequency() {
    $now = time();
    if (isset($_SESSION['last_code_time']) && ($now - $_SESSION['last_code_time']) < 60) {
        $wait = 60 - ($now - $_SESSION['last_code_time']);
        return ['allowed' => false, 'msg' => "请等待 {$wait} 秒后再试"];
    }
    $today = date('Y-m-d');
    if (!isset($_SESSION['code_send_count']) || $_SESSION['code_send_date'] !== $today) {
        $_SESSION['code_send_count'] = 0;
        $_SESSION['code_send_date'] = $today;
    }
    if ($_SESSION['code_send_count'] >= 10) {
        return ['allowed' => false, 'msg' => '今日验证码发送次数已达上限，请明天再试'];
    }
    return ['allowed' => true];
}
function recordCodeSent() {
    $_SESSION['last_code_time'] = time();
    $_SESSION['code_send_count'] = ($_SESSION['code_send_count'] ?? 0) + 1;
}
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
// ==================== API 路由 ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['type'])) {
    header('Content-Type: application/json; charset=utf-8');
    $type = $_POST['type'];
    if ($type === 'get_captcha') {
        $captchaType = $_POST['captcha_type'] ?? 'default';
        $data = generateImageCaptcha($captchaType);
        if (isset($data['error'])) {
            echo json_encode(['status' => 0, 'msg' => $data['error']]);
        } else {
            echo json_encode(['status' => 1, 'data' => $data]);
        }
        exit;
    }
    if ($type === 'login') {
        enforceRateLimit('login');
        enforceImageCaptcha($_POST['captcha'] ?? '', 'login');
        $identifier = trim($_POST['identifier'] ?? '');
        $password = trim($_POST['password'] ?? '');
        if (empty($identifier) || empty($password)) {
            echo json_encode(['status' => 0, 'msg' => '请填写完整账号密码']);
            exit;
        }
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE name = ? OR email = ?");
            $stmt->execute([$identifier, $identifier]);
            $user = $stmt->fetch();
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '数据库查询失败']);
            exit;
        }
        if ($user) {
            $verifyResult = verifyPassword($password, $user['password']);
            if ($verifyResult !== false) {
                if ($verifyResult === 'legacy') {
                    try {
                        $newHash = hashPassword($password);
                        $pdo->prepare("UPDATE users SET password = ? WHERE id = ?")
                            ->execute([$newHash, $user['id']]);
                    } catch (PDOException $e) {
                        // 忽略密码升级失败
                    }
                }
                setAuthenticatedSession($user);
                clearLoginFailure();
                securityLog("用户登录成功: " . $user['email']);
                echo json_encode(['status' => 1, 'msg' => '登录成功，正在跳转...']);
                exit;
            }
        }
        recordLoginFailure();
        securityLog("登录失败: {$identifier}");
        echo json_encode(['status' => 0, 'msg' => '账号或密码错误']);
        exit;
    }
    if ($type === 'register') {
        enforceRateLimit('register');
        enforceImageCaptcha($_POST['captcha'] ?? '', 'reg');
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $code = trim($_POST['code'] ?? '');
        if (empty($name) || empty($email) || empty($password) || empty($code)) {
            echo json_encode(['status' => 0, 'msg' => '请填写完整注册信息']);
            exit;
        }
        if (mb_strlen($name, 'UTF-8') < 2 || mb_strlen($name, 'UTF-8') > 20) {
            echo json_encode(['status' => 0, 'msg' => '昵称长度应为2-20个字符']);
            exit;
        }
        if (strlen($password) < 6) {
            echo json_encode(['status' => 0, 'msg' => '密码至少6位']);
            exit;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['status' => 0, 'msg' => '请输入有效的邮箱地址']);
            exit;
        }
        if (!isset($_SESSION['reg_code']) || !isset($_SESSION['reg_code_time']) || !isset($_SESSION['reg_code_email'])) {
            echo json_encode(['status' => 0, 'msg' => '请先获取验证码']);
            exit;
        }
        if ($_SESSION['reg_code_email'] !== $email) {
            echo json_encode(['status' => 0, 'msg' => '验证码与邮箱不匹配']);
            exit;
        }
        if (time() - $_SESSION['reg_code_time'] > 600) {
            echo json_encode(['status' => 0, 'msg' => '验证码已过期，请重新获取']);
            exit;
        }
        if (strtoupper($code) !== strtoupper($_SESSION['reg_code'])) {
            echo json_encode(['status' => 0, 'msg' => '验证码错误']);
            exit;
        }
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? OR name = ? LIMIT 1");
            $stmt->execute([$email, $name]);
            if ($stmt->fetch()) {
                echo json_encode(['status' => 0, 'msg' => '该邮箱或昵称已被使用']);
                exit;
            }
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '数据库查询失败']);
            exit;
        }
        $newUser = [
            'id' => uniqid(),
            'name' => $name,
            'email' => $email,
            'password' => hashPassword($password),
            'reg_time' => date('Y-m-d H:i:s')
        ];
        try {
            $stmt = $pdo->prepare("INSERT INTO users (id, name, email, password, reg_time) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$newUser['id'], $newUser['name'], $newUser['email'], $newUser['password'], $newUser['reg_time']])) {
                unset($_SESSION['reg_code'], $_SESSION['reg_code_time'], $_SESSION['reg_code_email']);
                setAuthenticatedSession($newUser);
                securityLog("用户注册成功: {$email}");
                echo json_encode(['status' => 1, 'msg' => '注册成功，正在跳转...']);
            } else {
                echo json_encode(['status' => 0, 'msg' => '注册失败']);
            }
        } catch (PDOException $e) {
            // 修复 #8: 不暴露数据库异常详情给客户端
            securityLog("注册DB异常: " . $e->getMessage());
            echo json_encode(['status' => 0, 'msg' => '注册失败，请稍后重试']);
        }
        exit;
    }
    if ($type === 'send_reg_code') {
        enforceRateLimit('send_code');
        $email = trim($_POST['email'] ?? '');
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['status' => 0, 'msg' => '请输入有效的邮箱地址']);
            exit;
        }
        $freqCheck = checkCodeFrequency();
        if (!$freqCheck['allowed']) {
            echo json_encode(['status' => 0, 'msg' => $freqCheck['msg']]);
            exit;
        }
        try {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                echo json_encode(['status' => 0, 'msg' => '该邮箱已注册']);
                exit;
            }
        } catch (PDOException $e) {
            echo json_encode(['status' => 0, 'msg' => '数据库查询失败']);
            exit;
        }
        $code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $_SESSION['reg_code'] = $code;
        $_SESSION['reg_code_time'] = time();
        $_SESSION['reg_code_email'] = $email;
        $smtpUser = $config['user'] ?? '';
        $smtpPass = $config['pass'] ?? '';
        $smtpHost = $config['host'] ?? 'smtp.qq.com';
        $smtpPort = $config['port'] ?? 587;
        if (empty($smtpPass)) {
            echo json_encode(['status' => 0, 'msg' => '邮件服务未配置，请联系管理员']);
            exit;
        }
        // 延迟加载 PHPMailer（避免 get_captcha 等请求因缺少此库而崩溃）
        $phpmailerDir = __DIR__ . '/../phpmailer/src';
        if (!is_dir($phpmailerDir) || !file_exists($phpmailerDir . '/PHPMailer.php')) {
            echo json_encode(['status' => 0, 'msg' => '邮件服务组件缺失']);
            exit;
        }
        require $phpmailerDir . '/Exception.php';
        require $phpmailerDir . '/PHPMailer.php';
        require $phpmailerDir . '/SMTP.php';
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = $smtpHost;
            $mail->SMTPAuth   = true;
            $mail->Username   = $smtpUser;
            $mail->Password   = $smtpPass;
            $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = $smtpPort;
            $mail->CharSet    = 'UTF-8';
            $mail->Timeout    = 15;
            $mail->Timelimit  = 15;
            $mail->SMTPDebug  = 0;
            // 修复 SMTP SSL 证书验证：启用验证，不再完全禁用
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer' => true,
                    'verify_peer_name' => true,
                    'allow_self_signed' => false
                ]
            ];
            $mail->setFrom($smtpUser, 'Miyo网站托管平台');
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Miyo平台注册验证码';
            $mail->Body    = "
            <div style='font-family: 微软雅黑, sans-serif; max-width: 600px; margin: 0 auto;'>
                <h3>您好！</h3>
                <p>您正在注册Miyo免费网站托管平台，本次注册验证码为：</p>
                <h2 style='color: #0a0a0a; letter-spacing: 8px; margin: 20px 0;'>{$code}</h2>
                <p>验证码10分钟内有效，请勿泄露给他人。如非本人操作，请忽略此邮件。</p>
                <hr style='border: none; border-top: 1px solid #eee; margin: 20px 0;' />
                <p style='color: #999; font-size: 12px;'>Miyo免费网站托管平台</p>
            </div>
            ";
            $mail->AltBody = "您的Miyo平台注册验证码是：{$code}，10分钟内有效，请勿泄露给他人。";
            $mail->send();
            recordCodeSent();
            securityLog("验证码发送成功: {$email}");
            echo json_encode(['status' => 1, 'msg' => '验证码已发送至您的邮箱，请注意查收']);
        } catch (Exception $e) {
            securityLog("[Miyo Mail Error] " . $mail->ErrorInfo);
            echo json_encode(['status' => 0, 'msg' => "邮件发送失败，请稍后重试"]);
        }
        exit;
    }
    if ($type === 'logout') {
        requireAuth();
        $userName = $_SESSION['user']['name'] ?? '未知';
        clearAuthenticatedSession();
        securityLog("用户退出登录: {$userName}");
        echo json_encode(['status' => 1, 'msg' => '退出成功']);
        exit;
    }
    echo json_encode(['status' => 0, 'msg' => '未知操作']);
    exit;
}

