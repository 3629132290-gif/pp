-- Miyo 存储配额迁移脚本
-- 为 users 表添加 storage_quota 字段
-- 默认 100KB (102400 bytes)，管理员开通后设为 520MB (545259520 bytes)

ALTER TABLE users ADD COLUMN IF NOT EXISTS storage_quota BIGINT NOT NULL DEFAULT 102400;