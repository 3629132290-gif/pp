/**
 * SSL证书配置前端脚本
 * 与现有平台风格保持一致
 * 无触控反馈版
 */
let csrfToken = window.csrfToken || '';
let currentUser = window.currentUser || {};

function showToast(msg, duration = 2500) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), duration);
}

function toggleMobileSidebar() {
    const sb = document.getElementById('sidebar');
    const ov = document.getElementById('overlay');
    sb.classList.toggle('open');
    ov.classList.toggle('show');
}

function toggleCollapse() {
    const sb = document.getElementById('sidebar');
    const icon = document.getElementById('collapseIcon');
    if (window.innerWidth <= 768 && sb.classList.contains('open')) {
        sb.classList.remove('open');
        document.getElementById('overlay').classList.remove('show');
        return;
    }
    sb.classList.toggle('collapsed');
    if (sb.classList.contains('collapsed')) {
        icon.classList.remove('fa-chevron-left');
        icon.classList.add('fa-chevron-right');
        localStorage.setItem('sb', '1');
    } else {
        icon.classList.remove('fa-chevron-right');
        icon.classList.add('fa-chevron-left');
        localStorage.setItem('sb', '0');
    }
}

function logout() {
    if (!confirm('确定要退出登录吗？')) return;
    $.ajax({
        url: '/注册登录/api.php',
        type: 'POST',
        data: { type: 'logout' },
        dataType: 'json',
        timeout: 10000,
        success: function() {
            window.location.href = '/注册登录/注册登录.php';
        },
        error: function() {
            window.location.href = '/注册登录/注册登录.php';
        }
    });
}

// 加载用户域名信息
function loadUserDomain() {
    $.ajax({
        url: '/域名/api.php',
        type: 'POST',
        data: { type: 'check_domain' },
        dataType: 'json',
        timeout: 10000,
        success: function(res) {
            if (res.status === 1 && res.has_domain && res.domain) {
                document.getElementById('domainName').textContent = res.domain.domain;
                
                // 计算证书有效期（模拟：从今天起90天）
                const today = new Date();
                const expireDate = new Date(today);
                expireDate.setDate(today.getDate() + 90);
                document.getElementById('expireDate').textContent = expireDate.toISOString().split('T')[0];
            } else {
                document.getElementById('domainName').textContent = '您还没有绑定域名';
                document.getElementById('expireDate').textContent = '请先绑定域名';
            }
        },
        error: function() {
            showToast('加载域名信息失败');
        }
    });
}

// 阻止开关点击并显示黑色Toast提示
function initSwitchHandlers() {
    document.querySelectorAll('.switch input').forEach(switchEl => {
        // 阻止 checkbox 状态改变
        switchEl.addEventListener('change', function(e) {
            e.preventDefault();
            this.checked = true; // 强制保持开启
            showToast('默认开启，不支持关闭');
        });
        // 兼容移动端：阻止 label 触发的点击穿透
        switchEl.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            this.checked = true; // 强制保持开启
            showToast('默认开启，不支持关闭');
            return false;
        });
    });
}

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    // 设置用户名
    if (currentUser.name) {
        document.getElementById('userName').textContent = currentUser.name;
    }
    
    // 恢复侧边栏折叠状态（仅桌面端）
    if (window.innerWidth > 768 && localStorage.getItem('sb') === '1') {
        const sb = document.getElementById('sidebar');
        const icon = document.getElementById('collapseIcon');
        if (sb) sb.classList.add('collapsed');
        if (icon) {
            icon.classList.remove('fa-chevron-left');
            icon.classList.add('fa-chevron-right');
        }
    }
    
    // 自动检测iframe嵌入并应用样式
    if (window.self !== window.top) {
        document.body.classList.add('iframe-mode');
    }
    
    // 加载域名信息
    loadUserDomain();
    
    // 初始化开关事件
    initSwitchHandlers();
});
