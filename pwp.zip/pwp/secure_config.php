<?php
/**
 * MiyoHost 安全配置加载器
 * ============================================================================
 * 用途：集中管理所有敏感凭据，从环境变量或安全配置文件加载
 * 安全策略：
 *   - 优先从环境变量读取（推荐生产环境）
 *   - 其次从 /www/.miyo_env.php 读取（Web 根目录外）
 *   - 不在源码中硬编码任何凭据
 *   - 配置文件权限应设为 600
 * ============================================================================
 */

class SecureConfig {
    private static $instance = null;
    private $config = [];

    private function __construct() {
        // 首先尝试加载外部配置文件
        $envFile = '/www/.miyo_env.php';
        if (file_exists($envFile) && is_readable($envFile)) {
            $cfg = require $envFile;
            if (is_array($cfg)) {
                $this->config = $cfg;
            }
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * 获取配置值，优先级：环境变量 > 配置文件
     */
    public function get($key, $default = null) {
        $envKey = strtoupper($key);
        $envValue = getenv($envKey);
        if ($envValue !== false && $envValue !== '') {
            return $envValue;
        }
        return $this->config[$key] ?? $default;
    }

    /**
     * 获取数据库配置
     */
    public function getDbConfig() {
        return [
            'host' => $this->get('DB_HOST', 'localhost'),
            'name' => $this->get('DB_NAME', 'miyo'),
            'user' => $this->get('DB_USER', ''),
            'pass' => $this->get('DB_PASS', ''),
        ];
    }

    /**
     * 获取 SMTP 配置
     */
    public function getSmtpConfig() {
        return [
            'host' => $this->get('SMTP_HOST', 'smtp.qq.com'),
            'port' => (int)$this->get('SMTP_PORT', '587'),
            'user' => $this->get('SMTP_USER', ''),
            'pass' => $this->get('SMTP_PASS', ''),
        ];
    }

    /**
     * 获取宝塔面板配置
     */
    public function getBtConfig() {
        return [
            'panel'  => $this->get('BT_PANEL_URL', 'http://127.0.0.1:8888'),
            'api_key' => $this->get('BT_API_KEY', ''),
        ];
    }
}

/**
 * 快捷函数：获取安全配置
 */
function secureConfig($key, $default = null) {
    return SecureConfig::getInstance()->get($key, $default);
}

/**
 * 创建 PDO 数据库连接（使用安全配置）
 */
function createSecurePdo() {
    $db = SecureConfig::getInstance()->getDbConfig();
    if (empty($db['user']) || empty($db['pass'])) {
        throw new RuntimeException('数据库凭据未配置，请设置环境变量 DB_USER 和 DB_PASS');
    }
    return new PDO(
        "mysql:host={$db['host']};dbname={$db['name']};charset=utf8mb4",
        $db['user'],
        $db['pass'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
}

// ==================== #16: PHP 文件危险函数扫描 ====================

/**
 * PHP 危险函数与关键字黑名单
 * 匹配以下模式即判定为危险：
 *   - 代码/命令执行函数
 *   - 文件系统写入/操作函数
 *   - 系统命令执行
 *   - WebShell 常用函数
 */
define('PHP_DANGEROUS_FUNCTIONS', [
    // 代码/命令执行
    'eval', 'assert', 'preg_replace\s*\([^)]*\/e', 'create_function',
    'call_user_func', 'call_user_func_array',
    // 系统命令
    'system', 'exec', 'shell_exec', 'passthru', 'popen', 'proc_open',
    'pcntl_exec', '``',  // 反引号
    // 文件系统
    'fwrite', 'fputs', 'file_put_contents', 'move_uploaded_file',
    'rename', 'copy', 'unlink', 'rmdir', 'mkdir', 'chmod', 'chown',
    'symlink', 'link',
    // 网络
    'curl_exec', 'fsockopen', 'pfsockopen', 'stream_socket_client',
    // 后端执行/WebShell模式
    'base64_decode', 'gzinflate', 'gzuncompress', 'str_rot13',
    // 危险包含
    'include\s*\(', 'require\s*\(', 'include_once\s*\(', 'require_once\s*\(',
    // 能够修改 PHP 配置
    'ini_set', 'ini_alter', 'set_time_limit',
    // 信息探测
    'phpinfo', 'get_current_user', 'getmyuid', 'getmypid',
]);

/**
 * 扫描 PHP 文件内容是否包含危险函数
 * 
 * @param string $content  文件内容
 * @param string $filename 文件名（用于日志）
 * @return array [safe => bool, matches => array]
 */
function scanPhpFile($content, $filename = '') {
    $matches = [];
    $tokens = token_get_all($content);

    foreach ($tokens as $token) {
        if (!is_array($token)) continue;
        // 只检查字符串（函数名、变量名等）
        if ($token[0] === T_STRING || $token[0] === T_EVAL || $token[0] === T_INCLUDE || $token[0] === T_REQUIRE) {
            $name = strtolower($token[1]);
            foreach (PHP_DANGEROUS_FUNCTIONS as $pattern) {
                // 简单函数名匹配（去掉正则中的模式）
                $funcName = str_replace(['\s*\(', '\s*\('], '', $pattern);
                $funcName = str_replace(['[^)]*\/e'], '', $funcName);
                if ($name === $funcName || $name === trim($funcName, '`')) {
                    $matches[] = $token[1];
                    break;
                }
            }
        }
    }

    // 补充基于正则的扫描（捕获 preg_replace /e, 反引号, 动态函数调用等）
    $dangerousRegexPatterns = [
        '/\bpreg_replace\s*\([^,]*\/e[^,]*[,\)]/i',
        '/`[^`]+`/',                           // 反引号执行
        '/\$[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*\s*\(/', // 变量函数调用 $func()
        '/\b(base64_decode|gzinflate|gzuncompress|str_rot13)\s*\(/i',
    ];
    foreach ($dangerousRegexPatterns as $pattern) {
        if (preg_match($pattern, $content)) {
            $matches[] = 'regex:' . $pattern;
        }
    }

    $uniqueMatches = array_unique($matches);
    return [
        'safe'    => empty($uniqueMatches),
        'matches' => $uniqueMatches
    ];
}

/**
 * 获取 PHP 危险函数安全白名单文件列表
 * 这些 PHP 文件由系统管理且必须包含特定函数，跳过扫描
 * 路径相对于用户网站根目录
 */
function isPhpWhitelisted($relativePath) {
    $whitelist = [
        // 用户可能需要的基础函数（不含危险的命令执行类）
        // 白名单为空：所有用户上传的 PHP 都不应有危险函数
    ];
    $normalized = str_replace('\\', '/', trim($relativePath, '/'));
    return in_array($normalized, $whitelist);
}

/**
 * 获取管理员配置文件的安全路径（Web 根目录外）
 * 修复 #9: 管理员配置文件存储在 /www/miyodata/ 而非 Web 可访问目录
 */
function getSecureDataDir() {
    $dir = '/www/miyodata';
    if (!is_dir($dir)) {
        @mkdir($dir, 0750, true);
    }
    return $dir;
}