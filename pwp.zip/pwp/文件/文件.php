<?php
// ==================== 用户认证（与注册登录系统统一） ====================
// 注意：注册登录/api.php 内部已调用 session_start()，此处不再重复调用
require_once __DIR__ . '/../注册登录/api.php';
if (!isAuthenticated()) {
    header('Location: /注册登录/注册登录.php');
    exit;
}

$userId = $_SESSION['user']['id'];
$userName = htmlspecialchars($_SESSION['user']['name'] ?? '用户', ENT_QUOTES, 'UTF-8');

// ==================== 数据库配置（安全加载） ====================
// 修复 C-01: 数据库凭据不再硬编码
require_once __DIR__ . '/../secure_config.php';
try {
    $pdo = createSecurePdo();
} catch (RuntimeException $e) {
    die('数据库配置未就绪');
} catch (PDOException $e) {
    die('数据库连接失败');
}

// 查询用户域名
$stmt = $pdo->prepare("SELECT * FROM domains WHERE user_id = ? AND status = 'active' LIMIT 1");
$stmt->execute([$userId]);
$userDomain = $stmt->fetch();

$hasDomain = !empty($userDomain);
$domainName = $hasDomain ? htmlspecialchars($userDomain['domain'], ENT_QUOTES, 'UTF-8') : '';
$domainPath = $hasDomain ? $userDomain['path'] : '';

// 生成CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// 容错加载 config.php
if (file_exists(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>文件管理 - Miyo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
      integrity="sha384-t1nt8BQoYMLFN5p42tRAtuAAFQaCQODekUVeKKZrEnEyp4H2R0RHFz0KWpmj7i8g" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <style>
        /* 用户信息栏 */
        .user-bar { display:flex; align-items:center; gap:12px; margin-left:auto; }
        .user-bar .domain-tag {
            font-size:12px; background:#000; color:#fff; padding:2px 8px; border-radius:4px;
            cursor:pointer; transition:opacity 0.2s; text-decoration:none;
        }
        .user-bar .domain-tag:hover { opacity:0.85; }
        .user-bar .logout-btn {
            background:none; border:1px solid #e5e5e5; color:#666; padding:4px 10px;
            border-radius:4px; font-size:12px; cursor:pointer; transition:all 0.2s;
        }
        .user-bar .logout-btn:hover { background:#000; color:#fff; border-color:#000; }
        .user-bar .user-name { font-size:13px; color:#555; }
        
        /* 面包屑 */
        .breadcrumb-bar {
            position:fixed; top:var(--header-height); left:0; right:0; z-index:998;
            height:var(--breadcrumb-height); padding:10px 20px; background:#f8f9fa;
            border-bottom:1px solid #e5e5e5; font-size:13px; display:flex;
            align-items:center; gap:4px; flex-wrap:wrap;
        }
        .breadcrumb-item { background:none; border:none; color:#666; cursor:pointer; font-size:13px; padding:2px 6px; border-radius:4px; }
        .breadcrumb-item:hover { background:#e9ecef; color:#000; }
        .breadcrumb-separator { color:#ccc; font-size:10px; }
        #searchInput { padding:6px 12px; border:1px solid #e5e5e5; border-radius:6px; font-size:13px; width:160px; outline:none; background:#fff; }
        #searchInput:focus { border-color:#000; }
        .main-content.no-toolbar { margin-top: var(--header-height); min-height: calc(100vh - var(--header-height)); }

        /* iframe嵌入模式：隐藏文件管理页面自己的header，并修正toolbar和内容区定位 */
        body.iframe-mode .app-header {
            display: none !important;
        }
        body.iframe-mode .breadcrumb-bar {
            top: 0 !important;
        }
        body.iframe-mode .toolbar {
            top: var(--breadcrumb-height) !important;
        }
        body.iframe-mode .main-content {
            margin-top: calc(var(--breadcrumb-height) + var(--toolbar-height)) !important;
        }

        /* 无域名引导页（与数据库页面保持一致的风格） */
        .no-domain-page {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            text-align: center;
            padding: 40px 20px;
            background: #fff;
        }
        .no-domain-page .guide-icon-wrap {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #f0f0f0 0%, #e0e0e0 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 24px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.06);
        }
        .no-domain-page .guide-icon-wrap i {
            font-size: 36px;
            color: #555;
        }
        .no-domain-page h2 {
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 12px;
            color: #0a0a0a;
        }
        .no-domain-page p {
            color: #666;
            margin-bottom: 28px;
            max-width: 420px;
            line-height: 1.7;
            font-size: 14px;
        }
        .no-domain-page .guide-steps {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 32px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .no-domain-page .guide-step {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
            background: #fafafa;
            border: 1px solid #e5e5e5;
            border-radius: 12px;
            padding: 16px 20px;
            min-width: 120px;
            transition: all 0.2s;
        }
        .no-domain-page .guide-step:hover {
            border-color: #d4d4d4;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
        }
        .no-domain-page .guide-step-num {
            width: 28px;
            height: 28px;
            background: #0a0a0a;
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 700;
        }
        .no-domain-page .guide-step span:last-child {
            font-size: 13px;
            color: #555;
            font-weight: 500;
        }
        .no-domain-page .guide-step-arrow {
            color: #ccc;
            font-size: 14px;
        }
        .no-domain-page .btn-guide {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 28px;
            background: #0a0a0a;
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            transition: all 0.2s;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border: none;
            cursor: pointer;
        }
        .no-domain-page .btn-guide:hover {
            background: #333;
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        @media (max-width: 768px) {
            .no-domain-page .guide-steps {
                flex-direction: column;
                gap: 8px;
            }
            .no-domain-page .guide-step-arrow {
                transform: rotate(90deg);
            }
            .no-domain-page .guide-step {
                flex-direction: row;
                width: 100%;
                max-width: 280px;
                padding: 12px 16px;
            }
        }
    </style>
</head>
<body>

<?php if (!$hasDomain): ?>
<!-- ===== 未绑定域名引导页 ===== -->
<div class="no-domain-page">
    <div class="guide-icon-wrap">
        <i class="fa-solid fa-folder-open"></i>
    </div>
    <h2>还没有绑定域名</h2>
    <p>绑定域名后，系统将自动为您创建专属的网站目录，您可以通过文件管理上传和管理您的网站文件。</p>
    <div class="guide-steps">
        <div class="guide-step">
            <span class="guide-step-num">1</span>
            <span>前往二级域名页面</span>
        </div>
        <div class="guide-step-arrow"><i class="fa-solid fa-chevron-right"></i></div>
        <div class="guide-step">
            <span class="guide-step-num">2</span>
            <span>输入域名前缀并绑定</span>
        </div>
        <div class="guide-step-arrow"><i class="fa-solid fa-chevron-right"></i></div>
        <div class="guide-step">
            <span class="guide-step-num">3</span>
            <span>返回此页面管理文件</span>
        </div>
    </div>
    <a href="/域名/域名.php" class="btn-guide"><i class="fa-solid fa-arrow-right"></i> 前往绑定域名</a>
</div>
<script>
function logout() {
    if (!confirm('确定要退出登录吗？')) return;
    fetch('/注册登录/api.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'type=logout'
    }).finally(() => {
        window.location.href = '/注册登录/注册登录.php';
    });
}
</script>

<?php else: ?>
<!-- ===== 已绑定域名：文件管理器完整界面 ===== -->
<header class="app-header">
    <div class="user-bar">
        <span class="user-name"><?php echo $userName; ?></span>
        <span class="domain-tag" onclick="window.open('http://<?php echo $domainName; ?>', '_blank')" title="点击访问网站"><?php echo $domainName; ?></span>
        <button class="logout-btn" onclick="logout()">
            <i class="fa-solid fa-sign-out-alt"></i> 退出
        </button>
    </div>
</header>

<div class="breadcrumb-bar" id="breadcrumb"></div>

<div class="toolbar" id="toolbar">
    <div class="toolbar-group">
        <button class="btn btn-icon" id="btnBack" onclick="goBack()" title="上级目录"><i class="fa-solid fa-arrow-up"></i></button>
        <button class="btn btn-icon" onclick="refresh()" title="刷新"><i class="fa-solid fa-rotate-right"></i></button>
    </div>
    <div class="toolbar-divider hide-mobile"></div>
    <div class="toolbar-group" id="mainActions">
        <button class="btn hide-mobile" onclick="showUploadModal()"><i class="fa-solid fa-cloud-arrow-up"></i><span class="btn-text">上传</span></button>
        <button class="btn hide-mobile" onclick="showMkdirModal()"><i class="fa-solid fa-folder-plus"></i><span class="btn-text">新建文件夹</span></button>
        <button class="btn hide-mobile" onclick="showTouchModal()"><i class="fa-solid fa-file-circle-plus"></i><span class="btn-text">新建文件</span></button>
    </div>
    <div class="toolbar-divider hide-mobile"></div>
    <div class="toolbar-group" id="viewActions">
        <button class="btn btn-icon" onclick="toggleView()" title="切换视图"><i class="fa-solid fa-list" id="viewIcon"></i></button>
        <button class="btn btn-icon" onclick="selectAll()" title="全选"><i class="fa-solid fa-check-double"></i></button>
    </div>
    <div class="dropdown" id="moreDropdown">
        <button class="btn btn-icon" onclick="toggleDropdown('moreDropdown')" title="更多"><i class="fa-solid fa-ellipsis-vertical"></i></button>
        <div class="dropdown-menu">
            <button class="dropdown-item" onclick="showUploadModal(); toggleDropdown('moreDropdown')"><i class="fa-solid fa-cloud-arrow-up"></i> 上传文件</button>
            <button class="dropdown-item" onclick="showMkdirModal(); toggleDropdown('moreDropdown')"><i class="fa-solid fa-folder-plus"></i> 新建文件夹</button>
            <button class="dropdown-item" onclick="showTouchModal(); toggleDropdown('moreDropdown')"><i class="fa-solid fa-file-circle-plus"></i> 新建文件</button>
            <div style="height:1px; background:var(--border); margin:4px 0;"></div>
            <button class="dropdown-item" onclick="toggleView(); toggleDropdown('moreDropdown')"><i class="fa-solid fa-list"></i> 切换视图</button>
        </div>
    </div>
    <div class="toolbar-group" style="margin-left:auto;">
        <input type="text" id="searchInput" placeholder="搜索文件..." autocomplete="off">
    </div>
</div>

<main class="main-content" id="mainContent">
    <div class="file-list" id="fileList"></div>
</main>

<div class="selection-bar" id="selectionBar">
    <span id="selectionCount">已选择 0 项</span>
    <button class="btn btn-danger" onclick="batchDelete()"><i class="fa-solid fa-trash"></i> 删除</button>
    <button class="btn" onclick="clearSelection()" style="margin-left:4px;"><i class="fa-solid fa-xmark"></i></button>
</div>

<div class="modal-overlay" id="uploadModal">
    <div class="modal">
        <div class="modal-header">
            <span class="modal-title">上传文件</span>
            <button class="modal-close" onclick="closeModal('uploadModal')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body">
            <div class="drop-zone" id="dropZone" onclick="document.getElementById('fileInput').click()">
                <i class="fa-solid fa-cloud-arrow-up"></i>
                <div>点击或拖拽文件到此处上传</div>
                <div style="font-size:12px; margin-top:4px; opacity:0.6;">支持多文件</div>
            </div>
            <input type="file" id="fileInput" multiple accept=".jpg,.jpeg,.png,.gif,.css,.js,.html,.txt,.zip,.mp3,.mp4" style="display:none" onchange="handleFiles(this.files); this.value='';">
            <div class="upload-progress" id="uploadProgress">
                <div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:4px; color:var(--text-secondary);">
                    <span id="uploadStatus">正在上传...</span>
                    <span id="uploadPercent">0%</span>
                </div>
                <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
            </div>
        </div>
        <div class="modal-footer"><button class="btn" onclick="closeModal('uploadModal')">取消</button></div>
    </div>
</div>

<div class="modal-overlay" id="mkdirModal">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">新建文件夹</span>
            <button class="modal-close" onclick="closeModal('mkdirModal')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">文件夹名称</label>
                <input type="text" class="form-input" id="mkdirName" placeholder="请输入文件夹名称" onkeydown="if(event.key==='Enter')confirmMkdir()">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn" onclick="closeModal('mkdirModal')">取消</button>
            <button class="btn btn-primary" onclick="confirmMkdir()">创建</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="touchModal">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">新建文件</span>
            <button class="modal-close" onclick="closeModal('touchModal')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">文件名称</label>
                <input type="text" class="form-input" id="touchName" placeholder="例如：index.php" onkeydown="if(event.key==='Enter')confirmTouch()">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn" onclick="closeModal('touchModal')">取消</button>
            <button class="btn btn-primary" onclick="confirmTouch()">创建</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="renameModal">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">重命名</span>
            <button class="modal-close" onclick="closeModal('renameModal')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">新名称</label>
                <input type="text" class="form-input" id="renameName" onkeydown="if(event.key==='Enter')confirmRename()">
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn" onclick="closeModal('renameModal')">取消</button>
            <button class="btn btn-primary" onclick="confirmRename()">确认</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="editModal">
    <div class="modal modal-fullscreen">
        <div class="modal-header">
            <span class="modal-title" id="editTitle">编辑文件</span>
            <button class="modal-close" onclick="closeModal('editModal')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body" style="padding:0; flex:1; display:flex; overflow:hidden;">
            <textarea class="form-textarea" id="editContent" style="border:none; border-radius:0; width:100%; height:100%; resize:none;"></textarea>
        </div>
        <div class="modal-footer">
            <button class="btn" onclick="closeModal('editModal')">取消</button>
            <button class="btn btn-primary" onclick="confirmSave()"><i class="fa-solid fa-floppy-disk"></i> 保存</button>
        </div>
    </div>
</div>

<div class="modal-overlay" id="imageModal" onclick="if(event.target===this)closeModal('imageModal')">
    <div class="modal" style="max-width:90vw; background:transparent; box-shadow:none; border:none;">
        <div style="position:relative;">
            <button class="modal-close" style="position:absolute; top:-40px; right:0; background:rgba(0,0,0,0.5); color:#fff; z-index:10;" onclick="closeModal('imageModal')"><i class="fa-solid fa-xmark"></i></button>
            <img src="" alt="preview" class="image-preview" id="previewImage">
        </div>
    </div>
</div>

<div class="modal-overlay" id="infoModal">
    <div class="modal" style="max-width:400px;">
        <div class="modal-header">
            <span class="modal-title">文件信息</span>
            <button class="modal-close" onclick="closeModal('infoModal')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <div class="modal-body" id="infoBody"></div>
        <div class="modal-footer">
            <button class="btn" onclick="closeModal('infoModal')">关闭</button>
        </div>
    </div>
</div>

<div class="toast-container" id="toastContainer"></div>
<div class="loading-overlay" id="loadingOverlay"><div class="spinner"></div></div>

<div class="context-menu" id="contextMenu">
    <button class="dropdown-item" onclick="contextUnzip()" id="ctxUnzip" style="display:none;"><i class="fa-solid fa-file-zipper"></i> 解压</button>
    <button class="dropdown-item" onclick="contextRename()"><i class="fa-solid fa-pen"></i> 重命名</button>
    <button class="dropdown-item" onclick="contextInfo()"><i class="fa-solid fa-circle-info"></i> 信息</button>
    <div style="height:1px; background:var(--border); margin:4px 0;"></div>
    <button class="dropdown-item" onclick="contextDelete()" style="color:#000; font-weight:500;"><i class="fa-solid fa-trash"></i> 删除</button>
</div>

<script>
window.csrfToken = "<?php echo $_SESSION['csrf_token']; ?>";
// iframe嵌入检测：被部署页面嵌入时隐藏自己的header
if (window.self !== window.top) {
    document.body.classList.add('iframe-mode');
}
function logout() {
    if (!confirm('确定要退出登录吗？')) return;
    fetch('/注册登录/api.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'type=logout'
    }).finally(() => {
        window.location.href = '/注册登录/注册登录.php';
    });
}
</script>
<script src="script.js"></script>
<?php endif; ?>

</body>
</html>