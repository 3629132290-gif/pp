<?php
/**
 * MonoFile Manager - 共享配置
 */
if (!defined('MONOFILE_CONFIG')) {
    define('MONOFILE_CONFIG', true);

    // ==================== 核心配置 ====================
    define('ACCESS_PASSWORD', '');               // 访问密码，留空不启用
    define('ROOT_PATH', '/www/wwwroot/');        // 强制根目录
    define('MAX_UPLOAD_SIZE', 50 * 1024 * 1024); // 50MB
    define('TIMEZONE', 'Asia/Shanghai');

    // ==================== 环境初始化 ====================
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    date_default_timezone_set(TIMEZONE);
    error_reporting(0);
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);

    // CSRF Token
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}
