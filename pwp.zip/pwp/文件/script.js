// ==================== 状态管理 ====================
const state = {
    config: null,
    currentPath: '',
    files: [],
    selected: new Set(),
    viewMode: localStorage.getItem('viewMode') || 'grid',
    contextTarget: null,
    isLoading: false
};
let lastClickedIndex = -1;

// ==================== API 请求封装 ====================
async function apiRequest(url, options = {}) {
    const res = await fetch(url, options);
    const text = await res.text();
    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        console.error('异常-1:', text.substring(0, 500));
        throw new Error('服务器返回无效数据');
    }
    if (data.error) {
        if (data.need_auth) {
            window.location.reload();
        }
        throw new Error(data.error);
    }
    return data;
}

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

async function initApp() {
    showLoading(true);
    try {
        const config = await apiRequest('api.php?action=config');
        state.config = config;
        state.currentPath = config.root_path;

        updateBackButton();
        setupEventListeners();
        setupDragDrop();
        setupEditor();
        updateViewMode();
        await loadFiles();
    } catch (err) {
        // 未登录
        if (err.message.includes('未登录') || err.message.includes('need_auth')) {
            window.location.href = '/注册登录/注册登录.php';
            return;
        }
        // 未绑定域名
        if (err.message.includes('还没有创建网站') || err.message.includes('need_domain')) {
            const fileListEl = document.getElementById('fileList');
            const toolbarEl = document.getElementById('toolbar');
            const breadcrumbEl = document.getElementById('breadcrumb');
            if (fileListEl) {
                fileListEl.innerHTML = `
                    <div class="empty-state" style="flex-direction:column; padding:60px 20px;">
                        <i class="fa-solid fa-globe" style="font-size:56px; color:#d4d4d4; margin-bottom:20px;"></i>
                        <div style="font-size:18px; font-weight:600; margin-bottom:8px;">您还没有创建网站</div>
                        <div style="color:#666; margin-bottom:24px; text-align:center; line-height:1.6; max-width:400px;">
                            文件管理需要与您的网站目录绑定。<br>请先前往二级域名管理页面绑定一个二级域名。
                        </div>
                        <a href="/域名/域名.php" style="display:inline-flex; align-items:center; gap:8px; padding:10px 20px; background:#000; color:#fff; text-decoration:none; border-radius:6px; font-size:14px;">
                            <i class="fa-solid fa-arrow-right"></i> 前往绑定域名
                        </a>
                    </div>
                `;
            }
            if (toolbarEl) toolbarEl.style.display = 'none';
            if (breadcrumbEl) breadcrumbEl.innerHTML = '';
            showLoading(false);
            return;
        }
        showToast(err.message, 'error');
    } finally {
        showLoading(false);
    }
}


function setupEventListeners() {
    let searchTimer;
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => filterFiles(e.target.value), 200);
        });
    }

    document.addEventListener('keydown', (e) => {
        if (e.ctrlKey || e.metaKey) {
            if (e.key === 'a') { e.preventDefault(); selectAll(); }
            if (e.key === 'r') { e.preventDefault(); refresh(); }
            if (e.key === 's') { 
                const editModal = document.getElementById('editModal');
                if (editModal.classList.contains('active')) {
                    e.preventDefault();
                    confirmSave();
                }
            }
        }
        if (e.key === 'Escape') {
            clearSelection();
            closeAllModals();
            closeContextMenu();
        }
        if (e.key === 'Delete' && state.selected.size > 0) batchDelete();
    });

    document.addEventListener('click', (e) => {
        if (!e.target.closest('.dropdown')) {
            document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('active'));
        }
        if (!e.target.closest('.context-menu') && !e.target.closest('.file-item')) {
            closeContextMenu();
        }
    });

    document.querySelectorAll('.modal-overlay').forEach(overlay => {
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) closeModal(overlay.id);
        });
    });
}

function setupDragDrop() {
    const zone = document.getElementById('dropZone');
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        document.body.addEventListener(eventName, (e) => { e.preventDefault(); e.stopPropagation(); }, false);
    });
    document.body.addEventListener('dragenter', () => {
        if (!document.getElementById('uploadModal').classList.contains('active')) showUploadModal();
    });
    if (zone) {
        zone.addEventListener('dragenter', () => zone.classList.add('dragover'));
        zone.addEventListener('dragleave', () => zone.classList.remove('dragover'));
        zone.addEventListener('drop', (e) => {
            zone.classList.remove('dragover');
            handleFiles(e.dataTransfer.files);
        });
    }
}

function setupEditor() {
    const editor = document.getElementById('editContent');
    if (editor) {
        editor.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                e.preventDefault();
                const start = this.selectionStart;
                const end = this.selectionEnd;
                this.value = this.value.substring(0, start) + '    ' + this.value.substring(end);
                this.selectionStart = this.selectionEnd = start + 4;
            }
        });
    }
}

// ==================== 文件加载 ====================
async function loadFiles() {
    showLoading(true);
    try {
        const formData = new FormData();
        formData.append('action', 'list');
        formData.append('csrf_token', state.config.csrf_token);
        const data = await apiRequest(`api.php?path=${encodeURIComponent(state.currentPath)}`, {
            method: 'POST',
            body: formData
        });
        state.files = data.files || [];
        renderBreadcrumb(data.path || state.currentPath);
        renderFiles();
        updateSelectionBar();
        updateBackButton();
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        showLoading(false);
    }
}

function updateBackButton() {
    const btn = document.getElementById('btnBack');
    if (!btn || !state.config) return;
    const root = state.config.root_path;
    if (state.currentPath === root) {
        btn.style.opacity = '0.4';
        btn.style.cursor = 'not-allowed';
    } else {
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
    }
}

function renderBreadcrumb(path) {
    const container = document.getElementById('breadcrumb');
    if (!container || !state.config) return;
    const rootResolved = state.config.root_path;
    const rootName = state.config.root_name;
    const relative = path.replace(rootResolved, '').replace(/^\/+/, '');
    const parts = relative ? relative.split('/').filter(Boolean) : [];

    let html = `<button class="breadcrumb-item" onclick="navigateTo('${escapeHtml(rootResolved)}')">
        <i class="fa-solid fa-hard-drive"></i> ${escapeHtml(rootName)}
    </button>`;

    let buildPath = rootResolved;
    parts.forEach((part) => {
        buildPath = normalizePath(buildPath + '/' + part);
        html += `<span class="breadcrumb-separator"><i class="fa-solid fa-chevron-right"></i></span>`;
        html += `<button class="breadcrumb-item" onclick="navigateTo('${escapeHtml(buildPath)}')">${escapeHtml(part)}</button>`;
    });

    container.innerHTML = html;
}

function renderFiles() {
    const container = document.getElementById('fileList');
    const searchInput = document.getElementById('searchInput');
    const searchVal = searchInput ? searchInput.value.toLowerCase() : '';
    let files = state.files;
    if (searchVal) files = files.filter(f => f.name.toLowerCase().includes(searchVal));

    if (files.length === 0) {
        const isEmpty = !searchVal;
        if (isEmpty) {
            container.innerHTML = `<div class="empty-state"><i class="fa-regular fa-folder-open"></i><div>此文件夹为空</div></div>`;
        } else {
            container.innerHTML = `<div class="empty-state"><i class="fa-solid fa-magnifying-glass"></i><div>未找到匹配 "${escapeHtml(searchVal)}" 的文件</div><div style="font-size:13px; color:#999; margin-top:4px;">请尝试其他关键词</div></div>`;
        }
        return;
    }

    files.sort((a, b) => {
        if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
        return a.name.localeCompare(b.name);
    });

    container.innerHTML = files.map((file, index) => {
        const isSelected = state.selected.has(file.name);
        const icon = getFileIcon(file.type, file.ext);
        const size = file.type === 'dir' ? '-' : formatSize(file.size);
        const date = formatDate(file.mtime);
        const delay = Math.min(index * 0.02, 0.3);
        return `
            <div class="file-item ${isSelected ? 'selected' : ''}" style="animation-delay:${delay}s"
                 data-name="${escapeHtml(file.name)}" data-type="${file.type}"
                 onclick="handleItemClick(event, '${escapeHtml(file.name)}', '${file.type}')"
                 oncontextmenu="handleContextMenu(event, '${escapeHtml(file.name)}', '${file.type}')">
                <div class="file-icon"><i class="${icon}"></i></div>
                <div class="file-name">${escapeHtml(file.name)}</div>
                <div class="file-meta"><span class="hide-mobile">${size}</span><span class="hide-mobile" style="margin:0 4px;">·</span><span>${date}</span></div>
            </div>
        `;
    }).join('');
}

// ==================== 交互处理 ====================
function handleItemClick(e, name, type) {
    if (document.getElementById('contextMenu').classList.contains('active')) {
        closeContextMenu();
        return;
    }
    if (e.ctrlKey || e.metaKey) {
        toggleSelection(name);
        lastClickedIndex = getFileIndex(name);
    } else if (e.shiftKey) {
        const currentIndex = getFileIndex(name);
        if (lastClickedIndex >= 0 && currentIndex >= 0) {
            const start = Math.min(lastClickedIndex, currentIndex);
            const end = Math.max(lastClickedIndex, currentIndex);
            const visible = getVisibleFiles();
            for (let i = start; i <= end; i++) {
                if (visible[i]) state.selected.add(visible[i].name);
            }
            renderFiles();
            updateSelectionBar();
        }
        lastClickedIndex = currentIndex;
    } else if (type === 'dir') {
        lastClickedIndex = getFileIndex(name);
        const newPath = normalizePath(state.currentPath + '/' + name);
        navigateTo(newPath);
    } else {
        lastClickedIndex = getFileIndex(name);
        openFile(name, type);
    }
}

function toggleSelection(name) {
    if (state.selected.has(name)) state.selected.delete(name);
    else state.selected.add(name);
    renderFiles();
    updateSelectionBar();
}

function getVisibleFiles() {
    const searchVal = document.getElementById('searchInput').value.toLowerCase().trim();
    let visible = state.files;
    if (searchVal) visible = visible.filter(f => f.name.toLowerCase().includes(searchVal));
    visible.sort((a, b) => {
        if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
        return a.name.localeCompare(b.name);
    });
    return visible;
}

function getFileIndex(name) {
    return getVisibleFiles().findIndex(f => f.name === name);
}

function selectAll() {
    const visible = getVisibleFiles();
    const visibleNames = visible.map(f => f.name);
    const allVisibleSelected = visibleNames.length > 0 && visibleNames.every(n => state.selected.has(n));
    if (allVisibleSelected) {
        visibleNames.forEach(n => state.selected.delete(n));
    } else {
        visibleNames.forEach(n => state.selected.add(n));
    }
    renderFiles();
    updateSelectionBar();
}

function clearSelection() {
    state.selected.clear();
    renderFiles();
    updateSelectionBar();
}

function updateSelectionBar() {
    const bar = document.getElementById('selectionBar');
    const count = document.getElementById('selectionCount');
    if (state.selected.size > 0) {
        bar.classList.add('active');
        count.textContent = `已选择 ${state.selected.size} 项`;
    } else {
        bar.classList.remove('active');
    }
}

// ==================== 文件操作 ====================
function navigateTo(path) {
    path = normalizePath(path);
    state.currentPath = path;
    state.selected.clear();
    document.getElementById('searchInput').value = '';
    loadFiles();
}

function goBack() {
    if (!state.config) return;
    const root = state.config.root_path;
    if (state.currentPath === root) {
        showToast('已经是根目录');
        return;
    }
    const parent = state.currentPath.substring(0, state.currentPath.lastIndexOf('/'));
    if (parent && parent.length >= root.length) {
        navigateTo(parent);
    } else {
        navigateTo(root);
    }
}

function refresh() {
    loadFiles();
    showToast('已刷新');
}

function openFile(name, type) {
    const ext = name.split('.').pop().toLowerCase();
    const path = normalizePath(state.currentPath + '/' + name);
    // 只允许 css/js/php/html/txt 点击后编辑，其他文件不做任何操作
    if (['css','js','php','html','htm','txt'].includes(ext)) {
        editFile(name);
        return;
    }
    // 其他文件类型：不做任何操作（不预览、不下载）
}

async function editFile(name) {
    showLoading(true);
    try {
        const formData = new FormData();
        formData.append('action', 'read');
        formData.append('path', normalizePath(state.currentPath + '/' + name));
        formData.append('csrf_token', state.config.csrf_token);
        const data = await apiRequest('api.php', { method: 'POST', body: formData });
        document.getElementById('editTitle').textContent = '编辑: ' + name;
        document.getElementById('editContent').value = data.content || '';
        document.getElementById('editContent').dataset.target = name;
        openModal('editModal');
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        showLoading(false);
    }
}

async function confirmSave() {
    const name = document.getElementById('editContent').dataset.target;
    const content = document.getElementById('editContent').value;
    showLoading(true);
    try {
        const formData = new FormData();
        formData.append('action', 'save');
        formData.append('path', normalizePath(state.currentPath + '/' + name));
        formData.append('content', content);
        formData.append('csrf_token', state.config.csrf_token);
        await apiRequest('api.php', { method: 'POST', body: formData });
        showToast('保存成功');
        closeModal('editModal');
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        showLoading(false);
    }
}

function downloadFile(name) {
    const path = normalizePath(state.currentPath + '/' + name);
    const url = `api.php?action=download&path=${encodeURIComponent(path)}`;
    const link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

async function deleteFile(name) {
    if (!confirm(`确定要删除 "${name}" 吗？此操作不可恢复。`)) return;
    showLoading(true);
    try {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('path', normalizePath(state.currentPath + '/' + name));
        formData.append('csrf_token', state.config.csrf_token);
        await apiRequest('api.php', { method: 'POST', body: formData });
        showToast('删除成功');
        state.selected.delete(name);
        loadFiles();
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        showLoading(false);
    }
}

function renameFile(name) {
    document.getElementById('renameName').value = name;
    document.getElementById('renameName').dataset.oldName = name;
    openModal('renameModal');
}

async function confirmRename() {
    const oldName = document.getElementById('renameName').dataset.oldName;
    const newName = document.getElementById('renameName').value.trim();
    if (!newName || newName === oldName) { closeModal('renameModal'); return; }
    showLoading(true);
    try {
        const formData = new FormData();
        formData.append('action', 'rename');
        formData.append('path', normalizePath(state.currentPath + '/' + oldName));
        formData.append('newName', normalizePath(state.currentPath + '/' + newName));
        formData.append('csrf_token', state.config.csrf_token);
        await apiRequest('api.php', { method: 'POST', body: formData });
        showToast('重命名成功');
        closeModal('renameModal');
        loadFiles();
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        showLoading(false);
    }
}

async function confirmMkdir() {
    const name = document.getElementById('mkdirName').value.trim();
    if (!name) return;
    showLoading(true);
    try {
        const formData = new FormData();
        formData.append('action', 'mkdir');
        formData.append('path', normalizePath(state.currentPath + '/' + name));
        formData.append('csrf_token', state.config.csrf_token);
        await apiRequest('api.php', { method: 'POST', body: formData });
        showToast('创建成功');
        closeModal('mkdirModal');
        document.getElementById('mkdirName').value = '';
        loadFiles();
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        showLoading(false);
    }
}

async function confirmTouch() {
    const name = document.getElementById('touchName').value.trim();
    if (!name) return;
    showLoading(true);
    try {
        const formData = new FormData();
        formData.append('action', 'touch');
        formData.append('path', normalizePath(state.currentPath + '/' + name));
        formData.append('csrf_token', state.config.csrf_token);
        await apiRequest('api.php', { method: 'POST', body: formData });
        showToast('创建成功');
        closeModal('touchModal');
        document.getElementById('touchName').value = '';
        loadFiles();
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        showLoading(false);
    }
}

async function batchDelete() {
    if (state.selected.size === 0) return;
    if (!confirm(`确定要删除选中的 ${state.selected.size} 个项目吗？`)) return;
    showLoading(true);
    let errors = [];
    for (const name of state.selected) {
        try {
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('path', normalizePath(state.currentPath + '/' + name));
            formData.append('csrf_token', state.config.csrf_token);
            await apiRequest('api.php', { method: 'POST', body: formData });
        } catch (e) {
            errors.push(name + ': ' + e.message);
        }
    }
    state.selected.clear();
    loadFiles();
    showLoading(false);
    if (errors.length) showToast(`完成，${errors.length} 个失败`, 'error');
    else showToast('批量删除成功');
}

function batchDownload() {
    if (state.selected.size === 0) return;
    state.selected.forEach((name, i) => {
        setTimeout(() => downloadFile(name), i * 300);
    });
    showToast('开始下载...');
}

// ==================== 上传 ====================
function handleFiles(files) {
    if (!files.length) return;
    const progress = document.getElementById('uploadProgress');
    const fill = document.getElementById('progressFill');
    const status = document.getElementById('uploadStatus');
    const percent = document.getElementById('uploadPercent');
    progress.classList.add('active');

    let uploaded = 0;
    const total = files.length;
    let hasError = false;

    const uploadNext = async () => {
        if (uploaded >= total) {
            setTimeout(() => {
                closeModal('uploadModal');
                progress.classList.remove('active');
                fill.style.width = '0%';
                loadFiles();
                if (!hasError) {
                    showToast(`成功上传 ${total} 个文件`);
                }
            }, 500);
            return;
        }
        const file = files[uploaded];
        status.textContent = `正在上传 ${file.name}...`;
        const progressPercent = Math.round((uploaded / total) * 100);
        fill.style.width = progressPercent + '%';
        percent.textContent = progressPercent + '%';

        const formData = new FormData();
        formData.append('action', 'upload');
        formData.append('path', state.currentPath);
        formData.append('file', file);
        formData.append('csrf_token', state.config.csrf_token);

        try {
            await apiRequest('api.php', { method: 'POST', body: formData });
            uploaded++;
        } catch (err) {
            showToast(`上传失败: ${file.name} - ${err.message}`, 'error');
            hasError = true;
            uploaded++;
        }
        uploadNext();
    };
    uploadNext();
}

// ==================== 视图与搜索 ====================
function toggleView() {
    state.viewMode = state.viewMode === 'grid' ? 'list' : 'grid';
    localStorage.setItem('viewMode', state.viewMode);
    updateViewMode();
}

function updateViewMode() {
    const list = document.getElementById('fileList');
    const icon = document.getElementById('viewIcon');
    if (state.viewMode === 'list') {
        list.classList.add('list-view');
        icon.className = 'fa-solid fa-border-all';
    } else {
        list.classList.remove('list-view');
        icon.className = 'fa-solid fa-list';
    }
}

function filterFiles(keyword) {
    renderFiles();
}

// ==================== 右键菜单 ====================
function handleContextMenu(e, name, type) {
    e.preventDefault();
    state.contextTarget = { name, type };
    const menu = document.getElementById('contextMenu');
    const unzipBtn = document.getElementById('ctxUnzip');
    const ext = name.split('.').pop().toLowerCase();
    if (unzipBtn) {
        unzipBtn.style.display = (ext === 'zip' && type === 'file') ? 'flex' : 'none';
    }

    // 边界检测
    let x = e.clientX;
    let y = e.clientY;
    const menuWidth = 180;
    const menuHeight = 200;

    if (x + menuWidth > window.innerWidth) x = window.innerWidth - menuWidth - 10;
    if (y + menuHeight > window.innerHeight) y = window.innerHeight - menuHeight - 10;
    if (x < 10) x = 10;
    if (y < 10) y = 10;

    menu.style.left = x + 'px';
    menu.style.top = y + 'px';
    menu.classList.add('active');
}

function closeContextMenu() {
    document.getElementById('contextMenu').classList.remove('active');
    state.contextTarget = null;
}


async function contextUnzip() {
    if (!state.contextTarget) return;
    const name = state.contextTarget.name;
    if (!confirm(`确定要解压 "${name}" 吗？`)) {
        closeContextMenu();
        return;
    }
    showLoading(true);
    try {
        const formData = new FormData();
        formData.append('action', 'unzip');
        formData.append('path', normalizePath(state.currentPath + '/' + name));
        formData.append('csrf_token', state.config.csrf_token);
        const data = await apiRequest('api.php', { method: 'POST', body: formData });
        showToast(`解压成功` + (data.target ? ': ' + data.target : ''));
        closeContextMenu();
        loadFiles();
    } catch (err) {
        showToast(err.message, 'error');
        closeContextMenu();
    } finally {
        showLoading(false);
    }
}
function contextOpen() {
    if (!state.contextTarget) return;
    handleItemClick({ ctrlKey: false }, state.contextTarget.name, state.contextTarget.type);
    closeContextMenu();
}

function contextDownload() {
    if (!state.contextTarget) return;
    downloadFile(state.contextTarget.name);
    closeContextMenu();
}

function contextRename() {
    if (!state.contextTarget) return;
    renameFile(state.contextTarget.name);
    closeContextMenu();
}

function contextDelete() {
    if (!state.contextTarget) return;
    deleteFile(state.contextTarget.name);
    closeContextMenu();
}

async function contextInfo() {
    if (!state.contextTarget) return;
    const name = state.contextTarget.name;
    showLoading(true);
    try {
        const formData = new FormData();
        formData.append('action', 'info');
        formData.append('path', normalizePath(state.currentPath + '/' + name));
        formData.append('csrf_token', state.config.csrf_token);
        const data = await apiRequest('api.php', { method: 'POST', body: formData });

        const size = formatSize(data.size || 0);
        const date = new Date((data.mtime || 0) * 1000).toLocaleString('zh-CN');
        const perms = data.perms || '-';

        document.getElementById('infoBody').innerHTML = `
            <div class="form-group"><label class="form-label">名称</label><div class="form-input" style="background:var(--bg-secondary);">${escapeHtml(name)}</div></div>
            <div class="form-group"><label class="form-label">大小</label><div class="form-input" style="background:var(--bg-secondary);">${escapeHtml(size)}</div></div>
            <div class="form-group"><label class="form-label">修改时间</label><div class="form-input" style="background:var(--bg-secondary);">${escapeHtml(date)}</div></div>
            <div class="form-group"><label class="form-label">权限</label><div class="form-input" style="background:var(--bg-secondary);">${escapeHtml(perms)}</div></div>
        `;
        openModal('infoModal');
    } catch (err) {
        showToast(err.message, 'error');
    } finally {
        showLoading(false);
        closeContextMenu();
    }
}

// ==================== UI 辅助 ====================
function showModal(id) {
    document.getElementById(id).classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
    if (!document.querySelector('.modal-overlay.active')) document.body.style.overflow = '';
}

function closeAllModals() {
    document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
    document.body.style.overflow = '';
}

function openModal(id) { showModal(id); }

function showUploadModal() {
    document.getElementById('uploadProgress').classList.remove('active');
    document.getElementById('progressFill').style.width = '0%';
    showModal('uploadModal');
}

function showMkdirModal() { showModal('mkdirModal'); setTimeout(() => document.getElementById('mkdirName').focus(), 100); }
function showTouchModal() { showModal('touchModal'); setTimeout(() => document.getElementById('touchName').focus(), 100); }
function toggleDropdown(id) { document.getElementById(id).classList.toggle('active'); }

function showLoading(show) {
    document.getElementById('loadingOverlay').classList.toggle('active', show);
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icon = type === 'error' ? 'fa-circle-xmark' : 'fa-circle-check';
    toast.innerHTML = `<i class="fa-solid ${icon}"></i> ${escapeHtml(message)}`;
    container.appendChild(toast);
    toast.offsetHeight;
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 400);
    }, 3000);
}

// ==================== 工具函数 ====================
function normalizePath(path) {
    return path.replace(/\/+/g, '/').replace(/\/$/, '') || '/';
}

function getFileIcon(type, ext) {
    if (type === 'dir') return 'fa-solid fa-folder';
    const map = {
        'php': 'fa-brands fa-php', 'js': 'fa-brands fa-js', 'css': 'fa-brands fa-css3',
        'html': 'fa-brands fa-html5', 'htm': 'fa-brands fa-html5', 'json': 'fa-solid fa-code',
        'md': 'fa-brands fa-markdown', 'jpg': 'fa-solid fa-image', 'jpeg': 'fa-solid fa-image',
        'png': 'fa-solid fa-image', 'gif': 'fa-solid fa-image', 'svg': 'fa-solid fa-image',
        'webp': 'fa-solid fa-image', 'mp4': 'fa-solid fa-film', 'mp3': 'fa-solid fa-music',
        'zip': 'fa-solid fa-file-zipper', 'rar': 'fa-solid fa-file-zipper', '7z': 'fa-solid fa-file-zipper',
        'pdf': 'fa-solid fa-file-pdf', 'txt': 'fa-solid fa-file-lines', 'sql': 'fa-solid fa-database',
        'xml': 'fa-solid fa-code', 'log': 'fa-solid fa-file-lines', 'vue': 'fa-brands fa-vuejs',
        'py': 'fa-brands fa-python', 'ts': 'fa-solid fa-code', 'jsx': 'fa-brands fa-react',
        'tsx': 'fa-brands fa-react', 'go': 'fa-brands fa-golang', 'java': 'fa-brands fa-java',
        'sh': 'fa-solid fa-terminal', 'yaml': 'fa-solid fa-file-code', 'yml': 'fa-solid fa-file-code'
    };
    return map[ext] || 'fa-solid fa-file';
}

function formatSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function formatDate(timestamp) {
    const date = new Date(timestamp * 1000);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    if (isToday) return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' });
}

function escapeHtml(text) {
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
