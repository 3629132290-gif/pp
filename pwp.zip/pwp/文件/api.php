<?php
// ==================== 用户认证（与注册登录系统统一） ====================
// 注意：注册登录/api.php 内部已调用 session_start()，此处不再重复调用
require_once __DIR__ . '/../注册登录/api.php';
if (!isAuthenticated()) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => '登录已过期，请重新登录', 'need_auth' => true, 'redirect' => '/注册登录/注册登录.php']);
    exit;
}

$userId = $_SESSION['user']['id'];

// ==================== 数据库配置（安全加载） ====================
require_once __DIR__ . '/../secure_config.php';
try {
    $pdo = createSecurePdo();
} catch (RuntimeException $e) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => '数据库配置未就绪']);
    exit;
} catch (PDOException $e) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => '数据库连接失败']);
    exit;
}

// 查询用户域名信息，确定其专属根目录
$stmt = $pdo->prepare("SELECT * FROM domains WHERE user_id = ? AND status = 'active' LIMIT 1");
$stmt->execute([$userId]);
$userDomain = $stmt->fetch();

if (!$userDomain) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => '您还没有创建网站，请先绑定域名', 'need_domain' => true]);
    exit;
}

// 用户专属根目录（只能管理自己网站下的文件）
$userRootPath = rtrim($userDomain['path'], '/');

// 获取用户存储配额（容错：字段不存在时降级为默认值）
$userStorageQuota = 102400; // 默认 100KB
try {
    $stmt = $pdo->prepare("SELECT storage_quota FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $quota = $stmt->fetchColumn();
    if ($quota !== false) {
        $userStorageQuota = (int)$quota;
    }
} catch (PDOException $e) {
    // 字段不存在时保持默认值
}

// 计算用户当前已用空间
function getUserUsedSpace($rootPath) {
    if (!is_dir($rootPath)) return 0;
    $size = 0;
    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($rootPath, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $size += $file->getSize();
            }
        }
    } catch (Exception $e) {
        // 忽略权限错误
    }
    return $size;
}

// 容错加载 config.php
if (file_exists(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
}

// ==================== 路径安全函数（基于用户专属根目录） ====================
function normalizePath($path) {
    $path = str_replace('\\', '/', $path);
    return preg_replace('#/+#', '/', $path);
}

function resolvePath($path) {
    $path = normalizePath($path);
    global $userRootPath;
    if (strpos($path, '/') !== 0) {
        $path = $userRootPath . '/' . $path;
    }
    $parts = explode('/', $path);
    $resolved = [];
    foreach ($parts as $part) {
        if ($part === '' || $part === '.') continue;
        if ($part === '..') {
            array_pop($resolved);
        } else {
            $resolved[] = $part;
        }
    }
    $result = '/' . implode('/', $resolved);
    return preg_replace('#/+#', '/', $result);
}

function isValidPath($path) {
    global $userRootPath;
    $resolved = resolvePath($path);
    $root = rtrim(resolvePath($userRootPath), '/');
    if ($resolved === $root) return true;
    return strpos($resolved, $root . '/') === 0;
}

function ensureValidPath($path) {
    if (!isValidPath($path)) {
        global $userRootPath;
        return rtrim(resolvePath($userRootPath), '/');
    }
    return resolvePath($path);
}

// ==================== CSRF 验证 ====================
// 修复 #7: CSRF Token 仅接受 POST 传递，禁止通过 URL 参数暴露
function validateCsrf() {
    $token = $_POST['csrf_token'] ?? '';
    if (empty($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        return false;
    }
    return true;
}

// ==================== 请求路由 ====================
$action = $_POST['action'] ?? $_GET['action'] ?? 'list';
$currentPath = isset($_GET['path']) ? ensureValidPath($_GET['path']) : ensureValidPath($userRootPath);

// 频率限制：上传和编辑操作
if ($action === 'upload') {
    enforceRateLimit('file_upload');
}
if ($action === 'save') {
    enforceRateLimit('file_edit');
}

// 非读取操作需要CSRF验证
$writeActions = ['upload', 'mkdir', 'touch', 'delete', 'rename', 'save', 'unzip'];
if (in_array($action, $writeActions) && !validateCsrf()) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => '异常，请刷新页面重试']);
    exit;
}

$response = [];
switch ($action) {
    case 'list':    $response = actionList($currentPath); break;
    case 'upload':  $response = actionUpload($currentPath); break;
    case 'mkdir':   $response = actionMkdir(); break;
    case 'touch':   $response = actionTouch(); break;
    case 'delete':  $response = actionDelete(); break;
    case 'rename':  $response = actionRename(); break;
    case 'read':    $response = actionRead(); break;
    case 'save':    $response = actionSave(); break;
    case 'download': actionDownload(); exit;
    case 'info':    $response = actionInfo(); break;
    case 'unzip':   $response = actionUnzip(); break;
    case 'config':  $response = actionConfig(); break;
    default:        $response = ['error' => '未知操作'];
}

// 确保输出前清除任何可能的额外输出（如PHP警告/通知），保证纯JSON响应
if (ob_get_level() > 0) ob_clean();
header('Content-Type: application/json; charset=utf-8');
echo json_encode($response, JSON_PARTIAL_OUTPUT_ON_ERROR | JSON_UNESCAPED_UNICODE);
exit;

function actionUnzip() {
    if (!isset($_POST['path'])) return ['error' => '参数缺失'];
    $path = ensureValidPath($_POST['path']);
    if (!isValidPath($path)) return ['error' => '路径无效'];
    if (!file_exists($path)) return ['error' => '文件不存在'];
    if (!is_file($path)) return ['error' => '不是文件'];

    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if ($ext !== 'zip') return ['error' => '仅支持 ZIP 格式'];

    if (!class_exists('ZipArchive')) {
        return ['error' => '服务器出现异常'];
    }

    $zip = new ZipArchive();
    $res = $zip->open($path);
    if ($res !== true) {
        return ['error' => '无法打开压缩包 (错误码: ' . $res . ')'];
    }

    $dir = rtrim(dirname($path), '/');
    $conflicts = [];

    // 修复 H-03: Zip Slip 防护 - 验证每个条目路径在用户目录内
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $entry = $zip->getNameIndex($i);

        // 跳过目录条目
        if (substr($entry, -1) === '/') continue;

        // 去除 ZIP 顶层目录名（通常 ZIP 内有一个根目录）
        $parts = explode('/', $entry, 2);
        $relativePath = (count($parts) === 2 && $parts[1] !== '') ? $parts[1] : $entry;

        // 关键：检查路径遍历攻击
        $targetFile = $dir . '/' . $relativePath;
        $realTarget = realpath(dirname($targetFile)) !== false
            ? realpath(dirname($targetFile)) . '/' . basename($targetFile)
            : $targetFile;

        // 确保目标路径在用户目录内
        $realDir = realpath($dir) ?: $dir;
        if (strpos($realTarget, $realDir) !== 0) {
            $zip->close();
            return ['error' => '解压失败：异常' . htmlspecialchars($entry)];
        }

        if (file_exists($targetFile)) {
            $conflicts[] = $relativePath;
        }
    }

    if (!empty($conflicts)) {
        $zip->close();
        return ['error' => '解压失败：可能发生冲突：' . implode(', ', array_slice($conflicts, 0, 5)) . (count($conflicts) > 5 ? ' 等' : '')];
    }

    if (!$zip->extractTo($dir)) {
        $zip->close();
        return ['error' => '解压失败'];
    }

    $zip->close();
    return ['success' => true, 'target' => basename($dir)];
}

function actionConfig() {
    global $userRootPath, $userDomain, $userStorageQuota;
    $rootResolved = rtrim(resolvePath($userRootPath), '/');
    $maxSize = defined('MAX_UPLOAD_SIZE') ? MAX_UPLOAD_SIZE : 100 * 1024;
    $usedSpace = getUserUsedSpace($userRootPath);
    $fileCount = 0;
    if (is_dir($userRootPath)) {
        try {
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($userRootPath, RecursiveDirectoryIterator::SKIP_DOTS)
            );
            foreach ($it as $f) {
                if ($f->isFile()) $fileCount++;
            }
        } catch (Exception $e) {}
    }
    return [
        'csrf_token' => $_SESSION['csrf_token'] ?? '',
        'root_path' => $rootResolved,
        'root_name' => basename($rootResolved) ?: 'wwwroot',
        'max_upload_size' => $maxSize,
        'auth_required' => true,
        'domain' => $userDomain['domain'] ?? '',
        'storage_quota' => $userStorageQuota,
        'storage_used' => $usedSpace,
        'file_count' => $fileCount
    ];
}

function actionList($path) {
    $path = rtrim(ensureValidPath($path), '/');
    if (!is_dir($path)) {
        return ['error' => '目录不存在或无法访问: ' . basename($path)];
    }

    $files = [];
    $dir = @opendir($path);
    if (!$dir) {
        return ['error' => '无权限读取目录'];
    }

    while (($entry = readdir($dir)) !== false) {
        if ($entry === '.' || $entry === '..') continue;
        // 隐藏系统配置文件（以 . 开头的文件）
        if (strpos($entry, '.') === 0) continue;
        $fullPath = $path . '/' . $entry;
        $stat = @stat($fullPath);
        if (!$stat) continue;

        $isDir = is_dir($fullPath);
        $ext = $isDir ? '' : strtolower(pathinfo($entry, PATHINFO_EXTENSION));

        $files[] = [
            'name' => $entry,
            'type' => $isDir ? 'dir' : 'file',
            'size' => $stat['size'],
            'mtime' => $stat['mtime'],
            'ext' => $ext,
            'perms' => substr(sprintf('%o', @fileperms($fullPath)), -4)
        ];
    }
    closedir($dir);

    return ['files' => $files, 'path' => $path];
}

function actionUpload($currentPath) {
    if (empty($_FILES['file'])) {
        return ['error' => '没有收到文件'];
    }
    $file = $_FILES['file'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE => '文件超过服务器限制',
            UPLOAD_ERR_FORM_SIZE => '文件超过表单限制',
            UPLOAD_ERR_PARTIAL => '文件上传不完整',
            UPLOAD_ERR_NO_FILE => '没有文件被上传',
            UPLOAD_ERR_NO_TMP_DIR => '服务器异常-1',
            UPLOAD_ERR_CANT_WRITE => '服务器异常-2'
        ];
        return ['error' => $errors[$file['error']] ?? '上传错误代码: ' . $file['error']];
    }

    $maxSize = defined('MAX_UPLOAD_SIZE') ? MAX_UPLOAD_SIZE : 100 * 1024;
    if ($file['size'] > $maxSize) {
        $maxSizeDisplay = $maxSize >= 1048576 ? round($maxSize / 1048576, 0) . 'MB' : round($maxSize / 1024, 0) . 'KB';
        return ['error' => '文件超过限制' . $maxSizeDisplay . '）'];
    }

    // 检查存储配额
    global $userRootPath, $userStorageQuota;
    $currentUsed = getUserUsedSpace($userRootPath);
    if ($currentUsed + $file['size'] > $userStorageQuota) {
        $quotaMB = round($userStorageQuota / 1024 / 1024, 2);
        $usedMB = round($currentUsed / 1024 / 1024, 2);
        $remainMB = round(($userStorageQuota - $currentUsed) / 1024, 1);
        return ['error' => "空间不足！配额: {$quotaMB}MB，已用: {$usedMB}MB，剩余: {$remainMB}KB"];
    }

    $targetPath = isset($_POST['path']) ? ensureValidPath($_POST['path']) : ensureValidPath($currentPath);

    $name = basename($file['name']);
    // 文件名长度限制：最多 100 个字符
    if (mb_strlen($name, 'UTF-8') > 100) {
        return ['error' => '文件名过长'];
    }
    // 过滤危险字符，仅保留字母、数字、下划线、横线、点、空格和中文字符
    $name = preg_replace('/[^\w\-\. \x{4e00}-\x{9fff}]+/u', '_', $name);
    // 去除首尾空格和点
    $name = trim($name, " .");
    if ($name === '' || $name === '.' || $name === '..' || $name === '_') {
        return ['error' => '无效的文件名'];
    }
    // 禁止上传系统配置文件（以 . 开头的文件）
    if (strpos($name, '.') === 0) {
        return ['error' => '异常！'];
    }

    $target = rtrim($targetPath, '/') . '/' . $name;

    if (file_exists($target)) {
        return ['error' => '文件已存在: ' . $name];
    }

    if (!is_dir($targetPath)) {
        return ['error' => '目标目录不存在'];
    }
    if (!is_writable($targetPath)) {
        return ['error' => '无权限'];
    }

    // 修复 H-01: 移除 PHP 等可执行文件类型，防止用户上传 WebShell
    $allowedExts = ['jpg', 'jpeg', 'png', 'php', 'css', 'js', 'html', 'txt', 'zip', 'mp3', 'mp4'];
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExts)) {
        return ['error' => '不允许的文件类型，只允许: ' . implode(', ', $allowedExts)];
    }

    if (move_uploaded_file($file['tmp_name'], $target)) {
        // 修复 #16: 上传 PHP 文件时扫描危险函数
        if ($ext === 'php') {
            $content = file_get_contents($target);
            $scanResult = scanPhpFile($content, $name);
            if (!$scanResult['safe']) {
                @unlink($target);
                return ['error' => '异常'];
            }
        }
        return ['success' => true, 'name' => $name];
    }
    return ['error' => '无权限'];
}

function actionMkdir() {
    if (!isset($_POST['path'])) return ['error' => '参数缺失'];
    $target = ensureValidPath($_POST['path']);
    if (!isValidPath($target)) return ['error' => '路径无效'];
    if (file_exists($target)) return ['error' => '已存在'];

    if (@mkdir($target, 0755, true)) return ['success' => true];
    return ['error' => '无权限'];
}

function actionTouch() {
    if (!isset($_POST['path'])) return ['error' => '参数缺失'];
    $target = ensureValidPath($_POST['path']);
    if (!isValidPath($target)) return ['error' => '路径无效'];
    if (file_exists($target)) return ['error' => '已存在'];

    $dir = dirname($target);
    if (!is_dir($dir)) return ['error' => '父目录不存在'];

    if (@file_put_contents($target, '') !== false) return ['success' => true];
    return ['error' => '无权限'];
}

function actionDelete() {
    global $userRootPath;
    if (!isset($_POST['path'])) return ['error' => '参数缺失'];
    $path = ensureValidPath($_POST['path']);
    $resolved = resolvePath($path);
    $root = rtrim(resolvePath($userRootPath), '/');
    if (!isValidPath($path) || $resolved === $root) {
        return ['error' => '不能删除根目录'];
    }
    if (!file_exists($path)) return ['error' => '文件或目录不存在'];

    if (is_dir($path)) {
        if (deleteDirectory($path)) return ['success' => true];
        return ['error' => '删除失败'];
    } else {
        if (@unlink($path)) return ['success' => true];
        return ['error' => '删除失败'];
    }
}

function deleteDirectory($dir) {
    if (!is_dir($dir)) return false;
    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
        $path = $dir . '/' . $file;
        if (is_dir($path)) {
            if (!deleteDirectory($path)) return false;
        } else {
            if (!@unlink($path)) return false;
        }
    }
    return @rmdir($dir);
}

function actionRename() {
    if (!isset($_POST['path']) || !isset($_POST['newName'])) return ['error' => '参数缺失'];
    $old = ensureValidPath($_POST['path']);
    $new = ensureValidPath($_POST['newName']);

    if (!isValidPath($new)) return ['error' => '异常'];
    if (!file_exists($old)) return ['error' => '不存在'];
    if (file_exists($new)) return ['error' => '已存在'];

    if (@rename($old, $new)) return ['success' => true];
    return ['error' => '无权限'];
}

function actionRead() {
    if (!isset($_POST['path'])) return ['error' => '参数缺失'];
    $path = ensureValidPath($_POST['path']);
    if (!is_file($path)) return ['error' => '文件不存在'];

    $content = @file_get_contents($path);
    if ($content === false) return ['error' => '无权限'];

    if (function_exists('mb_convert_encoding')) {
        $content = mb_convert_encoding($content, 'UTF-8', 'UTF-8');
    } elseif (function_exists('iconv')) {
        $content = @iconv('UTF-8', 'UTF-8//IGNORE', $content);
    }
    return ['content' => $content];
}

function actionSave() {
    if (!isset($_POST['path']) || !isset($_POST['content'])) return ['error' => '参数缺失'];
    $path = ensureValidPath($_POST['path']);
    if (!isValidPath($path)) return ['error' => '路径无效'];

    $dir = dirname($path);
    if (!is_dir($dir)) return ['error' => '父目录不存在'];
    if (!is_writable($dir)) return ['error' => '无权限'];

    if (@file_put_contents($path, $_POST['content']) !== false) {
        return ['success' => true];
    }
    return ['error' => '无权限'];
}

function actionDownload() {
    if (!isset($_GET['path'])) {
        header('HTTP/1.1 400 Bad Request');
        exit;
    }
    $path = ensureValidPath($_GET['path']);
    if (!is_file($path)) {
        header('HTTP/1.1 404 Not Found');
        exit;
    }

    $filename = basename($path);
    $mime = mime_content_type($path) ?: 'application/octet-stream';
    $isPreview = isset($_GET['preview']) && $_GET['preview'] === '1';

    header('Content-Type: ' . $mime);
    if ($isPreview) {
        header('Content-Disposition: inline; filename="' . rawurlencode($filename) . '"');
    } else {
        header('Content-Disposition: attachment; filename="' . rawurlencode($filename) . '"');
    }
    header('Content-Length: ' . filesize($path));
    header('Cache-Control: no-cache, must-revalidate');

    readfile($path);
    exit;
}

function getDirectorySize($dir) {
    $size = 0;
    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS));
    foreach ($files as $file) {
        $size += $file->getSize();
    }
    return $size;
}

function actionInfo() {
    if (!isset($_POST['path'])) return ['error' => '参数缺失'];
    $path = ensureValidPath($_POST['path']);
    if (!isValidPath($path)) return ['error' => '路径无效'];
    if (!file_exists($path)) return ['error' => '不存在'];

    return [
        'size' => is_file($path) ? filesize($path) : (is_dir($path) ? getDirectorySize($path) : 0),
        'mtime' => filemtime($path),
        'perms' => substr(sprintf('%o', @fileperms($path)), -4)
    ];
}
