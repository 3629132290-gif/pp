/**
 * 安全防护前端脚本
 * 与现有平台风格保持一致
 * 无触控反馈版
 */
let csrfToken = window.csrfToken || '';
let currentUser = window.currentUser || {};

function showToast(msg, duration = 2500) {
    const t = document.getElementById('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), duration);
}

function toggleMobileSidebar() {
    const sb = document.getElementById('sidebar');
    const ov = document.getElementById('overlay');
    if (!sb || !ov) return;
    sb.classList.toggle('open');
    ov.classList.toggle('show');
}

function toggleCollapse() {
    const sb = document.getElementById('sidebar');
    const icon = document.getElementById('collapseIcon');
    if (!sb) return;
    if (window.innerWidth <= 768 && sb.classList.contains('open')) {
        sb.classList.remove('open');
        const ov = document.getElementById('overlay');
        if (ov) ov.classList.remove('show');
        return;
    }
    sb.classList.toggle('collapsed');
    if (icon) {
        if (sb.classList.contains('collapsed')) {
            icon.classList.remove('fa-chevron-left');
            icon.classList.add('fa-chevron-right');
            localStorage.setItem('sb', '1');
        } else {
            icon.classList.remove('fa-chevron-right');
            icon.classList.add('fa-chevron-left');
            localStorage.setItem('sb', '0');
        }
    }
}

function logout() {
    if (!confirm('确定要退出登录吗？')) return;
    $.ajax({
        url: '/注册登录/api.php',
        type: 'POST',
        data: { type: 'logout' },
        dataType: 'json',
        timeout: 10000,
        success: function() {
            window.location.href = '/注册登录/注册登录.php';
        },
        error: function() {
            window.location.href = '/注册登录/注册登录.php';
        }
    });
}

// 加载防护统计数据
function loadProtectStats() {
    $.ajax({
        url: '/安全防护/api.php',
        type: 'POST',
        data: { type: 'get_stats' },
        dataType: 'json',
        timeout: 10000,
        success: function(res) {
            if (res.status === 1 && res.data) {
                const blockCount = document.getElementById('blockCount');
                const safeDays = document.getElementById('safeDays');
                const blackIpCount = document.getElementById('blackIpCount');
                const threatLevel = document.getElementById('threatLevel');
                if (blockCount) blockCount.textContent = res.data.block_count || '0';
                if (safeDays) safeDays.textContent = res.data.safe_days || '0';
                if (blackIpCount) blackIpCount.textContent = res.data.black_ip_count || '0';
                if (threatLevel) threatLevel.textContent = res.data.threat_level || '低';
            }
        },
        error: function() {
            // 静默处理，不显示错误提示
        }
    });
}

// 加载拦截日志
function loadAttackLogs() {
    $.ajax({
        url: '/安全防护/api.php',
        type: 'POST',
        data: { type: 'get_logs', limit: 5 },
        dataType: 'json',
        timeout: 10000,
        success: function(res) {
            if (res.status === 1 && res.logs && res.logs.length > 0) {
                const list = document.getElementById('logList');
                if (!list) return;
                list.innerHTML = '';
                res.logs.forEach(function(log) {
                    const typeClass = log.type === 'SQL注入' ? 'sql' : 
                                     log.type === 'XSS攻击' ? 'xss' :
                                     log.type === 'CC攻击' ? 'cc' : 'bot';
                    list.innerHTML += '<div class="log-item">' +
                        '<span class="log-time">' + (log.time || '') + '</span>' +
                        '<span class="log-type ' + typeClass + '">' + (log.type || '') + '</span>' +
                        '<span class="log-ip">' + (log.ip || '') + '</span>' +
                        '<span class="log-action"><i class="fas fa-ban" style="margin-right: 4px;"></i>已拦截</span>' +
                        '</div>';
                });
            }
        },
        error: function() {
            // 静默处理，不显示错误提示
        }
    });
}

// 阻止开关点击并显示黑色Toast提示
function initSwitchHandlers() {
    document.querySelectorAll('.switch input').forEach(function(switchEl) {
        // 阻止 checkbox 状态改变
        switchEl.addEventListener('change', function(e) {
            e.preventDefault();
            this.checked = true; // 强制保持开启
            showToast('默认开启，不支持关闭');
        });
        // 兼容移动端：阻止 label 触发的点击穿透
        switchEl.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            this.checked = true; // 强制保持开启
            showToast('默认开启，不支持关闭');
            return false;
        });
    });
}

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    // 设置用户名
    const userNameEl = document.getElementById('userName');
    if (userNameEl && currentUser.name) {
        userNameEl.textContent = currentUser.name;
    }

    // 恢复侧边栏折叠状态（仅桌面端）
    if (window.innerWidth > 768 && localStorage.getItem('sb') === '1') {
        const sb = document.getElementById('sidebar');
        const icon = document.getElementById('collapseIcon');
        if (sb) sb.classList.add('collapsed');
        if (icon) {
            icon.classList.remove('fa-chevron-left');
            icon.classList.add('fa-chevron-right');
        }
    }

    // 自动检测iframe嵌入并应用样式（后备：HTML中已有立即执行脚本）
    if (window.self !== window.top) {
        document.body.classList.add('iframe-mode');
        document.documentElement.classList.add('iframe-mode');
    }

    // 加载防护统计
    loadProtectStats();

    // 加载攻击日志
    loadAttackLogs();

    // 初始化开关事件
    initSwitchHandlers();
});