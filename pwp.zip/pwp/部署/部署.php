<?php
// ==================== 登录状态严格校验 ====================
require_once __DIR__ . '/../注册登录/api.php';
// 如果未认证，强制跳转到登录页
if (!isAuthenticated()) {
    // 清除可能损坏的会话
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params['path'], $params['domain'],
            $params['secure'], $params['httponly']
        );
    }
    session_destroy();
    header('Location: /注册登录/注册登录.php');
    exit;
}
// 可选：IP 绑定校验（防止会话劫持）
if (!empty($_SESSION['auth_ip']) && $_SESSION['auth_ip'] !== getClientIP()) {
    // IP 变更可能表示会话劫持，记录并清除
    securityLog("会话IP不匹配，强制登出: " . ($_SESSION['user']['name'] ?? '未知') . 
                " 预期IP: " . $_SESSION['auth_ip'] . " 实际IP: " . getClientIP());
    clearAuthenticatedSession();
    header('Location: /注册登录/注册登录.php');
    exit;
}
// 会话超过24小时强制刷新（可选安全增强）
if (!empty($_SESSION['auth_time']) && time() - $_SESSION['auth_time'] > 86400) {
    securityLog("会话超时，强制登出: " . ($_SESSION['user']['name'] ?? '未知'));
    clearAuthenticatedSession();
    header('Location: /注册登录/注册登录.php');
    exit;
}
// 将用户信息暴露给前端（安全字段）
$currentUser = [
    'name'  => htmlspecialchars($_SESSION['user']['name'] ?? '用户', ENT_QUOTES, 'UTF-8'),
    'email' => htmlspecialchars($_SESSION['user']['email'] ?? '', ENT_QUOTES, 'UTF-8'),
];

// 获取用户存储配额信息
$userStorageQuota = 102400; // 默认 100KB
$userStorageUsed = 0;
$userFileCount = 0;
$userStorageLevel = 'LV1';

try {
    require_once __DIR__ . '/../secure_config.php';
    $pdo = createSecurePdo();
    $stmt = $pdo->prepare("SELECT storage_quota FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user']['id']]);
    $quota = $stmt->fetchColumn();
    if ($quota !== false) {
        $userStorageQuota = (int)$quota;
    }
    // 判断用户等级：配额 > 100KB 视为已开通 LV2
    $userStorageLevel = ($userStorageQuota > 102400) ? 'LV2' : 'LV1';
    
    // 获取用户域名路径以计算已用空间
    $stmt = $pdo->prepare("SELECT path FROM domains WHERE user_id = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$_SESSION['user']['id']]);
    $domain = $stmt->fetch();
    if ($domain && is_dir($domain['path'])) {
        $userStorageUsed = getUserDirSize($domain['path']);
        $userFileCount = getUserFileCount($domain['path']);
    }
} catch (Exception $e) {
    // 降级使用默认值
}

function getUserDirSize($dir) {
    $size = 0;
    try {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        foreach ($it as $f) {
            if ($f->isFile()) $size += $f->getSize();
        }
    } catch (Exception $e) {}
    return $size;
}
function getUserFileCount($dir) {
    $count = 0;
    try {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        foreach ($it as $f) {
            if ($f->isFile()) $count++;
        }
    } catch (Exception $e) {}
    return $count;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>部署中心 - Miyo</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" 
      integrity="sha384-t1nt8BQoYMLFN5p42tRAtuAAFQaCQODekUVeKKZrEnEyp4H2R0RHFz0KWpmj7i8g" crossorigin="anonymous">
<link rel="stylesheet" href="部署.css">
<style>
/* iframe 嵌入专用补充样式 */
.iframe-wrapper {
    width: 100%;
    height: 100%;
    position: relative;
    display: none;
}
.iframe-wrapper iframe {
    width: 100%;
    height: 100%;
    border: none;
    display: block;
    opacity: 1;
    transition: opacity 0.3s ease;
}
.iframe-wrapper iframe.iframe-loading {
    opacity: 0;
}
.main-content.iframe-mode {
    padding: 0;
    overflow: hidden;
}
/* iframe 加载中的 Loading 动画 */
.iframe-loading-overlay {
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: var(--cream, #faf5f2);
    z-index: 10;
    pointer-events: none;
    transition: opacity 0.3s ease;
}
.iframe-loading-overlay.hidden {
    opacity: 0;
    pointer-events: none;
}
.iframe-loading-spinner {
    width: 40px;
    height: 40px;
    border: 3px solid #e5e5e5;
    border-top-color: #333;
    border-radius: 50%;
    animation: iframe-spin 0.8s linear infinite;
    margin-bottom: 16px;
}
.iframe-loading-text {
    font-size: 14px;
    color: #999;
}
@keyframes iframe-spin {
    to { transform: rotate(360deg); }
}
</style>
</head>
<body>
<div class="app">
    <div class="overlay" id="overlay" onclick="toggleMobileSidebar()"></div>
    <!-- 顶部导航栏 -->
    <header class="header-bar">
        <div class="left">
            <button class="menu-toggle" id="menuToggle" onclick="toggleMobileSidebar()" aria-label="菜单">
                <i class="fas fa-bars"></i>
            </button>
            <img src="logo1.png" alt="Logo" class="logo-img" onerror="this.style.display='none'">
            <span class="title">miyo 网站托管</span>
        </div>
        <div class="user-info">
            <span class="user-name user-name-display"><?php echo $currentUser['name']; ?></span>
            <!-- 系统通知按钮 -->
            <button class="notification-bell" id="notificationBell" onclick="toggleNotificationPanel()" title="系统通知">
                <i class="fas fa-bell"></i>
                <span class="notification-badge" id="notifBadge" style="display:none;">0</span>
            </button>
            <button class="logout-btn" onclick="logout()">
                <i class="fas fa-sign-out-alt"></i>
                <span class="btn-text">退出</span>
            </button>
        </div>
    </header>
    <!-- 侧边栏 -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <button class="collapse-btn" onclick="toggleCollapse()" title="折叠菜单">
                <i class="fas fa-chevron-left" id="collapseIcon"></i>
            </button>
        </div>
        <nav class="sidebar-nav">
            <a href="javascript:void(0)" class="nav-item active" data-nav="dashboard" onclick="showDashboard(); return false;">
                <i class="fas fa-home"></i>
                <span>控制面板</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="/域名/域名.php" onclick="navigateTo('/域名/域名.php'); return false;">
                <i class="fas fa-globe"></i>
                <span>域名绑定</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="/文件/文件.php" onclick="navigateTo('/文件/文件.php'); return false;">
                <i class="fas fa-folder"></i>
                <span>在线文件</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="/数据库/数据库.php" onclick="navigateTo('/数据库/数据库.php'); return false;">
                <i class="fas fa-database"></i>
                <span>数据库管理</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="/ssl/ssl.html" onclick="navigateTo('/ssl/ssl.html'); return false;">
                <i class="fas fa-shield-alt"></i>
                <span>SSL配置</span>
            </a>
            <a href="javascript:void(0)" class="nav-item" data-nav="/防护/防护.html" onclick="navigateTo('/防护/防护.html'); return false;">
                <i class="fas fa-lock"></i>
                <span>安全防护</span>
            </a>
            <!-- 新增：关于 -->
            <a href="javascript:void(0)" class="nav-item" data-nav="/关于/关于.html" onclick="navigateTo('/关于/关于.html'); return false;">
                <i class="fas fa-info-circle"></i>
                <span>关于</span>
            </a>
        </nav>
        <div class="sidebar-footer">miyo V4.0 · 网站托管</div>
    </aside>
    <!-- 主内容区 -->
    <main class="main-content" id="mainContent">
        <!-- 概览面板 -->
        <div class="content-wrapper" id="dashboard-view">
            <!-- 公告弹窗 -->
            <div class="announcement-modal-overlay" id="announcementOverlay" style="display:none;">
                <div class="announcement-modal" id="announcementBar">
                    <div class="announcement-modal-header">
                        <span class="announcement-modal-title">系统公告</span>
                        <button class="announcement-modal-close" onclick="closeAnnouncement()">×</button>
                    </div>
                    <div class="announcement-modal-body">
                        <div class="announcement-modal-text" id="announcementBody"></div>
                    </div>
                    <div class="announcement-modal-footer">
                        <button class="announcement-modal-btn" onclick="closeAnnouncement()">我知道了</button>
                    </div>
                </div>
            </div>
            <!-- 欢迎区域 -->
            <div class="welcome-section">
                <h1>欢迎回来，<span id="welcomeName"><?php echo $currentUser['name']; ?></span></h1>
                <p>这里是您的部署控制台，管理站点与资源</p>
            </div>
            <!-- 卡片网格 -->
            <div class="card-grid">
                <!-- 存储空间 -->
                <div class="card space-card" style="animation-delay:0.05s">
                    <div class="space-header">
                        <div class="space-info">
                            <h2>网页空间</h2>
                            <p>用户等级：<?php echo $userStorageLevel; ?><br>存储总容量：<?php echo $userStorageQuota >= 1048576 ? round($userStorageQuota / 1048576, 0) . 'MB' : round($userStorageQuota / 1024, 0) . 'KB'; ?></p>
                        </div>
                        <div class="space-ratio" id="spaceRatio">0% 已用</div>
                    </div>
                    <div class="progress-track">
                        <div class="progress-fill" id="spaceProgress" data-width="0"></div>
                    </div>
                    <div class="space-details">
                        <div class="space-detail-item">
                            <h4>已用空间</h4>
                            <p id="usedSpace">0 MB</p>
                        </div>
                        <div class="space-detail-item">
                            <h4>剩余空间</h4>
                            <p id="remainSpace">0 MB</p>
                        </div>
                        <div class="space-detail-item">
                            <h4>总容量</h4>
                            <p><?php echo $userStorageQuota >= 1048576 ? round($userStorageQuota / 1048576, 0) . ' MB' : round($userStorageQuota / 1024, 0) . ' KB'; ?></p>
                        </div>
                        <div class="space-detail-item">
                            <h4>文件数量</h4>
                            <p id="fileCountDisplay">0 个</p>
                        </div>
                    </div>
                    <!-- 扩容引导区 -->
                    <div class="upsell-divider"></div>
                    <a href="/其他/售卡.html" class="upsell-section">
                        <div class="upsell-inner">
                            <div class="upsell-left">
                                <span class="upsell-icon">
                                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                        <polyline points="15 3 21 3 21 9"></polyline>
                                        <polyline points="9 21 3 21 3 15"></polyline>
                                        <line x1="21" y1="3" x2="14" y2="10"></line>
                                        <line x1="3" y1="21" x2="10" y2="14"></line>
                                    </svg>
                                </span>
                                <div class="upsell-text">
                                    <span class="upsell-title">空间太小？一键扩容！</span>
                                    <span class="upsell-subtitle">解锁更大容量，释放你的创造力</span>
                                </div>
                            </div>
                            <div class="upsell-right">
                                <span class="upsell-arrow">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                        <polyline points="12 5 19 12 12 19"></polyline>
                                    </svg>
                                </span>
                            </div>
                        </div>
                        <div class="upsell-shimmer"></div>
                    </a>
                </div>
                <!-- 二级域名 -->
                <a href="javascript:void(0)" class="card action-card" id="subdomainCard" onclick="navigateTo('/域名/域名.php')" style="animation-delay:0.1s">
                    <div class="card-header">
                        <span class="card-label">二级域名</span>
                        <div class="card-icon"><i class="fas fa-link" id="subdomainIcon"></i></div>
                    </div>
                    <div class="card-value" id="subdomainValue">二级域名</div>
                    <div class="card-desc" id="subdomainDesc">点击管理您的二级域名</div>
                </a>
                <!-- 上传文件 -->
                <a href="javascript:void(0)" class="card action-card" onclick="navigateTo('/文件/文件.php')" style="animation-delay:0.15s">
                    <div class="card-header">
                        <span class="card-label">操作</span>
                        <div class="card-icon"><i class="fas fa-cloud-upload-alt"></i></div>
                    </div>
                    <div class="card-value">上传文件</div>
                    <div class="card-desc">管理您的项目文件</div>
                </a>
            </div>
        </div>
        <!-- iframe 嵌入容器 -->
        <div class="iframe-wrapper" id="iframe-view">
            <div class="iframe-loading-overlay" id="iframeLoading">
                <div class="iframe-loading-spinner"></div>
                <div class="iframe-loading-text">页面加载中...</div>
            </div>
            <iframe id="content-iframe" src="" loading="lazy"></iframe>
        </div>
    </main>
</div>
<!-- Toast 通知 -->
<div class="toast" id="toast"></div>
<!-- 通知面板 -->
<div class="notification-panel" id="notificationPanel">
    <div class="notification-panel-header">
        <span><i class="fas fa-bell"></i> 系统通知</span>
        <button onclick="toggleNotificationPanel()" style="background:none;border:none;font-size:18px;cursor:pointer;color:#666;"><i class="fas fa-times"></i></button>
    </div>
    <div class="notification-panel-body" id="notificationList">
        <div class="notification-empty">加载中...</div>
    </div>
</div>
<!-- 传递后端真实用户数据给前端 -->
<script>
window.currentUser = <?php echo json_encode($currentUser); ?>;
window.storageData = {
    usedBytes: <?php echo (int)$userStorageUsed; ?>,
    totalBytes: <?php echo (int)$userStorageQuota; ?>,
    fileCount: <?php echo (int)$userFileCount; ?>,
    level: '<?php echo $userStorageLevel; ?>'
};
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"
        integrity="sha384-1H217gwSVyLSIfaLxHbE7dRb3v4mYCKbpQvzx0cegeju1MVsGrX5xXxAvs/HgeFs" crossorigin="anonymous"></script>
<script src="部署.js"></script>
<script>
// CSRF Token（用于通知和公告接口）
window.csrfToken = "<?php
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8');
?>";
</script>
<script>
// 访问追踪（记录用户访问部署页面，修复访问统计不正确的问题）
(function() {
    let visitId = null;
    let startTime = Date.now();
    let totalDuration = 0;
    let isVisible = true;
    let recorded = false;

    function recordVisit() {
        if (recorded) return;
        recorded = true;
        var params = new URLSearchParams();
        params.append('type', 'record_visit');
        params.append('csrf_token', window.csrfToken);
        params.append('page', 'deploy');
        fetch('/admin/api.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: params.toString()
        }).then(function(r){ return r.json(); }).then(function(res){
            if (res.status === 1) visitId = res.visit_id;
        }).catch(function(){});
    }

    function updateDuration() {
        if (!visitId || !isVisible) return;
        var now = Date.now();
        totalDuration += Math.floor((now - startTime) / 1000);
        startTime = now;
        var params = new URLSearchParams();
        params.append('type', 'update_duration');
        params.append('visit_id', visitId);
        params.append('duration', totalDuration);
        params.append('csrf_token', window.csrfToken);
        if (navigator.sendBeacon) {
            navigator.sendBeacon('/admin/api.php', new Blob([params.toString()], {type: 'application/x-www-form-urlencoded'}));
        }
    }

    function recordLeave() {
        if (!visitId) return;
        if (isVisible) {
            totalDuration += Math.floor((Date.now() - startTime) / 1000);
        }
        var params = new URLSearchParams();
        params.append('type', 'record_leave');
        params.append('visit_id', visitId);
        params.append('duration', totalDuration);
        params.append('csrf_token', window.csrfToken);
        if (navigator.sendBeacon) {
            navigator.sendBeacon('/admin/api.php', new Blob([params.toString()], {type: 'application/x-www-form-urlencoded'}));
        } else {
            fetch('/admin/api.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: params.toString(),
                keepalive: true
            }).catch(function(){});
        }
        visitId = null;
    }

    recordVisit();
    window.addEventListener('beforeunload', recordLeave);
    document.addEventListener('visibilitychange', function() {
        if (document.visibilityState === 'hidden') {
            isVisible = false;
            updateDuration();
        } else if (document.visibilityState === 'visible') {
            isVisible = true;
            startTime = Date.now();
        }
    });
    setInterval(updateDuration, 30000);
})();
</script>
</body>
</html>
