/**
 * 部署中心前端脚本
 * 已修复：手机端显示不全
 * 已移除：全部AI客服相关代码
 */
// ===== 全局状态 =====
const AppState = {
    // 从后端传递的全局变量获取真实用户信息，降级处理防止报错
    user: window.currentUser || {
        name: '用户',
        email: ''
    },
    storage: window.storageData || {
        usedBytes: 0,
        totalBytes: 102400,    // 100 KB
        fileCount: 0,
        level: 'LV1'
    },
    config: {
        root_domain: 'miyo.app'
    }
};
// ===== Toast 通知 =====
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2500);
}
// ===== 页面路由（iframe 嵌入） =====
function navigateTo(url) {
    const mainContent = document.getElementById('mainContent');
    const dashboard   = document.getElementById('dashboard-view');
    const iframeView  = document.getElementById('iframe-view');
    const iframe      = document.getElementById('content-iframe');
    const loadingEl   = document.getElementById('iframeLoading');
    if (!iframeView || !iframe) return;
    dashboard.style.display   = 'none';
    iframeView.style.display    = 'block';
    mainContent.classList.add('iframe-mode');
    // 显示 Loading 动画
    if (loadingEl) {
        loadingEl.classList.remove('hidden');
        iframe.classList.add('iframe-loading');
    }
    iframe.src = url;
    // 关闭移动端侧边栏
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    if (sidebar) sidebar.classList.remove('open');
    if (overlay) overlay.classList.remove('show');
    updateActiveNav(url);
}
function showDashboard() {
    const mainContent = document.getElementById('mainContent');
    const dashboard   = document.getElementById('dashboard-view');
    const iframeView  = document.getElementById('iframe-view');
    const iframe      = document.getElementById('content-iframe');
    dashboard.style.display   = 'block';
    iframeView.style.display  = 'none';
    mainContent.classList.remove('iframe-mode');
    if (iframe) iframe.src = '';
    // 关闭移动端侧边栏
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    if (sidebar) sidebar.classList.remove('open');
    if (overlay) overlay.classList.remove('show');
    updateActiveNav('dashboard');
    // 刷新存储空间数据（修复：上传文件后返回控制面板时数据不更新）
    refreshStorageData();
}
function updateActiveNav(nav) {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.getAttribute('data-nav') === nav) {
            item.classList.add('active');
        }
    });
}
// ===== 侧边栏折叠/展开 =====
function toggleCollapse() {
    const sb = document.getElementById('sidebar');
    const icon = document.getElementById('collapseIcon');
    if (window.innerWidth <= 768 && sb.classList.contains('open')) {
        sb.classList.remove('open');
        document.getElementById('overlay').classList.remove('show');
        return;
    }
    sb.classList.toggle('collapsed');
    if (sb.classList.contains('collapsed')) {
        icon.classList.remove('fa-chevron-left');
        icon.classList.add('fa-chevron-right');
        localStorage.setItem('sb', '1');
    } else {
        icon.classList.remove('fa-chevron-right');
        icon.classList.add('fa-chevron-left');
        localStorage.setItem('sb', '0');
    }
}
// ===== 移动端侧边栏 =====
function toggleMobileSidebar() {
    const sb = document.getElementById('sidebar');
    const ov = document.getElementById('overlay');
    sb.classList.toggle('open');
    ov.classList.toggle('show');
}
// ===== 退出登录 =====
function logout() {
    if (!confirm('确定要退出登录吗？')) return;
    const btn = document.querySelector('.logout-btn');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span class="btn-text">退出中...</span>';
    }
    // 调用后端清除 session，防止仅前端跳转导致会话仍有效
    $.ajax({
        url: '/注册登录/api.php',
        type: 'POST',
        data: { type: 'logout' },
        dataType: 'json',
        timeout: 10000,
        success: function(res) {
            showToast(res.msg || '已退出登录');
            setTimeout(() => {
                window.location.href = '/注册登录/注册登录.php';
            }, 600);
        },
        error: function(xhr, status) {
            let msg = '退出请求失败';
            if (status === 'timeout') msg = '请求超时';
            else if (xhr.status === 401) msg = '登录已过期';
            showToast(msg + '，正在跳转...');
            // 即使后端失败也强制跳转，避免用户卡在页面
            setTimeout(() => {
                window.location.href = '/注册登录/注册登录.php';
            }, 1200);
        }
    });
}
// ===== 数字动画 =====
function animateNumbers() {
    document.querySelectorAll('[data-count]').forEach(el => {
        const target = parseInt(el.dataset.count);
        const dur = 800;
        const start = performance.now();
        function upd(now) {
            const p = Math.min((now - start) / dur, 1);
            const ease = 1 - Math.pow(1 - p, 3);
            el.textContent = Math.floor(ease * target);
            if (p < 1) requestAnimationFrame(upd);
        }
        requestAnimationFrame(upd);
    });
}
// ===== 存储进度条动画 =====
function animateStorage() {
    const bar = document.getElementById('spaceProgress');
    if (bar) {
        setTimeout(() => {
            bar.style.width = bar.dataset.width + '%';
        }, 300);
    }
}
// ===== 格式化字节 =====
function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
}
// 智能格式化存储空间（小空间用 KB，大空间用 MB）
function formatStorage(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
    return (bytes / 1024 / 1024).toFixed(2) + ' MB';
}
// ===== 渲染页面数据 =====
function renderPage() {
    const state = AppState;
    // 用户信息
    document.querySelectorAll('.user-name-display').forEach(el => {
        el.textContent = state.user.name;
    });
    // 欢迎语
    const welcomeName = document.getElementById('welcomeName');
    if (welcomeName) welcomeName.textContent = state.user.name;
    // 存储空间
    const usedDisplay  = formatStorage(state.storage.usedBytes);
    const remainDisplay = formatStorage(state.storage.totalBytes - state.storage.usedBytes);
    const totalDisplay  = formatStorage(state.storage.totalBytes);
    const usedPercent = Math.min(100, ((state.storage.usedBytes / state.storage.totalBytes) * 100).toFixed(1));
    const usedSpaceEl    = document.getElementById('usedSpace');
    const remainSpaceEl  = document.getElementById('remainSpace');
    const fileCountEl    = document.getElementById('fileCountDisplay');
    const spaceRatioEl   = document.getElementById('spaceRatio');
    const spaceProgressEl = document.getElementById('spaceProgress');
    if (usedSpaceEl)    usedSpaceEl.textContent    = usedDisplay;
    if (remainSpaceEl)  remainSpaceEl.textContent  = remainDisplay;
    if (fileCountEl)    fileCountEl.textContent    = state.storage.fileCount + ' 个';
    if (spaceRatioEl)   spaceRatioEl.textContent   = usedPercent + '% 已用';
    if (spaceProgressEl) spaceProgressEl.dataset.width = usedPercent;
    // 二级域名卡片文案（固定为操作入口）
    const subdomainValue = document.getElementById('subdomainValue');
    const subdomainDesc  = document.getElementById('subdomainDesc');
    if (subdomainValue) subdomainValue.textContent = '管理域名';
    if (subdomainDesc)  subdomainDesc.textContent  = '点击管理您的二级域名';
}
// ===== HTML 转义 =====
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
// ===== 刷新存储空间数据（修复：上传文件后返回控制面板数据不更新） =====
function refreshStorageData() {
    fetch('/文件/api.php?action=config')
        .then(function(r) { return r.json(); })
        .then(function(data) {
            if (data.storage_quota !== undefined) {
                AppState.storage.usedBytes = data.storage_used || 0;
                AppState.storage.totalBytes = data.storage_quota || 102400;
                AppState.storage.fileCount = data.file_count || 0;
                AppState.storage.level = (data.storage_quota > 102400) ? 'LV2' : 'LV1';
                renderPage();
                animateStorage();
            }
        })
        .catch(function() {});
}
// ===== 初始化 =====
document.addEventListener('DOMContentLoaded', function() {
    // 恢复侧边栏折叠状态（仅桌面端）
    if (window.innerWidth > 768 && localStorage.getItem('sb') === '1') {
        const sb   = document.getElementById('sidebar');
        const icon = document.getElementById('collapseIcon');
        if (sb) sb.classList.add('collapsed');
        if (icon) {
            icon.classList.remove('fa-chevron-left');
            icon.classList.add('fa-chevron-right');
        }
    }
    // iframe 加载完成隐藏 Loading
    const iframe = document.getElementById('content-iframe');
    const loadingEl = document.getElementById('iframeLoading');
    if (iframe && loadingEl) {
        iframe.addEventListener('load', function() {
            loadingEl.classList.add('hidden');
            iframe.classList.remove('iframe-loading');
        });
    }
    // 监听 iframe 内子页面的 postMessage（如：域名绑定后通知刷新存储）
    window.addEventListener('message', function(e) {
        if (e.data && e.data.type === 'domain_bound') {
            refreshStorageData();
        }
    });
    // 渲染数据
    renderPage();
    // 动画
    animateNumbers();
    animateStorage();
    // 加载公告（每次访问都显示）
    loadAnnouncement();
    // 加载通知
    loadMyNotifications();
});
// ===== 公告弹窗功能 =====
function loadAnnouncement() {
    var params = new URLSearchParams();
    params.append('type', 'get_announcement');
    params.append('csrf_token', window.csrfToken || '');
    fetch('/admin/api.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: params.toString()
    }).then(function(r){ return r.json(); }).then(function(res) {
        if (res.status === 1 && res.data) {
            var overlay = document.getElementById('announcementOverlay');
            var bodyEl = document.getElementById('announcementBody');
            if (overlay && bodyEl) {
                // 修复 #12: 使用 textContent 防止 XSS，手动将 \n 转为 <br>
                var content = res.data.content || '';
                // 先通过 textContent 安全渲染，再转成含 <br> 的 HTML
                var lines = content.split('\n');
                bodyEl.innerHTML = '';
                lines.forEach(function(line, idx) {
                    if (idx > 0) bodyEl.appendChild(document.createElement('br'));
                    bodyEl.appendChild(document.createTextNode(line));
                });
                overlay.style.display = 'flex';
            }
        }
    }).catch(function(){});
}
function closeAnnouncement() {
    var overlay = document.getElementById('announcementOverlay');
    if (overlay) overlay.style.display = 'none';
}
// ===== 通知面板功能 =====
function toggleNotificationPanel() {
    var panel = document.getElementById('notificationPanel');
    if (!panel) return;
    var isOpen = panel.classList.contains('open');
    if (isOpen) {
        panel.classList.remove('open');
    } else {
        panel.classList.add('open');
        // 每次打开时刷新通知列表
        loadMyNotifications();
    }
}
function loadMyNotifications() {
    var params = new URLSearchParams();
    params.append('type', 'get_my_notifications');
    params.append('csrf_token', window.csrfToken || '');
    fetch('/admin/api.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: params.toString()
    }).then(function(r){ return r.json(); }).then(function(res) {
        if (res.status === 1 && res.data) {
            var list = document.getElementById('notificationList');
            var badge = document.getElementById('notifBadge');
            // 更新未读数
            if (badge && res.data.unread_count > 0) {
                badge.textContent = res.data.unread_count > 99 ? '99+' : res.data.unread_count;
                badge.style.display = 'inline-flex';
            } else if (badge) {
                badge.style.display = 'none';
            }
            // 渲染通知列表
            if (!list) return;
            if (!res.data.notifications || res.data.notifications.length === 0) {
                list.innerHTML = '<div class="notification-empty"><i class="fas fa-bell-slash" style="font-size:24px;opacity:.3"></i><p>暂无通知</p></div>';
                return;
            }
            list.innerHTML = res.data.notifications.map(function(n) {
                var unreadClass = (parseInt(n.is_read) === 0) ? ' notification-item-unread' : '';
                var timeStr = n.created_at || '';
                return '<div class="notification-item' + unreadClass + '" data-id="' + n.id + '" onclick="markNotifRead(' + n.id + ')">'
                    + '<div class="notification-item-header">'
                    + '<strong>' + escapeHtml(n.title) + '</strong>'
                    + '<span class="notification-item-time">' + escapeHtml(timeStr) + '</span>'
                    + '</div>'
                    + '<div class="notification-item-body">' + escapeHtml(n.content) + '</div>'
                    + '</div>';
            }).join('');
        }
    }).catch(function(){});
}
function markNotifRead(id) {
    var params = new URLSearchParams();
    params.append('type', 'mark_notification_read');
    params.append('notification_id', id);
    params.append('csrf_token', window.csrfToken || '');
    fetch('/admin/api.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: params.toString()
    }).then(function(r){ return r.json(); }).then(function(res) {
        if (res.status === 1) {
            // 标记已读样式
            var item = document.querySelector('.notification-item[data-id="' + id + '"]');
            if (item) item.classList.remove('notification-item-unread');
            // 重新加载以更新未读数
            loadMyNotifications();
        }
    }).catch(function(){});
}
// 点击页面其他区域关闭通知面板
document.addEventListener('click', function(e) {
    var panel = document.getElementById('notificationPanel');
    var bell = document.getElementById('notificationBell');
    if (panel && panel.classList.contains('open')) {
        if (!panel.contains(e.target) && bell && !bell.contains(e.target)) {
            panel.classList.remove('open');
        }
    }
});
