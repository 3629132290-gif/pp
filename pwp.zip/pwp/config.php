<?php
/**
 * MiyoHost 配置桥接文件
 * ============================================================================
 * 修复 C-02: 此文件不再存储任何敏感凭据。
 * 所有敏感配置（SMTP、数据库、API密钥）现在通过 secure_config.php 加载。
 * 
 * 部署时请配置 /www/.miyo_env.php 或设置环境变量，详见 .env.example.php
 * ============================================================================
 * 
 * 向后兼容：保留此文件供旧代码引用，实际配置从安全加载器获取
 */

require_once __DIR__ . '/secure_config.php';

$smtp = SecureConfig::getInstance()->getSmtpConfig();

return [
    'smtp_host' => $smtp['host'],
    'smtp_port' => $smtp['port'],
    'smtp_user' => $smtp['user'],
    'smtp_pass' => $smtp['pass'],
];